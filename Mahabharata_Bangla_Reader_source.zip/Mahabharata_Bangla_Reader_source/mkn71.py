import mknotes3,mknotes,json,re,os
R=[('| Kartana', '1 Kartana'), ('Both are correct. To be on his own side.', 'Both are correct. 5 To be on his own side.'), ('©Rohini', '6 Rohini'), ('!1 The boar', '11 The boar'), ('12 arjuna', '12 Arjuna'), ('130 ther than', '13 Other than'), ('!7The word', '17 The word'), ('251n the sense', '25 In the sense'), ('ina pot', 'in a pot'), ('34 Ķumuda', '34 Kumuda'), ('37 shatapatras', '37 Shatapatras'), ('*20ne part', '42 One part'), ('44vVaruna', '44 Varuna'), ('‘8 That is', '48 That is'), ('49° He was', '49 He was'), ('5 I That is', '51 That is'), ('5 3Duryodhana ’s', '53 Duryodhana’s'), ('5 4 Ardhasi , or', '54 Ardhasi, or'), ('>From the side', '55 From the side'), ('5 °Bhratrivya', '59 Bhratrivya'), ('64Bhima. Bhima.', '64 Bhima. 65 Bhima.'), ('T0Lipta', '70 Lipta'), ('T71 Kapisha', '71 Kapisha'), ('7©Bhima’s', '76 Bhima’s'), ('830r Valakhilyas', '83 Or Valakhilyas'), ('°1Dhrishtadyumna’s bow', '91 Dhrishtadyumna’s bow'), ('92.Dhrishtadyumna', '92 Dhrishtadyumna'), ('°3Dhrishtadyumna leapt', '93 Dhrishtadyumna leapt'), ('96vVishnu', '96 Vishnu'), ('100k rishna', '100 Krishna'), ('10l Satyaki', '101 Satyaki'), ('106A shvatthama', '106 Ashvatthama'), ('111 gatyavati', '111 Satyavati')]
def first(t):
    for a,b in R:
        if a in t: t=t.replace(a,b,1); continue
        rx=re.escape(a).replace('\\ ',r'\s?')
        m=re.search(rx,t); assert m,a; t=t[:m.start()]+b+t[m.end():]
    t=re.sub(r'(?<=\s)(\d{1,3})(?=[A-Z])',r'\1 ',t)
    t=re.sub(r'(Sections? \d+) ?\(',lambda m:m.group(1)+' (',t)
    return t
N,miss=mknotes3.parse(23318,23420,118,first=first)
print('miss',len(miss),miss)
if not miss:
    mknotes.fin(N,118,"notes71.json")
    d=json.load(open('notes71.json')); d={k:v.replace(' ',' ') for k,v in d.items()}
    for k,v in d.items():
        if v and v[0].islower(): d[k]=v[0].upper()+v[1:]
    json.dump(d,open('notes71.json','w'),ensure_ascii=False,indent=0)
if os.environ.get('SH'):
    for k in map(int,os.environ['SH'].split(',')): print(k,'::',N.get(k))
d=json.load(open('notes71.json'))
import re as _re
for k,v in d.items():
    v=_re.sub(r'\b(J|K|B|D|S|Y|V|A) (ayadratha|ritavarma|arna|rishna|hurishrava|rona|hikhandi|udhishthira|asudeva|ritra|ishnu|atyaki|uryodhana|hima|hrishtadyumna|ishku|gni|shvattahama|shvatthama)',r'\1\2',v)
    d[k]=v
FX={}
for k,(a,b) in FX.items():
    assert a in d[k],(k,a); d[k]=d[k].replace(a,b)
json.dump(d,open('notes71.json','w'),ensure_ascii=False,indent=0)
