import mknotes3,mknotes,json,re,os
R=[('T A club','7 A club'),('4] Balarama was fair','41 Balarama was fair'),('49 Pralamba was','45 Pralamba was'),('J ayadratha','Jayadratha'),('sheelephant','she-elephant'),('kindom','kingdom')]
def first(t):
    t=re.sub(r'Chapter 12\d\d\(\d+\)',' ',t)
    for a,b in R:
        if a in t: t=t.replace(a,b,1); continue
        rx=re.escape(a).replace('\\ ',r'\s?')
        m=re.search(rx,t); assert m,a; t=t[:m.start()]+b+t[m.end():]
    t=re.sub(r'(?<=\s)(\d{1,3})(?=[A-Z])',r'\1 ',t)
    t=re.sub(r'(Sections? \d+) ?\(',lambda m:m.group(1)+' (',t)
    return t
N,miss=mknotes3.parse(27257,27333,84,first=first)
print('miss',len(miss),miss)
if not miss:
    mknotes.fin(N,84,"notes77.json")
    d=json.load(open('notes77.json')); d={k:v.replace(' ',' ') for k,v in d.items()}
    for k,v in d.items():
        if v and v[0].islower(): d[k]=v[0].upper()+v[1:]
    json.dump(d,open('notes77.json','w'),ensure_ascii=False,indent=0)
if os.environ.get('SH'):
    for k in map(int,os.environ['SH'].split(',')): print(k,'::',N.get(k))


