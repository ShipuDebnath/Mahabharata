exec(open('gen64.py').read())
p=P[134]+'\n'+P[135]+' '+P[136]+'\n'+P[137]+'\n'+P[138]+'\n'+P[139]
R=[("like that of kimpaka.'88 O","like that of kimpaka. 188 O"),("“Duryodhana said, “You, Drona","‘“Duryodhana said, ‘You, Drona"),("Kritavarma,!89 Sudakshina","Kritavarma, 189 Sudakshina"),("““Bhishma replied, ‘O king! O Kourava!","‘“Bhishma replied, ‘O king! O Kourava!"),("protect- ed","protected"),("Sharnga bow.!9! © son! O ore learned","Sharnga bow. 191 O son! O one learned"),("the grandfather! 92 on","the grandfather 192 on"),("Prajapati!93 saw","Prajapati 193 saw"),
("“Brahma, supreme among those","‘“‘Brahma, supreme among those"),("Create the god Samkarshana! out","Create the god Samkarshana 194 out"),("out of your own self.!’?5 Aniruddha","out of your own self. 195 Aniruddha"),("upholder of the universe.!9© I have","upholder of the universe. 196 I have"),("That is what the brahmanas sing.””’””","That is what the brahmanas sing.”’”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(187,197)))
mk(921,P[i].split('\n'),187,196)
