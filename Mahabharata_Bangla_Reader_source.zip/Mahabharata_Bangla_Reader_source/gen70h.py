exec(open('gen70.py').read())
p=P[38]+'\n'+P[39]
R=[("as angry as a fire.48 How","as angry as a fire. 48 How"),("met the king*? and","met the king 49 and"),("Shatanika>9 Virata","Shatanika, 50 Virata"),("to Yama’s eternal abode.”","to Yama’s eternal abode.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[48,49,50])
mk(1106,P[i].split('\n'),48,50)
