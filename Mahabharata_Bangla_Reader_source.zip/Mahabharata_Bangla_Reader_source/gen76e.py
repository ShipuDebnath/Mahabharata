exec(open('gen76.py').read())
p=dh('\n'.join(P[27:29]))
R=[("his disciples, Rama,2? with","his disciples, Rama, 29 with"),("was to take place 20 On seeing","was to take place. 30 On seeing"),("Krishna and Pandava>! and","Krishna and Pandava 31 and"),("time of Shravana.>~ O Madhava!>> I wish","time of Shravana. 32 O Madhava! 33 I wish"),("immensely strong son>* and","immensely strong son 34 and"),("\n‘ “O descendant of the Bharata lineage! Dharma’s","\n“O descendant of the Bharata lineage! Dharma’s"),("an end to the enmity.” ’","an end to the enmity.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(29,35)))
mk(1252,P[i].split('\n'),29,34)
