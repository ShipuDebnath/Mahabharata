/* ===== NAV module: 18-parva index, full-text search, in-chapter highlight, character presence ===== */
const NAV=(()=>{
const MAHA=[
 [1,'আদি পর্ব','Adi Parva',1,19,'কুরুবংশের উৎপত্তি, পাণ্ডব ও কৌরবদের জন্ম ও শৈশব, জতুগৃহ, দ্রৌপদীর স্বয়ংবর, ইন্দ্রপ্রস্থ ও খাণ্ডবদাহ।'],
 [2,'সভা পর্ব','Sabha Parva',20,28,'ময়দানবের সভা, রাজসূয় যজ্ঞ, শিশুপালবধ, পাশাখেলা, দ্রৌপদীর অপমান ও বনবাসের সূচনা।'],
 [3,'বন পর্ব (আরণ্যক)','Vana (Aranyaka) Parva',29,44,'বারো বছরের বনবাস, তীর্থযাত্রা, নল-দময়ন্তী, রামোপাখ্যান, সাবিত্রী-সত্যবান ও যক্ষপ্রশ্ন।'],
 [4,'বিরাট পর্ব','Virata Parva',45,48,'বিরাটরাজ্যে ছদ্মবেশে অজ্ঞাতবাস, কীচকবধ, গোহরণ ও উত্তরার বিবাহ।'],
 [5,'উদ্যোগ পর্ব','Udyoga Parva',49,59,'যুদ্ধের প্রস্তুতি, শান্তির দৌত্য, কৃষ্ণের হস্তিনাপুর যাত্রা, বিদুরনীতি ও সনৎসুজাত।'],
 [6,'ভীষ্ম পর্ব','Bhishma Parva',60,64,'কুরুক্ষেত্রের প্রথম দশ দিন, ভগবদ্গীতা ও শরশয্যায় ভীষ্মের পতন।'],
 [7,'দ্রোণ পর্ব','Drona Parva',65,72,'দ্রোণের সেনাপতিত্ব, অভিমন্যুবধ, জয়দ্রথবধ, ঘটোৎকচবধ ও দ্রোণের মৃত্যু।'],
 [8,'কর্ণ পর্ব','Karna Parva',73,73,'কর্ণের সেনাপতিত্ব, দুঃশাসনবধ এবং অর্জুনের হাতে কর্ণের মৃত্যু।'],
 [9,'শল্য পর্ব','Shalya Parva',74,77,'শল্যের সেনাপতিত্ব ও মৃত্যু, দুর্যোধনের হ্রদে আত্মগোপন, বলরামের তীর্থযাত্রা ও গদাযুদ্ধ।'],
 [10,'সৌপ্তিক পর্ব','Souptika Parva',78,79,'রাতের শিবিরে অশ্বত্থামার হত্যাকাণ্ড ও ব্রহ্মশির অস্ত্র।'],
 [11,'স্ত্রী পর্ব','Stri Parva',80,83,'নারীদের বিলাপ, গান্ধারীর অভিশাপ ও মৃতদের তর্পণ।'],
 [12,'শান্তি পর্ব','Shanti Parva',84,86,'শরশয্যায় ভীষ্মের উপদেশ: রাজধর্ম, আপদ্ধর্ম ও মোক্ষধর্ম।'],
 [13,'অনুশাসন পর্ব','Anushasana Parva',87,88,'দানধর্মের উপদেশ এবং ভীষ্মের স্বর্গারোহণ।'],
 [14,'আশ্বমেধিক পর্ব','Ashvamedhika Parva',89,89,'অনুগীতা, পরীক্ষিতের জন্ম ও যুধিষ্ঠিরের অশ্বমেধ যজ্ঞ।'],
 [15,'আশ্রমবাসিক পর্ব','Ashramavasika Parva',90,92,'ধৃতরাষ্ট্র, গান্ধারী, কুন্তী ও বিদুরের বনবাস, মৃত পুত্রদের দর্শন ও দাবানলে মৃত্যু।'],
 [16,'মৌষল পর্ব','Mousala Parva',93,93,'মুষলযুদ্ধে যদুবংশের ধ্বংস, কৃষ্ণ ও বলরামের দেহত্যাগ এবং দ্বারকার নিমজ্জন।'],
 [17,'মহাপ্রস্থানিক পর্ব','Mahaprasthanika Parva',94,94,'পাণ্ডব ও দ্রৌপদীর হিমালয়যাত্রা, পথে পতন এবং কুকুররূপী ধর্মের পরীক্ষা।'],
 [18,'স্বর্গারোহণ পর্ব','Svargarohana Parva',95,95,'স্বর্গ ও নরক দর্শন, প্রিয়জনদের সঙ্গে মিলন এবং মহাভারতের সমাপ্তি।']];
const enL=()=>typeof isEn==='function'&&isEn();
function sectionsOf(a,b){const out=[];for(const {part,parva} of allParvas())if(parva.no>=a&&parva.no<=b)out.push({part,parva});return out}
function mahaOfSection(no){return MAHA.find(m=>no>=m[3]&&no<=m[4])}
function mahaparvaHTML(){
 let tot=0,done=0;
 const cards=MAHA.map(m=>{const secs=sectionsOf(m[3],m[4]);const chs=secs.flatMap(x=>x.parva.chapters).filter(c=>c.no>0);const d=chs.filter(c=>S.completed.includes(c.id)).length;tot+=chs.length;done+=d;
  const first=chs[0],last=chs.at(-1);const uniq=[];secs.forEach(x=>{if(!uniq.some(u=>u.parva.no===x.parva.no))uniq.push(x)});
  return `<article class="nav-maha card"><div class="nav-maha-no">${bn(m[0])}</div><div class="nav-maha-body"><div class="nav-maha-head"><h2>${E(m[1])}</h2><span class="muted">${E(m[2])}</span></div><p>${E(m[5])}</p><div class="nav-maha-meta"><span class="cx-tag">অধ্যায় ${first?bn(first.no):''}–${last?bn(last.no):''}</span><span class="cx-tag">${bn(chs.length)} অধ্যায়</span><span class="cx-tag">${bn(uniq.length)}টি উপপর্ব</span>${d?`<span class="cx-tag">পড়া হয়েছে ${bn(d)}</span>`:''}</div><div class="nav-chips">${secs.map(x=>`<button class="nav-chip" data-action="navigate" data-page="parva" data-id="${E(x.parva.id)}" title="${E(x.part.title)}">${bn(x.parva.no)}. ${E(x.parva.title)}${secs.filter(y=>y.parva.no===x.parva.no).length>1?` <small>(${E(x.part.title)})</small>`:''}</button>`).join('')}</div>${first?`<div class="row" style="margin-top:10px"><button class="button sm primary" data-action="navigate" data-page="chapter" data-id="${E(first.id)}">${I('book')} প্রথম অধ্যায় থেকে পড়ুন</button><button class="button sm" data-action="navigate" data-page="parva" data-id="${E(secs[0].parva.id)}">উপপর্বগুলো দেখুন ${I('arrow-right')}</button></div>`:''}${d?`<div class="nav-prog"><i style="width:${Math.round(100*d/chs.length)}%"></i></div>`:''}</div></article>`});
 return `<div class="container stack">${breadcrumbs([{page:'home',label:'হোম'}])}<div><div class="eyebrow">THE EIGHTEEN PARVAS</div><h1 class="page-title">অষ্টাদশ পর্ব · সম্পূর্ণ সূচি</h1><p class="page-lead">মহাভারতের প্রচলিত ১৮টি মহাপর্ব, প্রতিটির ভেতরের উপপর্ব (দেবরায়ের ৯৫টি বিভাগ) ও অধ্যায়ের পরিসর। যেকোনো উপপর্বে ক্লিক করে সরাসরি যান।</p><div class="nav-maha-sum"><span class="cx-tag">১৮ মহাপর্ব</span><span class="cx-tag">৯৫ উপপর্ব</span><span class="cx-tag">${bn(tot)} অধ্যায়</span><span class="cx-tag">পড়া হয়েছে ${bn(done)}</span></div></div><div class="nav-maha-grid">${cards.join('')}</div></div>`}

/* ---------- search ---------- */
let cache=null,cacheEn=null,building=null,limit=40,vol='all',useEn=false,onlyMain=false,timer=null,lastKey='';
const norm=s=>String(s||'').normalize('NFC').replace(/[‌‍]/g,'').toLocaleLowerCase();
async function build(){if(cache)return cache;if(building)return building;building=(async()=>{const c=[];for(const x of allChapters()){const t=await getText(x.ch.id);if(t&&t.trim()){const n=norm(t);const k=n.indexOf('---টীকা---');c.push({x,n,k:k<0?n.length:k})}}cache=c;building=null;return c})();return building}
function buildEn(){if(cacheEn)return cacheEn;cacheEn=[];for(const x of allChapters()){const t=BUNDLED_EN[x.ch.id];if(t){const n=norm(t);const k=n.indexOf('---notes---');cacheEn.push({x,n,k:k<0?n.length:k})}}return cacheEn}
function searchHTML(){cache=null;cacheEn=null;limit=40;const vols=S.parts.map((p,i)=>`<option value="${E(p.id)}" ${vol===p.id?'selected':''}>${E(p.title)}</option>`).join('');
 return `<div class="container narrow stack">${breadcrumbs([{page:'home',label:'হোম'}])}<div><div class="eyebrow">SEARCH THE MAHABHARATA</div><h1 class="page-title">গ্রন্থে অনুসন্ধান</h1><p class="page-lead">সম্পূর্ণ ১৯৯৫টি অধ্যায়ের মূল পাঠ ও টীকায় খুঁজুন। ফলাফলে ক্লিক করলে অধ্যায় খুলবে এবং শব্দটি চিহ্নিত থাকবে।</p></div><div class="search-wrap">${I('search')}<input id="searchInput" type="search" placeholder="যেমন: দ্রৌপদী, গাণ্ডীব, সাবিত্রী, অধ্যায় ১২..." autocomplete="off" value="${E(searchQuery)}"><button class="iconbtn" data-action="clear-search" title="মুছে ফেলুন">${I('x')}</button></div><div class="nav-sopts"><label>খণ্ড <select id="navVol"><option value="all">সব খণ্ড</option>${vols}</select></label><label><input type="checkbox" id="navMain" ${onlyMain?'checked':''}> টীকা বাদ দিন</label><label><input type="checkbox" id="navEn" ${useEn?'checked':''}> ইংরেজি মূল পাঠে খুঁজুন</label></div><div class="nav-suggest">${['কৃষ্ণ','দ্রৌপদী','কর্ণ','গাণ্ডীব','ভগবদ্গীতা','সাবিত্রী','শকুন্তলা','নল','যক্ষ','অশ্বমেধ'].map(w=>`<button class="nav-chip" data-navq="${E(w)}">${E(w)}</button>`).join('')}</div><div id="searchResult"></div></div>`}
function excerpt(n,ix,ql){const a=Math.max(0,ix-60),b=Math.min(n.length,ix+ql+90);return (a?'…':'')+E(n.slice(a,ix))+'<mark>'+E(n.slice(ix,ix+ql))+'</mark>'+E(n.slice(ix+ql,b))+(b<n.length?'…':'')}
async function search(){const target=$('#searchResult');if(!target)return;const raw=searchQuery.trim();const q=norm(raw);
 if(!q){target.innerHTML=`<div class="empty"><div class="empty-icon">${I('search')}</div><h3>কী খুঁজতে চান?</h3><p>চরিত্র, স্থান, অস্ত্র, ঘটনা বা যেকোনো শব্দ লিখুন। খণ্ড বেছে ফলাফল সংকুচিত করতে পারেন; ইংরেজি নামেও খোঁজা যাবে।</p></div>`;return}
 const key=[q,vol,useEn,onlyMain,limit].join('|');lastKey=key;
 if(!useEn&&!cache)target.innerHTML='<p class="muted">সূচি তৈরি হচ্ছে…</p>';
 const C=useEn?buildEn():await build();if(lastKey!==key)return;
 const meta=[];{const m=raw.match(/^(?:অধ্যায়|chapter|ch)?\s*([০-৯0-9]+)$/i);if(m){const no=Number(m[1].replace(/[০-৯]/g,d=>'০১২৩৪৫৬৭৮৯'.indexOf(d)));const x=allChapters().find(y=>y.ch.no===no);if(x)meta.push(`<button class="search-result" data-action="navigate" data-page="chapter" data-id="${E(x.ch.id)}"><b>${E(x.ch.title)}</b><small>${E(x.parva.title)} · ${E(x.part.title)}</small></button>`)}}if(!useEn){for(const {part,parva} of allParvas())if(norm(parva.title+' '+parva.en+' '+parva.no).includes(q)&&(vol==='all'||part.id===vol))meta.push(`<button class="search-result" data-action="navigate" data-page="parva" data-id="${E(parva.id)}"><b>${E(parva.title)}</b><small>উপপর্ব · ${E(part.title)}</small></button>`);
  for(const x of allChapters())if(x.ch.no&&norm(x.ch.title).includes(q)&&(vol==='all'||x.part.id===vol)&&meta.length<30)meta.push(`<button class="search-result" data-action="navigate" data-page="chapter" data-id="${E(x.ch.id)}"><b>${E(x.ch.title)}</b><small>শিরোনামে মিল · ${E(x.parva.title)}</small></button>`)}
 const hits=[];let total=0;const perVol={};
 for(const r of C){if(vol!=='all'&&r.x.part.id!==vol)continue;const lim=onlyMain?r.k:r.n.length;let ix=r.n.indexOf(q),c=0,first=-1;while(ix>=0&&ix<lim){if(first<0)first=ix;c++;ix=r.n.indexOf(q,ix+q.length)}if(c){hits.push({r,c,first});total+=c;perVol[r.x.part.id]=(perVol[r.x.part.id]||0)+1}}
 const volBar=S.parts.map(p=>perVol[p.id]?`<button class="nav-chip ${vol===p.id?'on':''}" data-navvol="${E(p.id)}">${E(p.title)} <b>${bn(perVol[p.id])}</b></button>`:'').join('');
 let h='';if(meta.length)h+=`<div class="eyebrow" style="margin:6px 0">নাম ও শিরোনামে মিল</div><div class="card" style="padding:0;overflow:hidden">${meta.slice(0,30).join('')}</div>`;
 if(hits.length||!meta.length)h+=`<div class="nav-ssum"><b>${bn(hits.length)}</b>টি অধ্যায়ে মোট <b>${bn(total)}</b> বার পাওয়া গেছে${vol!=='all'?` <button class="nav-chip" data-navvol="all">সব খণ্ড দেখুন</button>`:''}</div>${hits.length&&vol==='all'?`<div class="nav-chips">${volBar}</div>`:''}`;
 if(hits.length){h+=`<div class="card" style="padding:0;overflow:hidden">${hits.slice(0,limit).map(({r,c,first})=>`<button class="search-result" data-action="navigate" data-page="chapter" data-id="${E(r.x.ch.id)}" data-hl="${E(raw)}"><b>${E(useEn&&EN_META[r.x.ch.no]?'Chapter '+r.x.ch.no+' — '+EN_META[r.x.ch.no].t:r.x.ch.title)}</b><small>${E(r.x.parva.title)} · ${E(r.x.part.title)} · ${bn(c)} বার${first>=r.k?' · টীকায়':''}</small><p>${excerpt(r.n,first,q.length)}</p></button>`).join('')}</div>`;if(hits.length>limit)h+=`<div class="row" style="justify-content:center;margin-top:10px"><button class="button" data-navmore="1">আরও ${bn(Math.min(40,hits.length-limit))}টি দেখান (বাকি ${bn(hits.length-limit)})</button></div>`}
 else if(!meta.length)h+='<div class="empty">কোনো মিল পাওয়া যায়নি। অন্য বানানে, কম অক্ষরে বা ইংরেজিতে চেষ্টা করুন।</div>';
 target.innerHTML=h}
function schedule(){clearTimeout(timer);timer=setTimeout(()=>{limit=40;search()},180)}
document.addEventListener('change',e=>{if(e.target.id==='navVol'){vol=e.target.value;limit=40;search()}else if(e.target.id==='navEn'){useEn=e.target.checked;limit=40;search()}else if(e.target.id==='navMain'){onlyMain=e.target.checked;limit=40;search()}});
document.addEventListener('click',e=>{const t=e.target.closest('[data-navq],[data-navvol],[data-navmore],[data-hl],[data-navhl]');if(!t)return;
 if(t.dataset.navq!==undefined){searchQuery=t.dataset.navq;const i=$('#searchInput');if(i)i.value=searchQuery;limit=40;search()}
 else if(t.dataset.navvol!==undefined){vol=t.dataset.navvol;const s=$('#navVol');if(s)s.value=vol;limit=40;search()}
 else if(t.dataset.navmore){limit+=40;search()}
 else if(t.dataset.hl!==undefined){hl=t.dataset.hl}
 else if(t.dataset.navhl==='next')step(1);else if(t.dataset.navhl==='prev')step(-1);else if(t.dataset.navhl==='close')clearHL()},true);

/* ---------- highlight inside chapter ---------- */
let hl='',marks=[],cur=-1;
function clearHL(){marks.forEach(m=>{const t=document.createTextNode(m.textContent);m.replaceWith(t)});marks=[];cur=-1;hl='';document.getElementById('navHlBar')?.remove()}
function step(d){if(!marks.length)return;marks[cur]?.classList.remove('cur');cur=(cur+d+marks.length)%marks.length;const m=marks[cur];m.classList.add('cur');m.scrollIntoView({block:'center',behavior:'smooth'});const c=document.getElementById('navHlCount');if(c)c.textContent=bn(cur+1)+' / '+bn(marks.length)}
function applyHL(){const q=norm(hl);if(!q)return;marks=[];cur=-1;const roots=[...document.querySelectorAll('#readerText, .chapter-notes')];
 for(const root of roots){const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);const nodes=[];while(w.nextNode())nodes.push(w.currentNode);
  for(const n of nodes){const v=n.nodeValue;const l0=norm(v);const lv=l0.length===v.length?l0:v.toLocaleLowerCase();let ix=lv.indexOf(q);if(ix<0)continue;const frag=document.createDocumentFragment();let p=0;while(ix>=0){frag.append(v.slice(p,ix));const mk=document.createElement('mark');mk.className='nav-hl';mk.textContent=v.slice(ix,ix+q.length);frag.append(mk);marks.push(mk);p=ix+q.length;ix=lv.indexOf(q,p)}frag.append(v.slice(p));n.replaceWith(frag)}}
 if(!marks.length)return;const bar=document.createElement('div');bar.id='navHlBar';bar.className='nav-hlbar';bar.innerHTML=`<span>“${E(hl)}”</span><b id="navHlCount"></b><button data-navhl="prev" title="আগের">▲</button><button data-navhl="next" title="পরের">▼</button><button data-navhl="close" title="চিহ্ন মুছুন">✕</button>`;document.body.append(bar);setTimeout(()=>step(1),60)}

/* ---------- character presence ---------- */
function presence(i){const L=(typeof CX_APP!=='undefined')&&CX_APP[i];if(!L||!L.length)return '';const nums=[];let p=0;for(const d of L){p+=d;nums.push(p)}
 const byNo={};for(const x of allChapters())byNo[x.ch.no]=x;const pv={};for(const n of nums){const x=byNo[n];if(x)pv[x.part.id]=(pv[x.part.id]||0)+1}const mx=Math.max(...Object.values(pv));
 const first=byNo[nums[0]],last=byNo[nums.at(-1)];const r=CH_DATA[i];const q=(r.bn.split(/[ (/,]/)[0]||'');
 return `<section class="nav-pres"><div class="eyebrow">এই পাঠকক্ষে উপস্থিতি</div><p><b>${bn(nums.length)}</b>টি অধ্যায়ে “${E(q)}” নামটি সরাসরি আছে${first?` · প্রথম: <button class="cx-mini" data-action="navigate" data-page="chapter" data-id="${E(first.ch.id)}" data-hl="${E(q)}">অধ্যায় ${bn(first.ch.no)}</button>`:''}${last&&last!==first?` · শেষ: <button class="cx-mini" data-action="navigate" data-page="chapter" data-id="${E(last.ch.id)}" data-hl="${E(q)}">অধ্যায় ${bn(last.ch.no)}</button>`:''}</p><div class="nav-presbars">${S.parts.map((p,k)=>`<div title="${E(p.title)}: ${bn(pv[p.id]||0)} অধ্যায়"><i style="height:${pv[p.id]?Math.max(6,Math.round(100*pv[p.id]/mx)):0}%"></i><span>${bn(k+1)}</span></div>`).join('')}</div><div class="muted tiny">খণ্ড অনুযায়ী অধ্যায়-সংখ্যা · নামের বিভক্তিসহ রূপ গোনা হয়েছে, উপনাম নয়</div><div class="nav-chips" style="margin-top:8px">${nums.slice(0,14).map(n=>byNo[n]?`<button class="nav-chip" data-action="navigate" data-page="chapter" data-id="${E(byNo[n].ch.id)}" data-hl="${E(q)}">${bn(n)}</button>`:'').join('')}${nums.length>14?`<button class="nav-chip" data-cxsearch="${E(q)}">সব ${bn(nums.length)}টি খুঁজুন →</button>`:''}</div></section>`}

function after(page,id){document.getElementById('navHlBar')?.remove();marks=[];
 if(page==='chapter'&&hl&&!enL())applyHL();hl='';
 if(page==='char'){const card=document.querySelector('.cx section.card');if(card&&!card.querySelector('.nav-pres')){const h=presence(+id);if(h){const rows=card.querySelectorAll(':scope > .cx-row');const at=rows[rows.length-1];at?at.insertAdjacentHTML('beforebegin',h):card.insertAdjacentHTML('beforeend',h)}}}}
return {mahaparvaHTML,searchHTML,search,schedule,after,mahaOfSection,MAHA};
})();
