exec(open('gen70.py').read())
p=P[168]+'\n'+P[169]
R=[("“Sanjaya said, “When that battle","‘Sanjaya said, “When that battle"),
("he wished to kill Bhima.22? He","he wished to kill Bhima. 239 He"),
("like that of Ghatotkacha.2“9 It","like that of Ghatotkacha. 240 It"),
("as swift as his.24! They","as swift as his. 241 They"),
("was like his242 and","was like his 242 and"),
("in every direction.","in every direction.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[239,240,241,242])
mk(1128,P[i].split('\n'),239,242)
