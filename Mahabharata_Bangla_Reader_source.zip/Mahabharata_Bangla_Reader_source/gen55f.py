exec(open('gen55.py').read())
for a,b in [("Tapana Virochana’! is","Tapana Virochana51 is"),("one-eyed mother.>? Earlier","one-eyed mother.52 Earlier"),("be like Rama’ and","be like Rama53 and"),("five Vedangas.** You","five Vedangas.54 You"),("a valiant Partha.”","a valiant Partha.”’")]: fx(24,a,b)
mk(806,[P[23],P[24]],51,54)
