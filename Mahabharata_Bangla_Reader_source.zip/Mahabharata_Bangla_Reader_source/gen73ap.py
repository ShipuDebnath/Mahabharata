exec(open('gen73.py').read())
p='\n'.join(P[224:230])
R=[("Dhristhadyumna angri- ly","Dhrishtadyumna angrily"),("The maharatha>~/’ brandished","The maharatha 527 brandished"),("with blood, they28 looked","with blood, they 528 looked"),
("and Drona’s enemy, 29 like Yama’s staff.","and Drona’s enemy, 529 with sharp arrows. O great king! Karna angrily dispatched a gold-decorated arrow that was like Yama’s staff."),
("\n‘“Drona’s son was extremely strong.","\n“Drona’s son was extremely strong."),("the destroyer of enemies who 530 «9 with sharp arrows. O great king! Karna angrily dispatched a gold-decorated arrow that was could rob the valour of the foe. Dhananjaya was still at a distance and Drona’s son angrily addressed him. slayer of a brahmana! Stay. Stay. You will not escape from me with your life.”","the destroyer of enemies who could rob the valour of the foe. Dhananjaya was still at a distance and Drona’s son angrily addressed him. 530 ‘O slayer of a brahmana! Stay. Stay. You will not escape from me with your life.’"),
("extremely energetic.\nThe maharatha>~! strove","extremely energetic. The maharatha 531 strove"),("to- wards","towards"),("might be before him.>22 O Indra","might be before him. 532 O Indra"),("O great king!\nShrouded by thousands","O great king! Shrouded by thousands"),("Before he>>? could","Before he 533 could"),("sev- ered","severed"),("The maharatha>~* tried","The maharatha 534 tried"),
("\n* “At this moment","\n“At this moment"),("the immensely strong one>>» made","the immensely strong one 535 made"),("was being dragged,> 36 Drona’s son. Those arrows","was being dragged, 536 the immensely strong Partha shot arrows towards Drona’s son. Those arrows"),("a duel with Partha.\nthe immensely strong Partha shot arrows towards On seeing that the brave one>»/ had","a duel with Partha. On seeing that the brave one 537 had"),("of the wind or thoughts.” ’","of the wind or thoughts.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(527,538)))
mk(1192,P[i].split('\n'),527,537)
