exec(open('gen68.py').read())
p=P[35]+' '+P[36]+'\n'+P[37]+'\n'+P[38]
R=[("the night ended. The king® 67 Dancers danced. Singers with sweet voices sang praises in honour of the Kuru lineage. There were the loud sounds arose. Panisvanikas, magadhas, madhuparkikas, vaitalikas and sutas chanted and satisfied that bull among men. of mridangas, jharjharas, bheris, panavas, anakas, gomukhas, adamvaras, shankhas and dundubhis 68 O",
"the night ended. The king, 66 that bull among men, was satisfied by the chants of panisvanikas, magadhas, madhuparkikas, vaitalikas and sutas. 67 Dancers danced. Singers with sweet voices sang praises in honour of the Kuru lineage. There arose the loud sounds of mridangas, jharjharas, bheris, panavas, anakas, gomukhas, adamvaras, shankhas and dundubhis. 68 O"),
("gar- ments","garments"),("splendid seat 59 He","splendid seat. 69 He"),("strong water./9 He","strong water. 70 He"),("fire was kept.” 1 He","fire was kept. 71 He"),
("“The king, tiger among men, entered","‘“The king, tiger among men, entered"),("golden nishka 72 one","golden nishka, 72 one"),("circumam- bulated","circumambulated"),("nandyavartas,’~ the","nandyavartas, 73 the"),("ruchakas,!* pure","ruchakas, 74 pure"),
("““O mighty-armed one! The servants","‘“O mighty-armed one! The servants"),("ar- rived","arrived"),("arghya!> and","arghya 75 and"),("honoured him with worship.”","honoured him with worship.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(66,76)))
mk(1035,P[i].split('\n'),66,75)
