exec(open('gen56.py').read())
fx(13,"“Adhokshaja!’ was","“Adhokshaja17 was"); fx(13,"lords of the earth.!® On hearing","lords of the earth.18 On hearing")
a,b=P[13].split(" Vaishampayana said, ‘When Dasharha")
mk(813,[a,"Vaishampayana said, ‘When Dasharha"+b],17,18)
