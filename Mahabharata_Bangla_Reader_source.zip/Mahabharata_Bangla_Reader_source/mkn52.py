import mknotes3,mknotes,json,re
R=[("' Yama. This entire","1 Yama. This entire"),("? Are born again","2 Are born again"),("© Has no desire","6 Has no desire"),("° Because a true brahmana","9 Because a true brahmana"),("!0 The vow of silence","10 The vow of silence"),("'! Prosperity characterizes","11 Prosperity characterizes"),("'3 Alternatively, speaking","13 Alternatively, speaking"),("'S The four Vedas","15 The four Vedas"),("'7 Meaning righteous","17 Meaning righteous"),("'8 Ancient sage","18 Ancient sage"),("'° The brahman or the paramatman.","19 The brahman or the paramatman."),("0 The brahman or the paramatman.","20 The brahman or the paramatman."),("1 Muni means","21 Muni means"),("°© The sun and the moon","26 The sun and the moon"),("°8 This is a reference to the horses","28 This is a reference to the horses"),("2° This is another shloka","29 This is another shloka"),("3! The tree is symbolic","31 The tree is symbolic"),("5° There would be no difference","35 There would be no difference"),("3° The Vedas are being compared","39 The Vedas are being compared")]
def first(t):
    for a,b in R:
        assert a in t,a; t=t.replace(a,b,1)
    t=re.sub(r'(Sections? \d+) \(',lambda m:m.group(1)+' (',t)
    return t
N,miss=mknotes3.parse(15070,15109,41,first=first)
print('miss',miss)
mknotes.fin(N,41,'notes52.json')
d=json.load(open('notes52.json')); d={k:v.replace(' ',' ') for k,v in d.items()}
d['15']=d['15'].replace('/tihasa','Itihasa');d['35']=d['35'].replace('sleeping, uriya','sleeping, turiya');json.dump(d,open('notes52.json','w'),ensure_ascii=False,indent=0)
