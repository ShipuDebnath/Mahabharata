exec(open('gen76.py').read())
p=dh('\n'.join(P[15:24]))
R=[("he replied to the king.15 ‘O Parthas","he replied to the king. 15 ‘O Parthas"),("\n‘ “Yudhisthira said, ‘O Suyodhana! It is","\n“Yudhishthira said, ‘O Suyodhana! It is"),("\n* “Duryodhana replied, ‘If you","\n“Duryodhana replied, ‘If you"),("not be the case.!7 0 mighty-armed","not be the case. 17 O mighty-armed"),("\n‘ “Yudhisthira said, ‘O Gandhari’s son!","\n“Yudhishthira said, ‘O Gandhari’s son!"),("will not remain alive today.”","will not remain alive today.’”"),("wielder of the trident, 1 stationed","wielder of the trident, 18 stationed"),("an exuding mountain.!? When","an exuding mountain. 19 When"),("Kimkara in his hand 29 His voice","Kimkara in his hand. 20 His voice"),("\n* “Duryodhana said","\n“Duryodhana said"),("\n*“Yudhishthira replied, “O Suyodhana!","\n“Yudhishthira replied, ‘O Suyodhana!"),("what else do you desire?”","what else do you desire?’”"),("llam willing","I am willing"),("Phalguna, or with you.","Phalguna, or with you. 21"),("pick up a club.” ?","pick up a club.’”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(15,22)))
mk(1250,P[i].split('\n'),15,21)
