exec(open('gen32.py').read())
def q(i): P[i]=re.sub(r'^[‘“]*““','“',P[i])
for i in range(31,39): q(i)
R={32:[('thousand eyes”? worshipped','thousand eyes 79 worshipped'),('O Maghavan!80 We','O Maghavan! 80 We'),('Vritra®! asked, “The','Vritra 81 asked, ‘The'),('the lords of the world,82 together','the lords of the world, 82 together'),('like Manmatha? personified','like Manmatha 83 personified'),('their resolution.84 The','their resolution. 84 The'),('jew- el','jewel'),('become our messenger.”','become our messenger.’”')],
34:[('lord of the wa- ters.85 O','lord of the waters. 85 O'),('for her husband.” Thus','for her husband.’ Thus'),('ask. Go immediately.” Thus','ask? Go immediately.’ Thus')],
37:[('or the rope.’86 Thus','or the rope.’ 86 Thus'),('sweetsmiling','sweet-smiling'),('‘ʻO lord of men!','‘O lord of men!'),('wa- ter','water')],
38:[('their lord,87 saw','their lord, 87 saw'),('Nala replied, “As instructed','Nala replied, ‘As instructed'),('O lords of the thirty !88 I','O lords of the thirty! 88 I'),('should be done.”','should be done.’”')]}
for i,L in R.items():
    for a,b in L: fx(i,a,b)
sp(32,'Narada said'); sp(34,'Thus addressed by Nishadha, Maghavan')
mk(348,[P[31],P[32]],79,84)
mk(349,[P[34],P[35]],85,85)
mk(350,[P[37],P[38]],86,88)
