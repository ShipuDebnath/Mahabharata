exec(open('gen70.py').read())
p=P[127]+'\n'+P[128]+'\n'+P[129]
R=[("the bow in his! 79 hand","the bow in his 179 hand"),("““O lord of the earth! In that encounter, Shikandi","“O lord of the earth! In that encounter, Shikhandi"),("The preceptor*°™ wished","The preceptor 180 wished"),("He struck him!8! with","He struck him 181 with"),("gods and the asuras.!82 The","gods and the asuras. 182 The"),("a night of destruction.!83 O","a night of destruction. 183 O"),
("the Panchalas and the 184 with a Somakas surrounded him from all sides. Similarly, your sons also surrounded that best of brahmanas large army and the battle resumed again.","the Panchalas and the Somakas surrounded him from all sides. Similarly, your sons also surrounded that best of brahmanas 184 with a large army and the battle resumed again."),
("““O king! In that encounter, rathas rushed","“O king! In that encounter, rathas rushed"),("many locusts! 85 in","many locusts 185 in"),("night and this engendered fear.”","night and this engendered fear.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(179,186)))
mk(1121,P[i].split('\n'),179,185)
