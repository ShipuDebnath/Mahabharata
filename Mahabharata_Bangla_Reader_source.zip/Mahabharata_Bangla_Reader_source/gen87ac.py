exec(open('gen87h.py').read())
NB(1718,1268,1268,fix=(("68D ebts","1268 Debts"),))
p=H(200,1718)+'\n'+J(201,204)
R=[("¢-V udhishthira asked","‘Yudhishthira asked"),("long distance away?”","long distance away?”’"),("long distance away.”","long distance away.”’"),("“Yudhishthira said, “One must","‘Yudhishthira said, “One must"),("from the act of giving.”","from the act of giving.”’"),("improper deeds— if","improper deeds—if"),("one’s own self — men","one’s own self—men"),("must be repaid.\" In due","must be repaid. 1268 In due"),("his dharma does not suffer.”","his dharma does not suffer.”’")]
run(1718,p,R,[1268],1268,1268)
