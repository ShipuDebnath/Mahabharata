import mknotes3,mknotes,json,re,os
R=[('Tin exchange', '7 In exchange'), ('°Bhurishrava.', '9 Bhurishrava.'), ("' Brahma. 12% the seven", '11 Brahma. 12 Of the seven'), ('13. Vimana.', '15 Vimana.'), ('171p Section 69', '17 In Section 69'), ('2 1 Abhimanyu Ss.', '21 Abhimanyu’s.'), ('3°This is Drona’s', '39 This is Drona’s'), ('400F the Pandavas.', '40 Of the Pandavas.'), ('4l Arjuna.', '41 Arjuna.'), ('4456 confused', '44 So confused'), ('Yudhishthira. 41Duryodhana.', 'Yudhishthira. 47 Duryodhana.'), ('5 2 Arjuna. 93 The king', '52 Arjuna. 53 The king'), ('6In Section 64', '56 In Section 64'), ('©l With his hand.', '61 With his hand.'), ('(Hara). © Bhurishrava.', '(Hara). 65 Bhurishrava.'), ('killed Shala. 62 Somadatta.', 'killed Shala. 69 Somadatta.'), ('ashvatthama. 73 Vishnu. 761 iterally', 'Ashvatthama. 75 Vishnu. 76 Literally'), ('8 lIn the sense', '81 In the sense'), ('°|The vajra.', '91 The vajra.'), ('°3These were tuskers', '93 These were tuskers'), ('100{n valour.', '100 In valour.'), ('11 l Arjuna. 1 12Duryodhana.', '111 Arjuna. 112 Duryodhana.'), ('1 l4Meaning Arjuna.', '114 Meaning Arjuna.'), ('1208 hurishrava’s brother. 12 1kripa’s sister', '120 Bhurishrava’s brother. 121 Kripa’s sister'), ('1 30Arjuna. 13 l Arjuna.', '130 Arjuna. 131 Arjuna.'), ('13 3Dhrishtadyumna :', '133 Dhrishtadyumna.'), ('gomadatta.', 'Somadatta.'), ('1 37Dhrishtadyumna.', '137 Dhrishtadyumna.'), ('1390n the Kourava side.', '139 On the Kourava side.'), ('134gince the colour', '154 Since the colour'), ('15 7Duryodhana.', '157 Duryodhana.'), ('1590ne of', '159 One of'), ('16l Sahadeva.', '161 Sahadeva.'), ('16°Chitrasena’s.', '169 Chitrasena’s.'), ('17 Mythical celestial', '171 Mythical celestial'), ('172-The Kourava', '172 The Kourava'), ('182-There were', '182 There were'), ('1 84k ripa .', '184 Kripa.'), ('1 86Dhrishtadyumna ;', '186 Dhrishtadyumna.'), ('1940f killing', '194 Of killing'), ('1 96 Abhimanyu :', '196 Abhimanyu.'), ('19° Utuka was', '199 Uluka was'), ('2007 run away.', '200 To run away.'), ('203-They ran', '203 They ran'), ('2071p the sense', '207 In the sense'), ('20° The horses', '209 The horses'), ('21 ‘However, Indra', '211 However, Indra'), ('21 2Duryodhana.', '212 Duryodhana.'), ('2192Resorting', '219 Resorting'), ('2234 nalva', '223 A nalva'), ('25 |Belonging', '251 Belonging'), ('25 3 Ayoguda i', '253 Ayoguda is an iron ball.'), ('25 © Alayudha.', '256 Alayudha.'), ('2601t was only', '260 It was only'), ('266Ẹyil spirits', '266 Evil spirits')]
def first(t):
    for a,b in R:
        if a in t: t=t.replace(a,b,1); continue
        rx=re.escape(a).replace('\\ ',r'\s?')
        m=re.search(rx,t); assert m,a; t=t[:m.start()]+b+t[m.end():]
    t=re.sub(r'(?<=\s)(\d{1,3})(?=[A-Z])',r'\1 ',t)
    t=re.sub(r'(Sections? \d+) ?\(',lambda m:m.group(1)+' (',t)
    return t
N,miss=mknotes3.parse(23100,23316,272,first=first)
print('miss',len(miss),miss)
if not miss:
    mknotes.fin(N,272,"notes70.json")
    d=json.load(open('notes70.json')); d={k:v.replace(' ',' ') for k,v in d.items()}
    for k,v in d.items():
        if v and v[0].islower(): d[k]=v[0].upper()+v[1:]
    json.dump(d,open('notes70.json','w'),ensure_ascii=False,indent=0)
if os.environ.get('SH'):
    for k in map(int,os.environ['SH'].split(',')): print(k,'::',N.get(k))
d=json.load(open('notes70.json'))
import re as _re
for k,v in d.items():
    v=_re.sub(r'\b(J|K|B|D|S|Y|V|A) (ayadratha|ritavarma|arna|rishna|hurishrava|rona|hikhandi|udhishthira|asudeva|ritra|ishnu|atyaki|uryodhana|hima|hrishtadyumna|ishku|gni|shvattahama|shvatthama)',r'\1\2',v)
    d[k]=v
FX={'27':('Asa preparatory','As a preparatory'),'36':('VVidura','Vidura'),'62':('Snecifically','Specifically'),'84':('Ndra’s bow','Indra’s bow'),'164':('Yirata','Virata'),'166':('Ajambusa','Alambusa'),'187':('Ashvattahama','Ashvatthama'),'189':('Ashvattahama','Ashvatthama'),'254':('Ujukhala','Ulukhala')}
for k,(a,b) in FX.items():
    assert a in d[k],(k,a); d[k]=d[k].replace(a,b)
json.dump(d,open('notes70.json','w'),ensure_ascii=False,indent=0)
