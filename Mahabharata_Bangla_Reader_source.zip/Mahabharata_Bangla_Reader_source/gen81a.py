exec(open('gen81.py').read())
def run(ch,p,R,auton,n1,n2,posts=()):
    for x,y in R:
        assert x in p,(ch,x); p=p.replace(x,y,1)
    P.append(p); i=len(P)-1
    auto(i,auton); mk(ch,P[i].split('\n'),n1,n2)
    for a,b in posts: post(ch,a,b)
cnt=[21,23,30,15,19,22,20,59,30,28,21,32,14,18,42,28,46]
chl=' '.join('Chapter %d(%d): %d shlokas'%(1310+k,k+9,c) for k,c in enumerate(cnt))
desc=dh(P[2][P[2].index('This section is named'):])
intro='Section Eighty-One Stri Parva: This parva has 468 shlokas and seventeen chapters. '+chl+'. '+desc
p=intro+'\n'+dh('\n'.join(P[4:6]))
run(1310,p,[("After he! heard","After he 1 heard"),("Sanjaya to yoke’ and told","Sanjaya to yoke 2 and told"),("by sorrow, he? climbed","by sorrow, he 3 climbed"),("climbed onto the chariot. ‘Gandhari was","climbed onto the chariot.\n‘Gandhari was"),
 ("words of her husband.* With Kunti","words of her husband. 4 With Kunti"),("Kshatta,> who","Kshatta, 5 who"),("they ignored each other. “The king was surrounded","they ignored each other.\n‘The king was surrounded")],[1,2,3,4,5],1,5)
run(1311,dh(P[7]),[("distance of one krosha,° they saw","distance of one krosha, 6 they saw"),("maharathas— Sharadvata","maharathas—Sharadvata"),("will come here quickly.’ They will be","will come here quickly. 7 They will be"),("their horses towards the Ganga. ‘O king! All those","their horses towards the Ganga.\n‘O king! All those")],[6,7],6,7)
