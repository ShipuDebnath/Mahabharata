exec(open('gen86bh.py').read())
NB(1676,1385,1389,fix=(("'385D aksha","1385 Daksha"),("1388K artavirya","1388 Kartavirya"),("138]ndra","1389 Indra")))
p=H(480,1676)+'\n'+J(481,483)
reps=[("6 e serpent asked, ‘","‘“The serpent asked, ‘"),("are swift.!°*°","are swift. 1385"),("““The serpent’s wife replied, ‘ʻO","‘“The serpent’s wife replied, ‘O"),("chataka bird for water.'**°","chataka bird for water. 1386"),("“The serpent said, ‘O virtuous","‘“The serpent said, ‘O virtuous"),("powerful Dashagriva'**’ fell","powerful Dashagriva 1387 fell"),("and were slain.'***","and were slain. 1388"),("the thousand-eyed one.'**°","the thousand-eyed one. 1389"),("depart as one unsuccessful.’””","depart as one unsuccessful.’”’")]
run(1676,p,reps,list(range(1385,1390)),1385,1389)
NB(1677,1390,1390)
p=H(483,1677)+'\n'+J(484,487)
reps=[("é D hishma said","‘Bhishma said"),("“The brahmana replied, ‘Know","‘“The brahmana replied, ‘Know"),("““The serpent said, ‘O virtuous","‘“The serpent said, ‘O virtuous"),("“The brahmana replied, ‘O immensely","‘“The brahmana replied, ‘O immensely"),("based on the atman,'*”’ I","based on the atman, 1390 I"),("hear about this from you.”","hear about this from you.’”’")]
run(1677,p,reps,[1390],1390,1390)
NB(1678,1391,1394,fix=(("133This seems","1393 This seems"),("1394S urya","1394 Surya")))
p=H(487,1678)+'\n'+J(488,489)
reps=[("¢¢6rqrhe brahmana said, ‘Vivasvat’s'**! chariot","‘“The brahmana said, ‘Vivasvat’s 1391 chariot"),("tell me about it.’","tell me about it.’"),("“The serpent replied, ‘Successful","‘“The serpent replied, ‘Successful"),("is at his feet.'*°?","is at his feet. 1392"),("without decay.'*°?","without decay. 1393"),("we asked Ravi,'** “O Surya!","we asked Ravi, 1394 “O Surya!")]
run(1678,p,reps,[1391,1392,1393,1394],1391,1394)
p=H(489,1679)
reps=[("666 S urya said, ‘O friend!","‘“‘Surya said, “O friend!"),("obtained the supreme objective.’ “The serpent said, ‘ʻO brahmana!","obtained the supreme objective.”’ The serpent said, ‘O brahmana!"),("circles around the earth.”","circles around the earth.’”’")]
run(1679,p,reps,[],1,0)
NB(1680,1395,1396,fix=(("'3°5Fveryone","1395 Everyone"),("'3°°Bhogavati","1396 Bhogavati")))
p=H(490,1680)+'\n'+J(491,493)
reps=[("c i brahmana said, ‘","‘“The brahmana said, ‘"),("“The serpent replied, ‘You","‘“The serpent replied, ‘You"),("“The brahmana said, ‘O immensely","‘“The brahmana said, ‘O immensely"),("can always go everywhere.'**","can always go everywhere. 1395"),("O lord of Bhoga!!™®","O lord of Bhoga! 1396"),("I seek your leave.””’","I seek your leave.’”’")]
run(1680,p,reps,[1395,1396],1395,1396)
NB(1681,1397,1399,fix=(("'3°7Chyavana","1397 Chyavana"),("'39°Parashurama","1399 Parashurama")))
p=H(493,1681)
reps=[("c B hishma said","‘Bhishma said"),("O king! He!” performed","O king! He 1397 performed"),("He!*** described","He 1398 described"),("battle with Rama,” the","battle with Rama, 1399 the"),("in accordance with unchha.” This concludes Moksha Dharma Parva and also concludes Shanti Parva. Anushasana Parva","in accordance with unchha.”’\nThis concludes Moksha Dharma Parva and also concludes Shanti Parva.")]
run(1681,p,reps,[1397,1398,1399],1397,1399)
