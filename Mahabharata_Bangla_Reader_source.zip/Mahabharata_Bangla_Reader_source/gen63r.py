exec(open('gen63.py').read())
p=P[83]+' '+P[84]+' '+P[85]+' '+P[86]
R=[("CHAPTER 891(31) 229 “The lord said, ‘You are not a detractor. 330 | will","‘“The lord said, 329 ‘You are not a detractor. 330 I will"),("with self-realization. 331 Knowing","with self-realization. 331 Knowing"),("332 Tt is","332 It is"),("destruc- tion","destruction"),("nature. 335.9 Dhananjaya!","nature. 335 O Dhananjaya!"),("Be- cause","Because"),("others as separate. 339 Worshipping as one means regarding the worshipper and the worshipped as identical. This can be called the I, who pervade","others as separate. 339 I, who pervade"),("342 o Arjuna!","342 O Arjuna!"),("sanctified heaven >49 and","sanctified heaven 345 and"),("347 © Kounteya!","347 O Kounteya!"),("attain the ancestors. 249 Those","attain the ancestors. 349 Those"),("And mine >>! attain","And mine 351 attain"),("you will attain me alone.”","you will attain me alone.’”’")]
for a,b in R:
    assert a in p,a; p=p.replace(a,b)
P.append(p); i=len(P)-1
auto(i,list(range(329,357)))
mk(891,[P[i]],329,356)
