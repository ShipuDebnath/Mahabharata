exec(open('gen73.py').read())
p='\n'.join(P[81:92])
R=[("fighing","fighting"),("mlecchas29? and","mlecchas 209 and"),("flung them down.\nOthers were","flung them down. Others were"),
("Vanga’s?10 Satyaki powerfully struck it with a fierce iron arrow. Pierced in its inner organs, it fell down. Abandoning that ele211 elephant was stationed in front of him.\nphant, he^- was about","Vanga’s 210 elephant was stationed in front of him. Satyaki powerfully struck it with a fierce iron arrow. Pierced in its inner organs, it fell down. Abandoning that elephant, he 211 was about"),
("its life.\nHaving brought","its life. Having brought"),("against Anga 212 However","against Anga. 212 However"),("pre- ceptor","preceptor"),("managing elephants.? 13 When","managing elephants. 213 When"),("the sides? 14 were","the sides 214 were"),
("shattered by a storm of thunder.\nYour elephants","shattered by a storm of thunder. Your elephants"),("The soldiers? !5 were","The soldiers 215 were"),("the soldiers,~*” the soldiers","the soldiers, 216 the soldiers"),
("\n‘ “O great king! While Sahadeva","\n“O great king! While Sahadeva"),("seemed to be laughing 217 © descendant","seemed to be laughing. 217 O descendant"),
("\n‘ “O king! While Nakula","\n“O king! While Nakula"),("be- ing","being"),("devoid of fever.’218 Having","devoid of fever.’ Having"),("O son!2!? Those","O son! 219 Those"),("en- counter, he220","encounter, he 220"),
("nothing could be seen.22! In","nothing could be seen. 221 In"),("\n‘ “Karna became wrathful","\n“Karna became wrathful"),("running away.222 Pulled","running away. 222 Pulled"),("Shakra’s bow.223 Karna","Shakra’s bow. 223 Karna"),
("\n‘ “Having abandoned him","\n“Having abandoned him"),("the commander224 The son of the suta caused carnage there.","the commander 224 advancing against the Panchalas on his chariot, a great uproar arose among the Pandavas. O great king! The son of the suta caused carnage there."),
("fleeing on their chariots.\nadvancing against the Panchalas on his chariot, a great uproar arose among the Pandavas. O great king!\nCrazy","fleeing on their chariots. Crazy"),
("roaming around.22> © venerable one!","roaming around. 225 O venerable one!"),("Surya’s son.229 There","Surya’s son. 226 There"),("rear, Showering","rear, showering"),("ma- haratha","maharatha"),
("destroyer of darkness22/ when it has attained midday.” ° scorching beings Chapter 1168(18)","destroyer of darkness 227 scorching beings when it has attained midday.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[n for n in range(209,228) if n!=218])
mk(1167,P[i].split('\n'),209,227)
