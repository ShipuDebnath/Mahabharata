exec(open('gen69.py').read())
p=P[29]+'\n'+P[30]+'\n'+P[31]+'\n'+P[32]+' '+P[33]+'\n'+P[34]
R=[("pouring a corrosive*> into the greatsouled","pouring a corrosive 45 into the great-souled"),("foremost rathas*© were","foremost rathas 46 were"),("““O descendant of the Bharata lineage! Bibhatsu","‘“O descendant of the Bharata lineage! Bibhatsu"),("Shakra weapon 47 From","Shakra weapon. 47 From"),("“O king! Thousands of angry","‘“O king! Thousands of angry"),("haematite*® flowing","haematite 48 flowing"),("many mlecchas*? on","many mlecchas 49 on"),("as poison.29 These","as poison. 50 These"),("“There were asuras skilled","‘“There were asuras skilled"),("those who lived in congregations were","those who lived in congregations 51 were"),("de- stroyed","destroyed"),("elephants.’ 2 The showers","elephants. 52 The showers"),("riv- er","river"),("towards the left.>> There","towards the left. 53 There"),("showers profusely.>+ Everywhere","showers profusely. 54 Everywhere"),("“As he advanced, Shrutayu from Ambashtha>> countered","‘“As he advanced, Shrutayu from Ambashtha 55 countered"),("OO descendant","O descendant"),("sun shrouded by clouds.”","sun shrouded by clouds.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(45,56)))
mk(1045,P[i].split('\n'),45,55)
