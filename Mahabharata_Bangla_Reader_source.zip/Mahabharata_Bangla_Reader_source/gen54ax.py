exec(open('gen54.py').read())
for a,b in [("two Krishnas~°? are","two Krishnas259 are"),("as Dhoumya”™ does","as Dhoumya260 does"),("generous one*°! place","generous one261 place"),("be bereft of fever.”","be bereft of fever.”’")]: fx(190,a,b)
mk(787,[P[190]],259,261)
