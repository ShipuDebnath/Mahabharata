exec(open('gen73.py').read())
p='\n'.join(P[312:317])
R=[("‘S anjaya said","‘Sanjaya said"),("The Kurus/0? were","The Kurus 702 were"),("Karna’s son, Sushena 103 Karna","Karna’s son, Sushena. 703 Karna"),("severed his/04 arms","severed his 704 arms"),("Hav- ing","Having"),("hors- es","horses"),("the Shinis/95 had","the Shinis 705 had"),("large arrows, he /06 severed","large arrows, he 706 severed"),
("\n““© lion among men!","\n“O lion among men!"),("being killed /07 by","being killed 707 by"),("\n‘ “During that time","\n“During that time"),("united with Parshata./08 They","united with Parshata. 708 They"),("each with three arrows./99 © venerable","each with three arrows. 709 O venerable"),("Droupa- di’s son rescued their maternal uncles” {0 with","Droupadi’s son rescued their maternal uncles 710 with"),
("boats on an ocean. ““The bull among the Shini","boats on an ocean.\n“The bull among the Shini"),("his eldest son!!! with","his eldest son 711 with"),("Kripa, Bhoja,’ !2 your","Kripa, Bhoja, 712 your"),("autumn sky.\nThose rathas’!3 armoured","autumn sky. Those rathas 713 armoured"),("numbers of Marut surrounding","numbers of Maruts surrounding"),
("\n* “At that time, without any fear","\n“At that time, without any fear"),("brother of the king,” 14 showered","brother of the king, 714 showered"),("indulge in intercourse 115 With","indulge in intercourse. 715 With"),("rained down arrows on Bhima.","rained down arrows on Bhima.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(702,716)))
mk(1210,P[i].split('\n'),702,715)
