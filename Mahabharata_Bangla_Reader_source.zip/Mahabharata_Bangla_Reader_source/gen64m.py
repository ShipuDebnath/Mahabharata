exec(open('gen64.py').read())
tail=P[95].split('kanapas, ',1)[1]
p='\n'.join(P[92:95])+' '+tail
R=[("family names.!33 However","family names. 133 However"),("‘““O king! Men","‘“O king! Men"),("strewn with de134 135 goads","strewn with destroyed standards, bows, lances, javelins, clubs, maces, kampanas, 134 spears, colourful armour, kanapas, 135 goads"),("“Bhishma, Drona, Saindhava","‘“Bhishma, Drona, Saindhava"),("made the body hair stand up.”","made the body hair stand up.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(133,136)))
mk(913,P[i].split('\n'),133,135)
