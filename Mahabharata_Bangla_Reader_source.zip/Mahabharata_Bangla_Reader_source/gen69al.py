exec(open('gen69.py').read())
p=P[161]+'\n'+P[162]
R=[("heir apparent.2>/ You","heir apparent. 257 You"),("great- souled Parthas","great-souled Parthas"),("on the ground.29 8 Have","on the ground. 258 Have"),(" “He was accompanied","\n“He was accompanied"),("all the Panchalas”>? desired","all the Panchalas 259 desired"),
("en- tered","entered"),("red mountain.2©9 The","red mountain. 260 The"),("““Those maharatha","“Those maharatha"),("Panchala’s2©! arrows","Panchala’s 261 arrows"),("sever his2©2 head","sever his 262 head"),("vaitastika arrows~0 that","vaitastika arrows 263 that"),("in the battle 264 the powerful","in the battle, 264 the powerful"),("defeating him in the battle.”","defeating him in the battle.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(257,265)))
mk(1075,P[i].split('\n'),257,264)
