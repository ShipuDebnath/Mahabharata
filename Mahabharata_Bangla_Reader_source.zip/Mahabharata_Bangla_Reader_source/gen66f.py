exec(open('gen66.py').read())
p=P[24]+'\n'+P[25]+' '+P[26]+'\n'+P[27]+'\n'+P[28]
R=[("sounded many musical instruments. 36 were like shattered boats tossed Large numbers of arrows were swiftly released from Drona’s bow and they around on the giant waves of the ocean. They surrounded","sounded many musical instruments. Large numbers of arrows were swiftly released from Drona’s bow and they 36 were like shattered boats tossed around on the giant waves of the ocean. They 37 surrounded"),
("“Karna said, ‘As long as there","‘“Karna said, ‘As long as there"),("Pan- davas","Pandavas"),("dwelling in the forest.?° It","dwelling in the forest. 38 It"),("hors- es","horses"),("men, chariots?” and","men, chariots 39 and"),("The bulls among the Kurus“® have","The bulls among the Kurus 40 have"),("supreme horses with diverse hues.”","supreme horses with diverse hues.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[36,37,38,39,40])
mk(998,P[i].split("\n"),36,40)
