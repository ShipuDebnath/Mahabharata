import sys;sys.path.insert(0,'.')
import mken25 as m
from tidy5 import tidy
P=m.P
def fx(i,a,b):
    assert a in P[i],(i,a); P[i]=P[i].replace(a,b)
fx(3,'stars.O king','stars. O king')
fx(7,'Narayana, the illustrious lord of the universe, was himself born in ‘O king!','‘O king!')
p6='Having thus instructed all the gods, Shambhu Narayana, the illustrious lord of the universe, was himself born in '+P[6].strip()
fx(9,'How can the son he shown','How can the son be shown')
fx(9,'O descendant of the Kuru lineage!’ When','O descendant of the Kuru lineage! When')
fx(10,'slew a king 8 Today','slew a king. Today')
P[11]='‘'+P[11][1:]
fx(11,'with all the other kings a 260(35)','with all the other kings.')
fx(12,'accept it.O lord of Chedi,','accept it. O lord of Chedi!')
fx(13,'intermediate directions —are','intermediate directions—are')
fx(13,'kinds of beings! 3 —are','kinds of beings—are')
P[15]=P[15].replace('261(36) ','',1)
def J(*ix): return ' '.join(P[i].strip() for i in ix)
def mk(ch,paras,ns,ne):
    body=tidy('\n'.join(paras),(ns,ne))
    notes=['[%d] %s'%(k-ns+1,m.N[k]) for k in range(ns,ne+1)]
    open('en/ch-%d.txt'%ch,'w',encoding='utf-8').write(body+'\n---NOTES---\n'+'\n'.join(notes)+'\n')
    print(ch,len(body.split()),'words',len(notes),'notes',len(body.split('\n')),'paras')
mk(258,[J(0,1),P[3],P[4]+' '+p6,P[7]],1,4)
mk(259,[P[9],P[10],P[11]],5,9)
mk(260,[P[12],P[13],P[14]],10,14)
mk(261,[P[15],P[16]],15,17)
