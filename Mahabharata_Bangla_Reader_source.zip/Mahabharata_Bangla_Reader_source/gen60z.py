exec(open('gen60.py').read())
for a,b in [("Kounteya! 12 summoned","Kounteya112 summoned"),("Goutama!!3 said","Goutama113 said"),("with the hunter.!!4 At","with the hunter.114 At"),("in Vedanta” ~ and","in Vedanta115 and"),("Yuyudhana,! 16 Parshata","Yuyudhana,116 Parshata"),("O Kourava! 117 I know this.”","O Kourava!117 I know this.”’")]: fx(107,a,b)
mk(858,[P[107]],112,117)
