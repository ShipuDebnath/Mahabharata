exec(open('gen87vh.py').read())
NB(1783,250,252,fix=(("2500n the","250 On the"),("°5!Nahusha","251 Nahusha"),(">From Brahma","252 From Brahma")))
p=H(155,1783)+'\n'+J(156,160)
R=[("c vow asked","‘Yudhishthira asked"),("hurl offerings down?””?","hurl offerings down? 250 ”’"),("The lord of the gods”! worshipped","The lord of the gods 251 worshipped"),("granted a boon,” he","granted a boon, 252 he"),("stores of austeries","stores of austerities"),("asked, ‘ʻO great sage","asked, ‘O great sage"),("‘Agastya replied, ‘O great sage","‘“Agastya replied, ‘O great sage"),("““Bhrigu said","‘“Bhrigu said"),("anxiety was dispelled.”","anxiety was dispelled.”’")]
run(1783,p,R,[250,251,252],250,252,posts=[("down ”’","down?”’")])
NB(1784,253,256,fix=(("253A gastya","253 Agastya"),("?54N ahusha","254 Nahusha"),("Bhrigu.","255 Bhrigu."),("256A small","256 A small")))
p=H(160,1784)+"\n"+J(161,164)
R=[("c yous asked","‘Yudhishthira asked"),("tell me about this.”","tell me about this.”’"),("““He yoked Agastya","‘“He yoked Agastya"),("the undecaying one”? stood","the undecaying one 253 stood"),("he>** became","he 254 became"),("He*> felt","He 255 felt"),("‘““The immensely energetic Agastya","‘“The immensely energetic Agastya"),("nimeshas”° for","nimeshas 256 for"),("the lamp is ablaze.”","the lamp is ablaze.”’")]
run(1784,p,R,[253,254,255,256],253,256)
