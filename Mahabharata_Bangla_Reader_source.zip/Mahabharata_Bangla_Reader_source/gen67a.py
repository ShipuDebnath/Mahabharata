exec(open('gen67.py').read())
intro=P[0].replace('Drona Parva continued After','Drona Parva continued. After',1)+' '+P[1].replace('Abhimanyu-Vadha Parva This parva','Abhimanyu-Vadha Parva: This parva')+' '+P[2]+' '+P[3]
p=intro+'\n'+P[5]+'\n'+P[6]+'\n'+P[7]+'\n'+P[8]
R=[("constructs the chakra vyuha! and Abhimanyu","constructs the chakra vyuha 1 and Abhimanyu"),("by the samshaptakas .“ When","by the samshaptakas. 2 When"),("and rathas? from the","and rathas 3 from the"),
("ten direc- tions","ten directions"),("Bharadvaja’s son,“ they","Bharadvaja’s son, 4 they"),("praise Phalguna’s~ qualities and Keshava’s” affection","praise Phalguna’s 5 qualities and Keshava’s 6 affection"),
("““When it was morning","‘“When it was morning"),("immor- tals","immortals"),("Those who are noble’ never","Those who are noble 7 never"),
("the gandharvas È ? the serpents and the rakshasas, cannot defeat an army that is protected by Kiriti.!0 © lord! Where the yakshas, Govinda,","the gandharvas, 8 the yakshas, 9 the serpents and the rakshasas, cannot defeat an army that is protected by Kiriti. 10 O lord! Where Govinda,"),
("other than Tryambaka,** where","other than Tryambaka, 11 where"),("brave maharatha.'2 Today","brave maharatha. 12 Today"),("like the residents of a forest.”","like the residents of a forest.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(1,14)))
mk(1009,P[i].split('\n'),1,13)
