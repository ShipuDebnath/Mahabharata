exec(open('gen64.py').read())
p=P[143]+'\n'+P[144]
R=[("‘Duryodhana said, ‘In all","‘“Duryodhana said, ‘In all"),("““Bhishma replied, ‘Vasudeva","‘“Bhishma replied, ‘Vasudeva"),("sand- hyas,293 the","sandhyas, 203 the"),("undecay- ing","undecaying"),("its mountains 204 Through","its mountains. 204 Through"),("as Madhusudana.20 He","as Madhusudana. 205 He"),("three steps.206 He","three steps. 206 He"),("as Hrishikesha.20/ Know","as Hrishikesha. 207 Know"),("lord of the earth.””’","lord of the earth.’”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(203,208)))
mk(923,P[i].split('\n'),203,207)
p=P[146]+'\n'+P[147]
R=[("“Bhishma said, ‘ʻO great king!","‘“Bhishma said, ‘O great king!"),("turn towards Keshava.”","turn towards Keshava.’”"),("spent the night on a white bed.”","spent the night on a white bed.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
mk(924,P[i].split('\n'),208,207)
