exec(open('gen9xh.py').read()); setsec(90)
def GG(ch,a,b,n1,n2,fix,R,hdr=None):
    if n1<=n2: NB(ch,n1,n2,fix=fix)
    h=dh(re.sub(r'^Chapter \d+ ?\(\d+\) ?','',P[a-1])) if hdr is None else hdr
    p=h+('\n'+J(a,b-1) if b-1>a else '')
    R=[r for r in R if r[0] in p or print('skip',ch,r[0])]
    run(ch,p,R,list(range(n1,n2+1)),n1,n2)
GG(1954,35,36,71,71,(("7! Arjuna","71 Arjuna"),),
 [("c kK said, “O mighty-armed","‘Kunti said, “O mighty-armed"),("Vijaya’! is","Vijaya 71 is"),("Farlier","Earlier")])
GG(1955,36,39,72,76,(("\"Kunti","74 Kunti"),("7°A brahmi","76 A brahmi")),
 [("yoa said, ‘O supreme","Vaishampayana said, ‘O supreme"),("were ashamed.” With","were ashamed. 72 With"),("circumambulated the king”? and","circumambulated the king 73 and"),("the queen” had","the queen 74 had"),("best of the Kuru lineage” had","best of the Kuru lineage 75 had"),("\n“The Pandavas were distressed","\n‘The Pandavas were distressed"),("\n“The same day","\n‘The same day"),("a brahmi night.’° When","a brahmi night. 76 When")])
GG(1956,39,40,77,79,(("8Dhrita","78 Dhrita"),("™Shatayupa","79 Shatayupa")),
 [("yon said, ‘Following","Vaishampayana said, ‘Following"),("honoured them” and","honoured them 77 and"),("the Kourava lineage” was","the Kourava lineage 78 was"),("dwelling in the forest.” O great","dwelling in the forest. 79 O great")])
GG(1957,40,41,80,80,(("®°Purukutsa","80 Purukutsa"),),
 [("ye said, ‘The best of sages","Vaishampayana said, ‘The best of sages"),("Purukutsa,®° Mandhata","Purukutsa, 80 Mandhata")])
GG(1958,41,42,81,81,(("5!Veda","81 Veda"),),
 [("Vee said, ‘The best among","Vaishampayana said, ‘The best among"),("a rishi’s son*! and","a rishi’s son 81 and")])
GG(1959,42,43,1,0,(),
 [("yo said, “O king! When","Vaishampayana said, ‘O king! When")])
GG(1960,43,45,82,82,(("®From","82 From"),),
 [("yee said, ‘Those brave","Vaishampayana said, ‘Those brave"),("\n“They then made up","\n‘They then made up"),("kusha and kasha.*? She","kusha and kasha. 82 She")])
GG(1961,45,46,83,83,(("This is a bad","83 This is a bad"),),
 [("yee said, “The supreme","Vaishampayana said, ‘The supreme"),("nails and spikes.** The","nails and spikes. 83 The")])
GG(1962,46,47,84,86,(("“The Pandavas","84 The Pandavas"),("8¢Dhrita","86 Dhrita")),
 [("yoo said, “When they","Vaishampayana said, ‘When they"),("her, they** fell","her, they 84 fell"),("the king,*° recognized","the king, 85 recognized"),("the king’s® eyes","the king’s 86 eyes")])
GG(1963,47,48,87,94,(("88This","88 This"),("®°The king","89 The king"),("°Sahadeva","90 Sahadeva"),("*'Nakula","91 Nakula")),
 [("vo said, ‘O bull","Vaishampayana said, ‘O bull"),("of Gouri®’ personified","of Gouri 87 personified"),("the chakra as a weapon. There","the chakra as a weapon. 88 There"),("is his sister.*? This","is his sister. 89 This"),("Madravati’s younger son.’ This","Madravati’s younger son. 90 This"),("Madravati’s older son.”! This","Madravati’s older son. 91 This"),("and this is her son.” She","and this is her son. 92 She"),("partings in their hair.” They","partings in their hair. 93 They"),("the king of men.” They","the king of men. 94 They")])
