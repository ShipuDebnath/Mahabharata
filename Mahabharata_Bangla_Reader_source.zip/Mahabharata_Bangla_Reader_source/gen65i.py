exec(open('gen65.py').read())
p=P[35]+'\n'+P[36]
R=[("about what exactly had happened.","about what exactly had happened.’"),("“He is like the rising sun.44 He","‘“He is like the rising sun. 44 He"),("with a female AS which","with a female, 45 which"),("bat- tle","battle"),("what was his*® state","what was his 46 state"),("He*/ crushed","He 47 crushed"),
("He 1,48 is valiant among all archers. He is Rama equal in weapons","He is valiant among all archers. He is Rama’s 48 equal in weapons"),("in Satvata, 4? just","in Satvata, 49 just"),("in that tumult? Which","in that tumult. Which"),("gate to the mountains.-9 When","gate to the mountains. 50 When"),("state of your mind then?>! Droupadi’s","state of your mind then? 51 Droupadi’s"),
("Pandavas’s mother’s sister and desire their victory. 2 When","Pandavas’ mother’s sister and desire their victory. 52 When"),("wishing to obtain a wife, the maharatha used","wishing to obtain a wife, the maharatha 53 used"),("from his chariot. > 3 Dhrishtadyumna","from his chariot. Dhrishtadyumna"),("maharatha son>“ covered","maharatha son 54 covered"),("grew up in a single day. 5 He","grew up in a single day. 55 He"),("calmness in my own self.”","calmness in my own self.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(44,56)))
mk(986,P[i].split('\n'),44,55)
