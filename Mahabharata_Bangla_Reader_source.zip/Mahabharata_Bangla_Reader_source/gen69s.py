exec(open('gen69.py').read())
a="Drona’s son struck Vasudeva with seventy-three arrows, Arjuna with three broad-headed arrows and his standard "
b="“Duryodhana and the eight maharatha kings assigned to protect Jayadratha then surrounded Pandava."
assert P[80].strip()==a+b, P[80]
p=P[79]+'\n‘“Duryodhana and the eight maharatha kings 139 assigned to protect Jayadratha then surrounded Pandava. '+a+P[81]
R=[("filled heaven and earth.!38 There","filled heaven and earth. 138 There"),("Angiras’s descen- dant back with a hundred arrows.!4 He","Angiras’s descendant 140 back with a hundred arrows. He"),("like a mighty storm shredding clouds.”","like a mighty storm shredding clouds.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[138,139,140])
mk(1056,P[i].split('\n'),138,140)
