exec(open('gen87h.py').read())
NB(1686,34,36,fix=(("Indra.","34 Indra."),))
p=H(40,1686)+'\n'+J(41,43)
R=[("6 udhishthira said","‘Yudhishthira said"),("O grandfather! Tell me this.”","O grandfather! Tell me this.”’"),("chastiser of Paka*4 was","chastiser of Paka 34 was"),("Shakra wondered, “This bird","Shakra wondered, ‘This bird"),("had excellent offspring.”","had excellent offspring. 35"),("replied, ʻO king of the gods!","replied, ‘O king of the gods!"),("destroyer of Bala*® knew","destroyer of Bala 36 knew"),("through the parrot.”","through the parrot.”’")]
run(1686,p,R,[34,35,36],34,36)
NB(1687,37,49,fix=(("“3S oudasa","43 Soudasa"),("“SUparichara","45 Uparichara"),("“7/Vaishampayana","47 Vaishampayana")))
p=H(43,1687)+'\n'+J(44,45)
R=[("¢-W udhishthira asked","‘Yudhishthira asked"),("destiny or human endeavour?”","destiny or human endeavour?”’"),("A person who does deeds’ obtains","A person who does deeds 37 obtains"),("in the world of the gods.**","in the world of the gods. 38"),("world of the thirty gods.*?","world of the thirty gods. 39"),("do not lead to consequences.“","do not lead to consequences. 40"),("fell down on the ground.*!","fell down on the ground. 41"),("restrained by the brahmanas.**","restrained by the brahmanas. 42"),("he became a maneater.**","he became a maneater. 43"),("Ashvatthama and Rama“ were","Ashvatthama and Rama 44 were"),("Like a second Vasava, Vasu performed","Like a second Vasava, Vasu 45 performed"),("killed brahmana women.*°","killed brahmana women. 46"),("was tainted by this.*’","was tainted by this. 47"),("he became a lizard.**","he became a lizard. 48"),("overcome by old age.”","overcome by old age. 49"),("obtains the road to heaven.”","obtains the road to heaven.’”’")]
run(1687,p,R,list(range(37,50)),37,49)
NB(1688,50,55,fix=(("5That is","55 That is"),))
p=H(45,1688)+'\n'+J(46,48)
R=[("c yoo said","‘Yudhishthira said"),("auspicious deeds. Tell me.”","auspicious deeds. Tell me.”’"),("by giving one’s eyes,’ by","by giving one’s eyes, 50 by"),("one’s devotions.>!","one’s devotions. 51"),("obtains houses and beds.”","obtains houses and beds. 52"),("always sleeps alone, obtains the desired objective.","always sleeps alone, obtains the desired objective. 53"),("meant for heroes,“ he","meant for heroes, 54 he"),("A desert-like penance* ensures","A desert-like penance 55 ensures"),("all rites are fruitless.”","all rites are fruitless.”’")]
run(1688,p,R,list(range(50,56)),50,55)
