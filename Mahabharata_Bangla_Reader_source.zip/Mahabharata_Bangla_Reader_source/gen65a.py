exec(open('gen65.py').read())
intro=P[0].replace('Drona Parva Drona Parva continues','Drona Parva. Drona Parva continues',1)+' '+P[1].replace('Dronabhisheka Parva This parva','Dronabhisheka Parva: This parva')+' '+P[2]
p=intro+'\n'+P[3]+' '+P[4]+'\n'+P[5]+'\n'+P[6]+'\n'+P[7]
R=[("CHAPTER 978(1) Janamejaya asked","Janamejaya asked"),("had been killed! by Shikhandi","had been killed 1 by Shikhandi"),("what did Kouravya” do?","what did Kouravya 2 do?"),
("could find no peace. Kouravya> son,4 pure in soul, again came before him.","could find no peace. Kouravya 3 was overcome by anxiety and sorrow. The king continually reflected on his misery. Gavalgana’s son, 4 pure in soul, again came before him."),
("lamented in woe and asked... was overcome by anxiety and sorrow. The king continually reflected on his misery. Gavalgana’s ‘Dhritarashtra asked, “O son! The Kurus","lamented in woe and asked.’\n‘Dhritarashtra asked, “O son! 5 The Kurus"),
("or a beautiful woman who is a widow","or a beautiful woman 6 who is a widow"),("“The Kouravas then remembered Karna","‘“The Kouravas then remembered Karna"),("counted as only half a ratha.” Karna","counted as only half a ratha. 7 Karna"),("is twice that 8 Though","is twice that. 8 Though"),("leave for the forest.O Bhishma!","leave for the forest. O Bhishma!"),("from Jamadagni’s son 2 Our minds","from Jamadagni’s son. 9 Our minds"),("from extremely grave calamities.","from extremely grave calamities.”’"),
("Thus did hel0 speak","Thus did he 10 speak"),("who were wishing for victory?”","who were wishing for victory?”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(1,11)))
mk(978,P[i].split('\n'),1,10)
