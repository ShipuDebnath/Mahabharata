exec(open('gen87vh.py').read())
NB(1744,34,39,fix=(("Rice mixed with milk","35 Rice mixed with milk"),("Actually, the text","38 Actually, the text")))
p=H(15,1744)+'\n'+J(16,19)
R=[("¢ VY udhishthira said","‘Yudhishthira said"),("conjunctions of nakshatras,**","conjunctions of nakshatras, 34"),("must be thought of.”","must be thought of.”’"),("with payasam™ and","with payasam 35 and"),("Under Somadaivata,","Under Somadaivata, 36"),("gives krisara*’mixed","gives krisara 37 mixed"),("gives rice? mixed","gives rice 38 mixed"),("gives rajamasha,” he","gives rajamasha, 39 he"),("a large number of cows.’”","a large number of cows.’"),("told her daughters-in-law.””","told her daughters-in-law.”’")]
run(1744,p,R,list(range(34,40)),34,39)
NB(1745,40,40)
p=H(19,1745)
R=[("é D hishma said, “The illustrious Atri","‘Bhishma said, “The illustrious Atri"),("O brahmana!“ He is","O brahmana! 40 He is"),("the illustrious rishi, Shandilya.’”’","the illustrious rishi, Shandilya.”’")]
run(1745,p,R,[40],40,40)
