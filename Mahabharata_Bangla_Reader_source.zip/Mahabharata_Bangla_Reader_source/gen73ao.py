exec(open('gen73.py').read())
p=P[222]
R=[("advancing towards Pandava.>2© Behold","advancing towards Pandava. 526 Behold"),("roars like lions’ were","roars like those of lions were"),("death to retreat.” ’","death to retreat.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[526])
mk(1191,P[i].split('\n'),526,526)
