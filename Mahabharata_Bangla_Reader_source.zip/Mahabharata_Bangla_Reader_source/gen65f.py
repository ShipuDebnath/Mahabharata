exec(open('gen65.py').read())
p=P[26]+'\n'+P[27]+'\n'+P[28]
R=[("“Drona instructed that our vyuha should be in the form of a cart.28 O king! O descendant of the Bharata lin- eage! The vyuha of the enemy was in the form of a curlew.2? Cheerfully","‘“Drona instructed that our vyuha should be in the form of a cart. 28 O king! O descendant of the Bharata lineage! The vyuha of the enemy was in the form of a curlew. 29 Cheerfully"),
("Vishvaksena~™ and","Vishvaksena 30 and"),("This was the hump?! of","This was the hump 31 of"),("Va- sudeva","Vasudeva"),("four kinds of energy? were","four kinds of energy 32 were"),
("““Bharadvaja’s maharatha son powerfully","‘“Bharadvaja’s maharatha son powerfully"),("vul- tures","vultures"),("on the soldiers.>> Jackals","on the soldiers. 33 Jackals"),("drink the blood.34 Flaming","drink the blood. 34 Flaming"),
("When the commander of the army> tic solar disc","When the commander of the army 35 advanced, the gigantic solar disc"),("The immensely 36 advanced, the gigan- radiant and great archer?’ rushed","The immensely radiant and great archer 36 rushed"),("Yajnasena’s son,>/ skilled","Yajnasena’s son, 37 skilled"),
("army of the Pandvas like a circle of fire?® versant with sacred texts.","army of the Pandavas like a circle of fire 38 and it was wonderful. His chariot was like a city in the sky, constructed by one conversant with sacred texts."),("slaughtered the soldiers of the enemy.”","slaughtered the soldiers of the enemy.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(28,39)))
mk(983,P[i].split('\n'),28,38)
