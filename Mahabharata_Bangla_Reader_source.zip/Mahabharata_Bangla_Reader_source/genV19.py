exec(open('gen87vh.py').read())
NB(1767,155,162,fix=(("155This","155 This"),("'S6Tn their","156 In their"),("'S7Garuda","157 Garuda"),("‘8S urabhi","158 Surabhi"),("'S°The text","159 The text"),("'eOVishnu","160 Vishnu"),("'olSkanda","161 Skanda"),("'©2Pavaka","162 Pavaka")))
p=H(105,1767)+'\n'+J(106,108)
R=[("N said, “The grandfather","‘Yudhishthira said, “The grandfather"),("My curiosity is great.”","My curiosity is great.”’"),("Yajna,'*’","Yajna, 155"),("offered to the gods'*°","offered to the gods 156"),("Suparna'*’","Suparna 157"),("mother of cows! gave","mother of cows 158 gave"),("flowers and fruit.'*?","flowers and fruit. 159"),("Sudhanva!®","Sudhanva 160"),("““On seeing the lord","‘“On seeing the lord"),("The lord!®!","The lord 161"),("Pavaki'®","Pavaki 162"),("difficult for a man to obtain.”","difficult for a man to obtain.”’")]
run(1767,p,R,list(range(155,163)),155,162)
NB(1768,163,164,fix=(("'©3Before","163 Before"),("‘4K rishnapaksha","164 Krishnapaksha")))
p=H(108,1768)+'\n'+J(109,111)
R=[("c ye said, “O one with dharma","‘Yudhishthira said, “O one with dharma"),("in funeral ceremonies.”","in funeral ceremonies.”’"),("performed first.!°?","performed first. 163"),("earlier paksha.'™","earlier paksha. 164"),("superior to the forenoon.”","superior to the forenoon.”’")]
run(1768,p,R,[163,164],163,164)
