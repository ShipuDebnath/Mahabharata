exec(open('gen69.py').read())
p=P[148].replace('CHAPTER 1072(95) ','')+'\n'+P[149]+'\n'+P[150]
R=[("O son!244 We","O son! 244 We"),("Jamadagni24> were","Jamadagni 245 were"),("a trifle?24®","a trifle? 246"),("Vaivasvata2*’ has","Vaivasvata 247 has"),
("““Satyaki said, “Like","“Satyaki said, ‘Like"),("show the king.’”248 ‘Sanjaya said,","show the king.’”\n‘Sanjaya said,"),("Ya- vanas","Yavanas"),("bandits24? and","bandits 249 and"),("every- where","everywhere"),("greatsouled","great-souled"),("eight Yavana’s","eight Yavanas"),("honoured him.’”’","honoured him.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[244,245,246,247,249])
mk(1072,P[i].split('\n'),244,249)
post(1072,'trifle O one','trifle? O one')
