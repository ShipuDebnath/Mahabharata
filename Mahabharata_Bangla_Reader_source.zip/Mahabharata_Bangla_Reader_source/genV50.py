exec(open('gen87vh.py').read())
def norm(p):
    L=p.split('\n')
    for i in range(1,len(L)): L[i]='‘“'+re.sub(r'^[‘“’"]+\s*','',L[i])
    return '\n'.join(L)
NB(1813,418,418,fix=(("“18Tn hell","418 In hell"),))
p=norm(H(316,1813)+'\n'+J(317,324))
R=[("6666 D asked","‘“Uma asked"),("always attack him.*!8","always attack him. 418"),("injury towards creatures.”’””","injury towards creatures.”’”")]
run(1813,p,R,[418],418,418)
