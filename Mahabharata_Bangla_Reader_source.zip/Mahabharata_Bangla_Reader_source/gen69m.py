exec(open('gen69.py').read())
p=P[56].split('CHAPTER 1050(73) ')[1]+'\n'+P[57]+'\n'+P[58]+'\n'+P[59]+'\n'+P[60]
R=[("Yuyudhana,?> foremost","Yuyudhana, 95 foremost"),("great archer,2© supreme","great archer, 96 supreme"),("slayer of Bala.?’ He","slayer of Bala. 97 He"),("own duties.?° The","own duties. 98 The"),("Madhava’s?? supreme","Madhava’s 99 supreme"),
("“O great king! The sounds of delighted roars","‘“O great king! The sounds of delighted roars"),("They were colourful with standards and 100 and caparisons, seats and blankets.","They were colourful with standards and ornaments and with golden armour. There were vaijayanti flags 100 and caparisons, seats and blankets."),("like a net of clouds at ornaments and with golden armour. There were vaijayanti flags the end of the summer","like a net of clouds at the end of the summer"),("and flashes.!9! Those","and flashes. 101 Those"),("fore- front","forefront"),("vidyadharas!92 and","vidyadharas 102 and"),
("““Those tigers among men displayed","‘“Those tigers among men displayed"),("Dasharha!93 used","Dasharha 103 used"),("super- human","superhuman"),("mind. “This kind of strength","mind. ‘This kind of strength"),("seen in Rama,!04 Kartavirya","seen in Rama, 104 Kartavirya"),("“At that time, the sun began","‘“At that time, the sun began"),("the battle raged on.","the battle raged on.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(95,105)))
mk(1050,P[i].split('\n'),95,104)
