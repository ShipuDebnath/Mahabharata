exec(open('gen70.py').read())
p=P[107]+'\n'+P[108]+'\n'+P[109]+'\n'+P[110]
R=[("about to be con- sumed.!42 All","about to be consumed. 142 All"),("un- vanquished","unvanquished"),("penetrated the Panchalas.!43 The","penetrated the Panchalas. 143 The"),("as angry as a fire.'44 How","as angry as a fire. 144 How"),("and their followers.!4> ‘O brave","and their followers. 145 ‘O brave"),("““O bull among the Bharata lineage! A battle","“O bull among the Bharata lineage! A battle"),("the king of Panchala!4° and","the king of Panchala 146 and"),("in the night engendered great fear.”","in the night engendered great fear.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(142,147)))
mk(1116,P[i].split('\n'),142,146)
