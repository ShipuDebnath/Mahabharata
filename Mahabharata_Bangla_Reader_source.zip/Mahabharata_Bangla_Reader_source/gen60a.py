exec(open('gen60.py').read())
intro='Section Sixty Amba-Upakhyana Parva: This parva has 755 shlokas and twenty-eight chapters. '+P[1]
fx(3,"ear- lier","earlier"); fx(3,"reason for this.”!","reason for this.1”")
for a,b in [("Vi- chitravirya","Vichitravirya"),("O son!? I desired","O son!2 I desired"),("in a svayamvara All","in a svayamvara.3 All"),("lin- eage","lineage"),("as viryashulka a I raised","as viryashulka,4 I raised"),("‘ʻO kings!","‘O kings!"),("maidens for my brother.”","maidens for my brother.”’")]: fx(4,a,b)
mk(833,[intro,P[3],P[4]],1,4)
