exec(open('gen64.py').read())
p=P[215]+'\n'+P[216]+'\n'+P[217]+'\n'+P[218]
R=[("“Sanjaya said, “When the sun","‘Sanjaya said, “When the sun"),("“While all the soldiers looked on, Varshneya","‘“While all the soldiers looked on, Varshneya"),("lighteness","lightness"),("protected his flanks.28> Satvata28® swiftly","protected his flanks. 285 Satvata 286 swiftly"),("““O king! In anger, the immensely","‘“O king! In anger, the immensely"),("Somadatta’s son287 in","Somadatta’s son 287 in"),("“O king! The rathas Chitrasena","‘“O king! The rathas Chitrasena"),("be- tween vata, pitta and kapha 288 9 king!","between vata, pitta and kapha. 288 O king!"),("remem- bering","remembering"),("did not kill them.289 Bhishma","did not kill them. 289 Bhishma"),("blood flowed like water.”","blood flowed like water.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(285,290)))
mk(940,P[i].split('\n'),285,289)
