import sys,re;sys.path.insert(0,'.')
import mken87b as m
from tidy5 import tidy
P=m.P
def fx(i,a,b):
    assert a in P[i],(i,a); P[i]=P[i].replace(a,b)
def sp(i,*keys):
    for k in keys:
        assert k in P[i],(i,k); P[i]=P[i].replace(' '+k,'\n'+k,1)
def J(*ix): return ' '.join(P[i].strip() for i in ix)
def mk(ch,paras,ns,ne):
    body=tidy('\n'.join(paras),(ns,ne))
    body=re.sub(r'(?<=[A-Za-z,.;’”!?])(\d{4})(?=[\s’”,.;:!?]|$)',lambda q:'' if ns<=int(q.group(1))<=ne else q.group(0),body)
    body='\n'.join(('‘'+l if re.match(r'(Shakuni|Duryodhana|Dhritarashtra|Vidura|Yudhishthira|Bhima|Arjuna|Droupadi|Kunti|Karna)\s(said|replied|asked)',l) else l) for l in body.split('\n'))
    notes=['[%d] %s'%(k-ns+1,m.N[k]) for k in range(ns,ne+1)]
    open('en/ch-%d.txt'%ch,'w',encoding='utf-8').write(body+'\n---NOTES---\n'+'\n'.join(notes)+'\n')
    print(ch,len(body.split()),'words',len(notes),'notes',len(body.split('\n')),'paras')
def post(ch,a,b):
    f='en/ch-%d.txt'%ch; s=open(f,encoding='utf-8').read(); assert a in s,(ch,a); open(f,'w',encoding='utf-8').write(s.replace(a,b))
def auto(i,ks):
    pos=0
    for k in ks:
        m=re.compile(r'(\S) %d(?=\s|$)'%k).search(P[i],pos)
        assert m,(i,k,P[i][pos:pos+80])
        P[i]=P[i][:m.start()]+m.group(1)+str(k)+P[i][m.end():]; pos=m.start()+1
CP={'evil','mighty','co','self','well','ill','great','long','four','one','two','three','half','ever','far','many','all','sharp','golden','gold','white','red','broad','thick','large','thousand','hundred','ten','six','eight','five','seven','nine','twelve','single','iron','lion','tiger','bull','sixty','fifty','forty','thirty','twenty'}
def dh(p): return re.sub(r'(\w+)- ([a-z]\w*)', lambda m: m.group(1)+('-' if m.group(1).lower() in CP else '')+m.group(2), p)
L9=open('/mnt/user-data/uploads/bf4b53ce-Source_-_Copy.txt',encoding='utf-8').read().split('\n')
F=[l.strip() for l in L9[37468:38724] if l.strip() and l.strip()!='9999' and not __import__('re').fullmatch(r'\d{1,3}',l.strip())]
G=re.compile(r"^[\dl'°©*>?!”’“+®™»<~|\[\]\\^$#%&ʻ‘é€°]+(?= ?)")
import json as _j
def NB(ch,start,end,fix=(),split=(),merge=(),show=False):
    cur=_j.load(open('cur87b.json')); i0=cur[str(start)]
    n=end-start+1+len(merge)-len(split)
    ls=list(F[i0:i0+n])
    for x,y in fix:
        j=[i for i,l in enumerate(ls) if x in l]; assert j,(ch,x); ls[j[0]]=ls[j[0]].replace(x,y,1)
    for i in sorted(merge,reverse=True): ls[i-1]+=' '+ls.pop(i)
    out=[]
    for l in ls:
        o=G.sub('',l).strip(); o=re.sub(r"^(S[\d'’!°*”]+ ?|[¢\"'’]+)",'',o).strip(); out.append(o)
    for x in split:
        j=[i for i,l in enumerate(out) if x in l]; assert j,(ch,x); i=j[0]; k=out[i].index(x)
        a,b=out[i][:k].strip(),out[i][k:]
        b=G.sub('',b).strip(); out[i:i+1]=[a,b]
    out=[re.sub(r'(\w)- (\w)',r'\1\2',o).replace(' ',' ') for o in out]
    out=[re.sub(r'^Tn','In',re.sub(r'^Tt ','It ',re.sub(r'^Ty ','In ',o))) for o in out]
    assert len(out)==end-start+1,(ch,len(out))
    for i,o in enumerate(out): m.N[start+i]=o
    cur[str(end+1)]=i0+n; _j.dump(cur,open('cur87b.json','w'))
    if show:
        for i,o in enumerate(out): print('  N',start+i,o[:70])
    return out
def peek(start,k=12):
    cur=_j.load(open('cur87b.json')); i0=cur[str(start)]
    for i,l in enumerate(F[i0:i0+k]): print(' ',i,l[:90])
