exec(open('gen86bh.py').read())
NB(1547,198,202,fix=(("2The sage Goutama","202 The sage Goutama"),))
p=H(68,1547)+'\n'+J(69,70)
p=re.sub(r'(^|\n)[‘“]+(Namuchi replied)',r'\1‘“\2',p)
run(1547,p,[("6 hishma said","‘Bhishma said"),("is recounted. He”? was","is recounted. He 198 was"),("about that which is superior.'”? However","about that which is superior. 199 However"),("sees unhappiness in this.?” In","sees unhappiness in this. 200 In"),
("not a virtuous assembly.””! If","not a virtuous assembly. 201 If"),("he is not confused.” In","he is not confused. 202 In"),("the lord of all riches.","the lord of all riches.’”’")],list(range(198,203)),198,202)
NB(1548,203,207,fix=(("203Tn his","203 In his"),))
p=H(70,1548)+'\n'+J(71,73)
p=re.sub(r'(^|\n)[‘“]+(However, Virochana|Having been thus addressed, Shatakratu)',r'\1‘“\2',p)
run(1548,p,[("6 yo asked","‘Yudhishthira asked"),("You should tell me about it.” ‘Bhishma replied","You should tell me about it.”’\n‘Bhishma replied"),("kingship of the gods for Shatakratu.”™™ Sacrifices","kingship of the gods for Shatakratu. 203 Sacrifices"),
("of Dakshayani and Prajapati.?“ All","of Dakshayani and Prajapati. 204 All"),("for you will be completed.” You","for you will be completed. 205 You"),("find impossible to cross.” This","find impossible to cross. 206 This"),("The lord” lost","The lord 207 lost"),("and found pleasure there.”","and found pleasure there.”’")],list(range(203,208)),203,207)
