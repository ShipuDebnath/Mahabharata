exec(open('gen86bh.py').read())
NB(1549,208,230,fix=(("?08Tn heaven","208 In heaven"),("7153S uccess","215 Success"),("?20\\n auspicious","220 An auspicious"),("23D ish","223 Dish"),("2260f the","226 Of the"),('"1 Bhuti','211 Bhuti'),('*I8This','218 This')))
p=H(73,1549)+'\n'+J(74,77)
p=re.sub(r'(^|\n)[‘“]+(Shri said|Shakra asked|Shri replied)',r'\1‘“\2',p)
run(1549,p,[("6 udhishthira said","‘Yudhishthira said"),("his subsequent downfall.” ‘Bhishma replied","his subsequent downfall.”’\n‘Bhishma replied"),("the gate known as Dhruva.” The","the gate known as Dhruva. 208 The"),("with both Suparna”” and","with both Suparna 209 and"),
("who knew about everything’? also","who knew about everything 210 also"),("I am Bhuti.”!! I am Shri. I am Shraddha and Medha.” I am Sannati, Vijiti and Sthiti? I am Dhriti2'* I am Siddhi?!> I am Tvidbhuti.?!° I","I am Bhuti. 211 I am Shri. I am Shraddha and Medha. 212 I am Sannati, Vijiti and Sthiti. 213 I am Dhriti. 214 I am Siddhi. 215 I am Tvidbhuti. 216 I"),
("Niyati and Kriti.7!’ I","Niyati and Kriti. 217 I"),("I always dwell with them. They”!® kept","I always dwell with them. They 218 kept"),("and pounded ground meal.”!? They","and pounded ground meal. 219 They"),("began to blaze downwards.” Sons","began to blaze downwards. 220 Sons"),
("touched clarified butter”! Spades","touched clarified butter. 221 Spades"),("They cooked payasa,” krisara,”> meat and shashkuli™ for themselves.” They","They cooked payasa, 222 krisara, 223 meat and shashkuli 224 for themselves. 225 They"),("There was a mixture” and","There was a mixture 226 and"),
("eat at funeral ceremonies.” Every","eat at funeral ceremonies. 227 Every"),("Sannati and Kshama.””* O","Sannati and Kshama. 228 O"),("The eighth, Vritti,?” is","The eighth, Vritti, 229 is"),("steadfast dharma in their souls.’” ‘Bhishma said","steadfast dharma in their souls.’”’\n‘Bhishma said"),
("the celestial rishi.~° The","the celestial rishi. 230 The"),("about this and follow it.”","about this and follow it.”’")],list(range(208,231)),208,230)
NB(1550,231,232)
p=H(77,1550)+'\n'+J(78,79)
run(1550,p,[("¢-W udhishthira asked","‘Yudhishthira asked"),("certainly beyond nature?””*!","certainly beyond nature? 231 ”’"),("never enraged. “You are not","never enraged. ‘You are not"),("regard the two” equally","regard the two 232 equally"),("obtaining that supreme end.”","obtaining that supreme end.’”’")],[231,232],231,232,posts=[("beyond nature ”’","beyond nature?”’")])
NB(1551,233,233,fix=(("°33U grasena","233 Ugrasena"),))
p=H(79,1551)+'\n'+J(80,83)
p=re.sub(r'(^|\n)[‘“]+(Ugrasena said|Vasudeva replied)',r'\1‘“\2',p)
run(1551,p,[("é 7 udhisthira asked","‘Yudhishthira asked"),("has every kind of quality?”","has every kind of quality?”’"),("Keshava about Narada.***","Keshava about Narada. 233"),("Ugrasena said, “Behold.","Ugrasena said, ‘Behold."),("Vasudeva replied, ‘ʻO lord","Vasudeva replied, ‘O lord"),("good things should not be done.’”","good things should not be done.’”’")],[233],233,233)
