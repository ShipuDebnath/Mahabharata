exec(open('gen64.py').read())
p=P[140].split('CHAPTER 922(62) ',1)[1]+'\n'+P[141]
R=[("““Bhishma said, ‘Then","‘“Bhishma said, ‘Then"),("supreme Tat.198 He","supreme Tat. 198 He"),("srivatsa mark.!99 The","srivatsa mark. 199 The"),("Koustubha jewel 200 He","Koustubha jewel. 200 He"),("“““The gods, the gandharvas","‘“‘The gods, the gandharvas"),("O son!20! In","O son! 201 In"),("Sat- vata","Satvata"),("appropriate way,202 All","appropriate way. 202 All"),("created by Vasudeva.”””’","created by Vasudeva.’”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(197,203)))
mk(922,P[i].split('\n'),197,202)
