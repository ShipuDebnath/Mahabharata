exec(open('gen76.py').read())
p=dh(P[60])
R=[("J anamejaya asked, “O supreme","Janamejaya asked, ‘O supreme"),("I have great curiosity.’ Vaishampayana","I have great curiosity.’\nVaishampayana"),
("fell down into fire 120 The illustrious one who devours everything?! was bearing that energetic seed, the one","fell down into fire. 120 The illustrious one who devours everything 121 was incapable of destroying that eternal seed. Instead, because he was bearing that energetic seed, the one"),
("by the im- 123 was incapable of destroying that eternal seed. Instead, because he mortals. Agni’s son1?2 began","by the immortals. Agni’s son 122 began"),("The Krittikas saw the blazing","The Krittikas 123 saw the blazing"),
("name of Kartikeya.!?4 Before","name of Kartikeya. 124 Before"),("collections of weapons, not just arrows, presented themselves before him. ‘The","collections of weapons, not just arrows, presented themselves before him.\n‘The"),
("large number of bhutas.!25 The daughter of the mountains was with him.!26 Those","large number of bhutas. 125 The daughter of the mountains was with him. 126 Those"),("faces like cats.!2” There","faces like cats. 127 There"),
("were also there !28 So","were also there. 128 So"),("and his sons,!29 Vishnu","and his sons, 129 Vishnu"),("Aryama!30 and","Aryama 130 and"),("lord of the gods,!31 who","lord of the gods, 131 who"),
("He will come to me.” 132 AIl of them","He will come to me.” All of them"),("went to Vibhavasu.!33 Naigamesha","went to Vibhavasu. 133 Naigamesha"),("Rudra, the goddess, !34 Agni","Rudra, the goddess, 134 Agni")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(120,132))+[133,134])
mk(1262,P[i].split('\n'),120,134)
