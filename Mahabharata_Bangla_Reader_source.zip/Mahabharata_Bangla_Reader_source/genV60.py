exec(open('gen87vh.py').read())
NB(1827,1424,1433,fix=(("'429Sthanu","1429 Sthanu"),("141This is forced","1431 This is forced")))
p=H(359,1827)
R=[("c yoe said, “O Yudhishthira! O mighty-armed one! V Listen","‘Vasudeva said, “O Yudhishthira! O mighty-armed one! Listen"),("Ekaksha,!*","Ekaksha, 1424"),("Tryambaka,'**Vishvarupa","Tryambaka, 1425 Vishvarupa"),("Rudra.'*”°","Rudra. 1426"),("Mahadeva.'*”’","Mahadeva. 1427"),("Shiva.'*”8","Shiva. 1428"),("Sthanu.'*”?","Sthanu. 1429"),("reason be is said","reason he is said"),("Bahurupa.'*”°","Bahurupa. 1430"),("said be Dhurjati","said to be Dhurjati"),("smoke.!**!","smoke. 1431"),("Pashupati.!*?","Pashupati. 1432"),("mare-headed fire.” 1433","mare-headed fire. 1433 ”")]
run(1827,p,R,list(range(1424,1434)),1424,1433,posts=[("fire. ”","fire.”")])
NB(1828,1434,1439,fix=(("1438A cts and sacrificies","1438 Acts and sacrifices"),("'43°Vudhishthira","1439 Yudhishthira")))
p=H(360,1828)+'\n'+J(361,366)
R=[("Voce said","Vaishampayana said"),("heard.'***","heard. 1434"),("single entity!**>","single entity 1435"),("This!**° is","This 1436 is"),("behaviour'*”’","behaviour 1437"),("\n“Yudhishthira said","\n‘Yudhishthira said"),("\n“Yudhishthira asked","\n‘Yudhishthira asked"),("perception!***","perception 1438"),("Bhishma replied “Dharma","Bhishma replied, “Dharma"),("Ajatashatru!!*°°","Ajatashatru! 1439")]
run(1828,p,R,list(range(1434,1440)),1434,1439)
