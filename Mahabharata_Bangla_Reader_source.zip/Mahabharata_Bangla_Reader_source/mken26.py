import json,re,sys
sys.path.insert(0,'/home/claude/mbh')
from tidy5 import tidy
P=open('/tmp/c26.txt',encoding='utf-8').read().split('\n')
N={int(k):v for k,v in json.load(open('notes26.json',encoding='utf-8')).items()}
def mk(ch,ps,pe,ns,ne,extra_first=None):
    paras=[]
    for i in range(ps,pe+1):
        p=P[i].strip()
        p=re.sub(r'^\d{2,3} (?=(Souti|Shounaka|and sadasyas))','',p)
        paras.append(p)
    body=tidy('\n'.join(paras),(ns,ne))
    notes=['[%d] %s'%(k-ns+1,N[k]) for k in range(ns,ne+1)] if ne>=ns else []
    open('en/ch-%d.txt'%ch,'w',encoding='utf-8').write(body+'\n---NOTES---\n'+'\n'.join(notes)+'\n')
    print(ch,len(body.split()),'words',len(notes),'notes')
if __name__=='__main__':
    a=list(map(int,sys.argv[1:]))
    mk(*a)
