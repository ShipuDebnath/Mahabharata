exec(open('gen84.py').read())
def run(ch,p,R,auton,n1,n2,posts=()):
    for x,y in R:
        assert x in p,(ch,x); p=p.replace(x,y,1)
    P.append(p); i=len(P)-1
    auto(i,auton); mk(ch,P[i].split('\n'),n1,n2)
    for a,b in posts: post(ch,a,b)
def H(k,ch): return dh(re.sub(r'^Chapter %d\(\d+\) ?'%ch,'',P[k]))
def J(a,b): return dh('\n'.join(P[a:b]))
NB(1335,33)
run(1335,J(29,31),[("said, *‘Yudhishthira","said, ‘Yudhishthira"),("flesh of the earth*? have","flesh of the earth 33 have"),("Vaivasvata’s** eternal","Vaivasvata’s 34 eternal"),("When he? saw","When he 35 saw"),("by Soubala.*° Because","by Soubala. 36 Because"),("two aged ones*’ into","two aged ones 37 into"),("used such words.’ We","used such words. 38 We"),
 ("gave bad advice.*? Because","gave bad advice. 39 Because"),("Therefore, he“? is","Therefore, he 40 is"),("sense of opposites.*! O","sense of opposites. 41 O"),("birth and death.*” I will","birth and death. 42 I will"),("youngest Partha*’ replied","youngest Partha 43 replied")],list(range(33,44)),33,43)
NB(1336,44)
run(1336,H(32,1336),[("Vaishampayana said “Arjuna spoke","Vaishampayana said, ‘Arjuna spoke"),("Nahusha“ said","Nahusha 44 said"),("an inferior river* during","an inferior river 45 during"),("mighty elephants.*° O","mighty elephants. 46 O"),("their own relatives.*” If","their own relatives. 47 If"),("kinds of knowledge** and","kinds of knowledge 48 and"),
 ("and Mandhata.’? It","and Mandhata. 49 It"),("Vishvarupa*? Mahadeva","Vishvarupa 50 Mahadeva"),("known as dasharatha.>! O","known as dasharatha. 51 O"),("any other route.”","any other route.”’")],list(range(44,52)),44,51)
NB(1337,52)
run(1337,H(34,1337),[("“Yudhishthira said, “Listen","‘Yudhishthira said, “Listen"),("resorted to vanaprastha** and","resorted to vanaprastha 52 and"),("that which is unripe.’ I will","that which is unripe. 53 I will"),("four kinds of beings,>* mobile","four kinds of beings, 54 mobile"),("opposite sentiments>> that","opposite sentiments 55 that"),("in seven houses.°° But","in seven houses. 56 But"),("two to five houses.>’ I will","two to five houses. 57 I will"),
 ("dharma of the wind.>* I will","dharma of the wind. 58 I will"),("to their relatives.°? When","to their relatives. 59 When"),("the doer obtains the consequence.","the doer obtains the consequence. 60"),("desire to exist?°! A king","desire to exist 61 A king"),("body on that path.”","body on that path.”’")],list(range(52,62)),52,61,[('desire to exist A king','desire to exist? A king')])
NB(1338,62,split=('63 A reflection',))
run(1338,H(36,1338),[("faithfully accept it.°? Men","faithfully accept it. 62 Men"),("one’s own fortune® and","one’s own fortune 63 and"),("no success without action.”","no success without action.”’")],[62,63],62,63)
NB(1339,64)
run(1339,J(38,46),[("developed beards.°* Though","developed beards. 64 Though"),("‘Men who eat leftover food perform","‘Men who eat leftover food 65 perform"),("\n““The rishis replied, “Aha!","\n“The rishis replied, ‘Aha!"),("\n““The bird said, ‘I am","\n“The bird said, ‘I am"),("\n““The rishis replied, “We think","\n“The rishis replied, ‘We think"),("\n‘The bird said, ‘If","\n“The bird said, ‘If"),
 ("in your own selves, then","in your own selves, 66 then"),("\n‘“The rishis replied, ‘O father!®’ We","\n“The rishis replied, ‘O father 67 We"),("\n““The bird said, ‘The cow","\n“The bird said, ‘The cow"),("the moon and the stars.°° In","the moon and the stars. 68 In"),("with this. This® is","with this. This 69 is"),("lineage of Brahma.’° They","lineage of Brahma. 70 They"),
 ("path of non-believers”! and","path of non-believers 71 and"),("dharma of householders.’” O","dharma of householders. 72 O"),("over the entire earth.”","over the entire earth.”’")],list(range(64,73)),64,72,[('O father We will','O father! We will')])
