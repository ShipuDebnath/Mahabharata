import mknotes3,mknotes,json
R=[]
def first(t):
    for a,b in R:
        assert a in t,a; t=t.replace(a,b,1)
    return t
N,miss=mknotes3.parse(12095,12144,59,first=first)
print('miss',miss)
mknotes.fin(N,59,'notes36.json')
d=json.load(open('notes36.json'))
json.dump(d,open('notes36.json','w'),ensure_ascii=False,indent=0)
