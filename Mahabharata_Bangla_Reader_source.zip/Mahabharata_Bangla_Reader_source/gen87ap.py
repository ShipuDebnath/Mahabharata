exec(open('gen87h.py').read())
NB(1736,1338,1338)
p=H(290,1736)+"\n"+J(291,294)
R=[("666 C hyavana said, ‘Accept","‘“Chyavana said, ‘Accept"),("““Kushika said, ‘O illustrious one! O Bhargava!","‘“Kushika said, ‘O illustrious one! O Bhargava!"),("son for this. am extremely","son for this. I am extremely"),("““Chyavana replied","‘“Chyavana replied"),("and said, “I am observing a vow. You should serve me.","and said, ‘I am observing a vow. You should serve me.’"),("be a Koushika!***","be a Koushika 1338"),("““Kushika said, ‘O great sage!","‘“Kushika said, ‘O great sage!"),("Whom will I honour?”","Whom will I honour?’”’")]
run(1736,p,R,[1338],1338,1338)
NB(1737,1339,1339)
p=H(294,1737)+"\n"+J(295,296)
R=[("c ee said, ‘O bull among men!","‘“Chyavana said, ‘O bull among men!"),("will clease his soul","will cleanse his soul"),("born Visvamitra","born Vishvamitra"),("because of women.!**?","because of women. 1339"),("will be your matrimonial allies.’”","will be your matrimonial allies.’"),("who said, ‘ʻO great king!","who said, ‘O great sage!")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
i=p.index('occurred in that way.” Volume 9 ends here.'); p=p[:i]+'occurred in that way.”’'
run(1737,p,[],[1339],1339,1339)
