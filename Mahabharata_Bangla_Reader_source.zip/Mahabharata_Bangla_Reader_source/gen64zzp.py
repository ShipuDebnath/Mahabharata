exec(open('gen64.py').read())
p=P[341]+'\n'+P[342]+'\n'+P[343]
R=[("broadheaded","broad-headed"),("“““Shalya could not","‘“Shalya could not"),("Vishoka26 had","Vishoka 426 had"),("powerful Bhimsena","powerful Bhimasena"),("“The brave maharatha Bhagadatta","‘“The brave maharatha Bhagadatta"),("between Arjuna and the enemy.”","between Arjuna and the enemy.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[426])
mk(969,P[i].split('\n'),426,426)
