exec(open('gen69.py').read())
p=P[8]
R=[("Pandava king,!3 Bhishma","Pandava king, 13 Bhishma"),("by the Parthas.!4 The","by the Parthas. 14 The"),("Gudakesha!> and","Gudakesha 15 and"),("to everything that occurred.”","to everything that occurred.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[13,14,15])
mk(1039,P[i].split('\n'),13,15)
