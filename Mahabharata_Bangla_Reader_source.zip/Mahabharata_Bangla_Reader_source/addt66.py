import json,sys
# usage: addt.py file.json END   (file: {"902":[t,p,te,pe],...})
t=json.load(open('titles.json'))
for k,(a,b,c,d) in json.load(open(sys.argv[1])).items(): t[k]={"t":a,"p":b,"te":c,"pe":d}
json.dump(t,open('titles.json','w'),ensure_ascii=False,indent=1)
v=json.load(open('v2_chapters.json')); v['p5-s66']=[993,int(sys.argv[2])]; json.dump(v,open('v2_chapters.json','w'),ensure_ascii=False,indent=1)
