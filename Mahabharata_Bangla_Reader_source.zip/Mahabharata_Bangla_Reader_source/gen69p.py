exec(open('gen69.py').read())
p=P[68]+'\n'+P[69]+'\n'+P[70]+'\n'+P[71]
R=[("from Rahu’s mouth. 120 They","from Rahu’s mouth. 120 They"),("‘Krishna and Dhananjaya began","‘“Krishna and Dhananjaya began"),("This is what het?! told","This is what he 121 told"),("on their faces!22 was","on their faces 122 was"),("viru- lent","virulent"),("head to the ocean, !23 at","head to the ocean, 123 at"),("‘Having approached, they looked","‘“Having approached, they looked"),("“Having seen that Hrishikesha and Dhananjaya had crossed,!24 your","‘“Having seen that Hrishikesha and Dhananjaya had crossed, 124 your"),("Krishna and Partha.!25 © lord of men!","Krishna and Partha. 125 O lord of men!"),("to Arjuna.”","to Arjuna.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(120,126)))
mk(1053,P[i].split('\n'),120,125)
