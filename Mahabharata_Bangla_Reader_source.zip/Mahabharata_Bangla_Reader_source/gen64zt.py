exec(open('gen64.py').read())
p=P[245]+'\n'+P[246]
R=[("ele- phants","elephants"),("the traveller of the night>2° became","the traveller of the night 326 became"),("ad- vance","advance"),("The cruel one?2/ angrily","The cruel one 327 angrily"),("He bit his lip-~° and","He bit his lip 328 and"),("Dury- odhana","Duryodhana"),("the slayer of Bala>2? bringing","the slayer of Bala 329 bringing")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(326,330)))
mk(947,P[i].split('\n'),326,329)
