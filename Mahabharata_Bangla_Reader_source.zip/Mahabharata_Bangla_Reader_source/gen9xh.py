exec(open('gen9x.py').read())
def run(ch,p,R,auton,n1,n2,posts=()):
    for x,y in R:
        assert x in p,(ch,x); p=p.replace(x,y,1)
    P.append(p); i=len(P)-1
    auto(i,auton); mk(ch,P[i].split('\n'),n1,n2)
    for a,b in posts: post(ch,a,b)
def H(k,ch): return dh(re.sub(r'^Chapter %d ?\(\d+\) ?'%ch,'',P[k]))
def J(a,b): return dh('\n'.join(P[a:b]))
