exec(open('gen64.py').read())
p='\n'.join(P[36:39])
R=[("with his brothers,20 placing","with his brothers, 30 placing"),("Somadatta’s valorous son.>! They","Somadatta’s valorous son. 31 They"),("““At that, Droupadi’s","‘“At that, Droupadi’s"),("maharatha son>2 Nakula","maharatha son, 32 Nakula"),("But your father’?","But your father 33 surpassed all the other soldiers.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(30,34)))
mk(902,P[i].split('\n'),30,33)
