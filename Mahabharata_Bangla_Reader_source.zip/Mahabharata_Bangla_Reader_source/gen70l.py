exec(open('gen70.py').read())
p='\n'.join([P[67].replace('CHAPTER 1110(133) ',''),P[68],P[69],P[70],P[71],P[72]])
R=[("has arrived.!13 O","has arrived. 113 O"),("Matysas","Matsyas"),("kill Pandava.!!4 © descendant","kill Pandava. 114 O descendant"),("giving it to Vasava.!!5 © lord of the earth! Iam","giving it to Vasava. 115 O lord of the earth! I am"),("forest. 0 Kouravya!","forest. O Kouravya!"),("and give the earth to you.”","and give the earth to you.’"),("and you ran away.116 O","and you ran away. 116 O"),("younger brother. ! 17 In","younger brother. 117 In"),
("““When Sharadvata addressed","“When Sharadvata addressed"),("to Kripa. “Brave ones","to Kripa. ‘Brave ones"),("skilled in fighting.1 18 Even","skilled in fighting. 118 Even"),("Dhrish- tadyumna","Dhrishtadyumna"),("Durmukha’s son,! 19 Janamejaya","Durmukha’s son, 119 Janamejaya"),("Sudashana","Sudarshana"),("Soma- datta, Bhuri,!29 Drona’s","Somadatta, Bhuri, 120 Drona’s")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(113,121)))
mk(1110,P[i].split('\n'),113,120)
