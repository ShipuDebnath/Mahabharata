exec(open('gen87vh.py').read())
NB(1755,80,80)
p=H(49,1755)+'\n'+J(50,51)
R=[("c you said, “O lord!","‘Yudhishthira said, “O lord!"),("What are the fruits of rituals? What are the fruits of studying","What are the fruits of rituals? 80 What are the fruits of studying"),("fruits of brahmacharya?.","fruits of brahmacharya?"),("My curiosity is great.”","My curiosity is great.”’"),("obtain what they desire.O Pandava!","obtain what they desire. O Pandava!"),("he doesn’t have to see hell.”","he doesn’t have to see hell.”’")]
run(1755,p,R,[80],80,80)
