exec(open('gen53.py').read())
fx(35,'Sudarshana?” among','Sudarshana97 among'); fx(35,'bears the monkey is supreme °$ The one','bears the monkey is supreme.98 The one'); fx(35,'valour of that intelligent one.”? They','valour of that intelligent one.99 They'); fx(35,'That evil man,!” together','That evil man,100 together'); fx(35,'incapable, are pointless.”','incapable, are pointless.”’')
mk(716,[P[35]],97,100)
