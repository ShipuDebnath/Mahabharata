exec(open('gen73.py').read())
p='\n'.join(P[246:248])
R=[("\n*“Yudhishthira said, ‘O Devaki’s son!","\n“Yudhishthira said, ‘O Devaki’s son!"),("with the maharatha?570 He","with the maharatha? 570 He"),("from Rama>/! himself","from Rama 571 himself"),("after killing an asura.O Achyuta!","after killing an asura. O Achyuta!"),("Dhrish- tadyumna","Dhrishtadyumna"),("O mighty-armed one!>/2 Having","O mighty-armed one! 572 Having"),
("it was going to die 573 O lord","it was going to die. 573 O lord"),("He is like Rama>/* in weapons","He is like Rama 574 in weapons"),("sons for your sake >/5 How","sons for your sake. 575 How"),("yoked to that chariot. 7° He always","yoked to that chariot. 576 He always"),("in an encounter, O son!>/7 Has","in an encounter. O son! 577 Has"),("Dhritrarashtra’s","Dhritarashtra’s"),
("as long as Partha was alive.’ He always","as long as Partha was alive. 578 He always"),("Ku- rus","Kurus"),("spoke to Krishna>/9 and said","spoke to Krishnaa 579 and said"),("by the sun god 580 Has","by the sun god. 580 Has"),("pres- ence","presence"),("sesamum seeds earlier. 81 Has","sesamum seeds earlier. 581 Has"),("won by Soubala,> 82 the","won by Soubala, 582 the"),("censured him.>83 Has","censured him. 583 Has"),("Tell me and pacify me.’” ’","Tell me and pacify me.’”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(570,584)))
mk(1196,P[i].split('\n'),570,583)
post(1196,'with the maharatha He is','with the maharatha? He is')
