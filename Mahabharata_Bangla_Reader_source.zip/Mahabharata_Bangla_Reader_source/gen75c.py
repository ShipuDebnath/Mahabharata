exec(open('gen75.py').read())
p=dh(P[22])
R=[("as proud as Airavata’ and","as proud as Airavata 7 and"),("and the Srinjayas® could","and the Srinjayas 8 could"),("against the elephant, he? afflicted","against the elephant, he 9 afflicted"),("by the lord of the gods.” ’","by the lord of the gods.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[7,8,9])
mk(1238,P[i].split('\n'),7,9)
p=dh(P[24])
R=[("the brave ones!! returned","the brave ones 11 returned"),("performer of truthful deeds !2 and","performer of truthful deeds 12 and"),("and Madhava! was confused","and Madhava 13 was confused"),("Yuyudhana,“ skilled","Yuyudhana, 14 skilled"),("all the soldiers!> were","all the soldiers 15 were"),("and the Panchalas!© and countered","and the Panchalas 16 and countered"),("another chariot and attacked.” ’","another chariot and attacked.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(10,17)))
mk(1239,P[i].split('\n'),10,16)
