exec(open('gen71.py').read())
intro=P[0].replace('Drona-Vadha Parva This parva','Drona-Vadha Parva: This parva')+' '+P[1].replace('Chapter 1142(165): 125 shlokas This section','Chapter 1142(165): 125 shlokas. This section')
p=intro+'\n'+P[3]+'\n'+P[4]+' '+P[5]
R=[("Vaikartana.! Karna","Vaikartana. 1 Karna"),("greatsouled","great-souled"),("known as Vrisha.2 He","known as Vrisha. 2 He"),
("through my yoga, for your sake. Later,","through my yoga, for your sake. 3 Later,"),
("the performer of fierce deeds.””’","the performer of fierce deeds.’”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[1,2,3])
mk(1132,P[i].split('\n'),1,3)
