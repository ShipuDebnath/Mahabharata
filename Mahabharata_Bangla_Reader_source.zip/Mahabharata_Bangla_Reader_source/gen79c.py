exec(open('gen79.py').read())
def run(ch,p,R,auton,n1,n2,posts=()):
    for x,y in R:
        assert x in p,(ch,x); p=p.replace(x,y,1)
    P.append(p); i=len(P)-1
    auto(i,auton); mk(ch,P[i].split('\n'),n1,n2)
    for a,b in posts: post(ch,a,b)
run(1296,dh(P[17]),[("yoked on the flanks.”’ This divine","yoked on the flanks. 27 This divine"),("Vishvakarma’® and","Vishvakarma 28 and"),("Vinata’s son? was","Vinata’s son 29 was"),
 ("Kuru king, Yudhishthira.*? On either","Kuru king, Yudhishthira. 30 On either"),("Sharnga*! bow","Sharnga 31 bow"),("descending in the sky. ‘Bhimasena,","descending in the sky.\n‘Bhimasena,"),("Kounteya*” blazed","Kounteya 32 blazed"),
 ("banks of the Bhagirathi.** He had","banks of the Bhagirathi. 33 He had"),("celestial weapon on it.** In the presence","celestial weapon on it. 34 In the presence")],list(range(27,35)),27,34)
run(1297,dh(P[19]),[("grandfather of the Bharatas,*- showed","grandfather of the Bharatas, 35 showed"),("energies of the weapons. ‘The two rishis said","energies of the weapons.\n‘The two rishis said"),("Why have you invoked them?”","Why have you invoked them?”’")],[35],35,35)
run(1298,dh(P[21]),[("two energetic ones,*° who","two energetic ones, 36 who"),("for even the gods to do this.*” With","for even the gods to do this. 37 With"),("withdrawing that weapon again. ‘Drona’s son saw","withdrawing that weapon again.\n‘Drona’s son saw"),
 ("will slaughter the Parthas.” ‘Vyasa replied, “O son!? Partha","will slaughter the Parthas.”\n‘Vyasa replied, “O son 38 Partha"),("from your father.?? However","from your father. 39 However"),("Rajarshi Pandava*® does","Rajarshi Pandava 40 does"),
 ("your life in return.” ‘Drona’s son said","your life in return.”\n‘Drona’s son said"),("wombs of the Pandaveyas.”#! “Vyasa replied","wombs of the Pandaveyas.”\n‘Vyasa replied"),("Pandaveyas and desist.”’*” Vaishampayana said","Pandaveyas and desist.”’\nVaishampayana said")],[36,37,38,39,40],36,42,[('O son Partha','O son! Partha')])
p=dh('\n'.join(P[23:26]))
run(1299,p,[("Vaishampayana said, “The perpetrator","Vaishampayana said, ‘The perpetrator"),("wielder of Gandiva,** had gone","wielder of Gandiva, 43 had gone"),("name of Parikshit.’“+ The words","name of Parikshit.’ The words"),
 ("the one that you wish to protect.” “Vasudeva replied","the one that you wish to protect.”\n‘Vasudeva replied"),("energy and truth.” ‘Vyasa said","energy and truth.”\n‘Vyasa said"),("a virtuous brahmana 45 That is","a virtuous brahmana. 45 That is"),
 ("path of inferior deeds.” ‘Ashvatthama replied","path of inferior deeds.”\n‘Ashvatthama replied"),("dwell among men.*° O illustrious","dwell among men. 46 O illustrious"),("Purushottama’s*’” words come true.”","Purushottama’s 47 words come true.”’"),
 ("They saw Krishna*® Droupadi","They saw Krishna 48 Droupadi"),("yoked his mounts.*° you had","yoked his mounts, 49 you had"),("to Madhu’s slayer.~? ‘I do not","to Madhu’s slayer. 50 ‘I do not"),("fasten the gem on his head.”","fasten the gem on his head.”’"),
 ("The spirited Krishna,”! afflicted","The spirited Krishna, 51 afflicted")],[43,45,46,47,48,49,50,51],43,51)
run(1300,dh(P[27]),[("all of them in the camp?” “Vasudeva replied","all of them in the camp?”\n‘Vasudeva replied"),("the tawny locks”? saw","the tawny locks 52 saw"),("being told his father,’ ‘I will","being told his father, 53 ‘I will"),
 ("Daksha and the others.** All of them","Daksha and the others. 54 All of them"),("four kinds of beings.*> Having","four kinds of beings. 55 Having"),("preceptor of the worlds*° was pleased","preceptor of the worlds 56 was pleased"),("ʻO Sharva!","‘O Sharva!"),
 ("What will I do with this?>’ O grandfather","What will I do with this 57 O grandfather"),("foothills of Mount Munjavat.””>8","foothills of Mount Munjavat.”’")],list(range(52,58)),52,58,[('do with this O grandfather','do with this? O grandfather')])
p=dh(P[28]).replace('Chapter 1301(18) ','',1)
run(1301,p,[("the gods was over,’ the gods","the gods was over, 59 the gods"),("Krittivasa® quickly","Krittivasa 60 quickly"),("involve the five elements.°! Sacrifices","involve the five elements. 61 Sacrifices"),("Kapardi® constructed","Kapardi 62 constructed"),
 ("Vashatkara® constituted","Vashatkara 63 constituted"),("four limbs of the sacrifice .64 Therefore","four limbs of the sacrifice. 64 Therefore"),("Tryambaka® then","Tryambaka 65 then"),("Shitikantha® laughed","Shitikantha 66 laughed"),
 ("When Bhava®’ was enraged","When Bhava 67 was enraged"),("He®* was gratified with the valiant one.® That is","He 68 was gratified with the valiant one. 69 That is"),("task must be done next.” This ends Souptika Parva.","task must be done next.”’\nThis ends Souptika Parva.")],list(range(59,70)),59,69)
