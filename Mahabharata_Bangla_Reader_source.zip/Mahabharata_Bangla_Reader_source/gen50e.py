exec(open('gen50.py').read())
fx(18,'690(27)45 ‘Sanjaya said, “O Pandava!','‘Sanjaya said,45 “O Pandava!'); fx(18,'strikes itf down','strikes it46 down')
fx(19,'‘““O Indra among men','“O Indra among men'); fx(19,'transgress the limits’ O Parthas','transgress the limits.47 O Parthas'); fx(19,'road followed by the gods.”','road followed by the gods.”’')
mk(690,[P[18],P[19]],45,47)
