exec(open('gen89vh.py').read())
p=H(63,1846)+'\n'+J(64,65)
R=[("yc said, “The king","Vaishampayana said, ‘The king"),("\n“Vasudeva said","\n‘Vasudeva said"),("At scent having vanished","As scent had vanished"),("Listen.””","Listen.”’")]
run(1846,p,R,[],1,0)
NB(1847,35,42,fix=(("“lKrishnaa","41 Krishnaa"),))
p=H(65,1847)
R=[("¢ \\ 7 asudeva said","‘Vasudeva said"),("these two.’ There","these two. 35 There"),("physical qualities.°°","physical qualities. 36"),("three qualities.*’","three qualities. 37"),("being healthy.** If","being healthy. 38 If"),("remember joy.”","remember joy. 39"),("remember misery.*”","remember misery. 40"),("You saw Krishna‘!","You saw Krishna 41"),("with his foot.”","with his foot. 42"),("rule the kingdom appropriately.","rule the kingdom appropriately.”")]
run(1847,p,R,list(range(35,43)),35,42)
NB(1848,43,46,fix=(("4 Mama means","45 Mama means"),("sylla- bles","syllables")))
p=H(66,1848)
R=[("6 x zasudeva said","‘Vasudeva said"),("has two syllables. The eternal","has two syllables. 43 The eternal"),("three syllables.“","three syllables. 44"),("A lack of ownership is eternal.","A lack of ownership is eternal. 45"),("in this connection.*°","in this connection. 46")]
run(1848,p,R,list(range(43,47)),43,46)
NB(1849,47,51,fix=(("“7Krishnaa","47 Krishnaa"),))
p=H(67,1849)
R=[("yours said, “Rajarshi","Vaishampayana said, ‘Rajarshi"),("Krishna,“ Sahadeva","Krishna, 47 Sahadeva"),("Vijaya*®","Vijaya 48"),("own kingdom,”","own kingdom, 49"),("grandfather!*°","grandfather! 50"),("Gajasahvya.*'","Gajasahvya. 51")]
run(1849,p,R,list(range(47,52)),47,51)
NB(1850,52,54)
p=H(68,1850)+'\n'+J(69,71)
R=[("anamejaya asked, “O supreme","‘Janamejaya asked, “O supreme"),("tranquil. J What did","tranquil. What did"),("Dhananjaya do?’","Dhananjaya do?”"),("in Nandana.”","in Nandana. 52"),("excellent rishis,>*","excellent rishis, 53"),("O son!** The earth","O son! 54 The earth")]
run(1850,p,R,list(range(52,55)),52,54)
