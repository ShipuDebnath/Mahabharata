import mknotes3,mknotes,json,re
R=[("' Horses, elephants","1 Horses, elephants"),("> The sign of the svastika","5 The sign of the svastika"),("© Sairandhri is a maidservant","6 Sairandhri is a maidservant"),("° Kshatta has","9 Kshatta has"),("'0 Yudhishthira.","10 Yudhishthira."),("'! Droupadi.","11 Droupadi."),("'2 Because of Arjuna","12 Because of Arjuna"),("'3 Uttara’s mother","13 Uttara’s mother"),("'4 Drona.","14 Drona."),("'S The Yadavas.","15 The Yadavas."),("8 Meaning Arjuna. This is","28 Meaning Arjuna. This is"),("29 Tn the fight","29 In the fight"),("3! Arjuna.","31 Arjuna."),("3? The Kouravas.","32 The Kouravas."),("#2 Balarama","42 Balarama")]
def first(t):
    for a,b in R:
        assert a in t,a; t=t.replace(a,b,1)
    t=re.sub(r'(Sections? \d+) \(',lambda m:m.group(1)+' (',t)
    return t
N,miss=mknotes3.parse(14684,14728,46,first=first)
print('miss',miss)
mknotes.fin(N,46,'notes48.json')
d=json.load(open('notes48.json')); d={k:v.replace(' ',' ') for k,v in d.items()}
json.dump(d,open('notes48.json','w'),ensure_ascii=False,indent=0)
