exec(open('gen59.py').read())
for a,b in [("“Bhishma said, ‘ʻO great king!","‘“Bhishma said, ‘O great king!"),("he is an atiratha.?? He","he is an atiratha.33 He"),("like Maghavan** against","like Maghavan34 against"),("the rakshasas*» is","the rakshasas35 is"),("O son!*° He loves","O son!36 He loves"),("mightyarmed","mighty-armed"),("the sons of Kunti.’””","the sons of Kunti.’”’")]: fx(32,a,b)
mk(832,[P[32]],33,36)
