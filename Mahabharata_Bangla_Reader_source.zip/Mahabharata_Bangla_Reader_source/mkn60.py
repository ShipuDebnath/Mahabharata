import mknotes3,mknotes,json,re
R=[("' Shikhandi also","1 Shikhandi also"),("shulka meaning price. Dasha is a slave","shulka meaning price. 5 Dasha is a slave"),("daughter of a fisherman. Because she was dark","daughter of a fisherman. 6 Because she was dark"),("studied there. Meaning Bhishma.","studied there. 9 Meaning Bhishma."),("l0Hotravahana","10 Hotravahana"),("!21f Bhishma does not","12 If Bhishma does not"),("13Sa ges.","13 Sages."),("l14Gandharvas","14 Gandharvas"),("15 A psaras","15 Apsaras"),("2l Bhisma.","21 Bhishma."),("22s a woman.","22 As a woman."),("23tndra.","23 Indra."),("31 siddhi","31 Siddhi"),("4lThe sun.","41 The sun."),("50K artavirya Arjuna was the king of Haihaya. The word used is vishikha","50 Kartavirya Arjuna was the king of Haihaya. 51 The word used is vishikha"),("5 2 Arshtishena","52 Arshtishena"),("3 Thousands of gifts and stipends. S4Rahu.","53 Thousands of gifts and stipends. 54 Rahu."),("8Suggesting that it was large.","58 Suggesting that it was large."),("°° There is destruction","59 There is destruction"),("6l Because Bhishma","61 Because Bhishma"),("620urva’s son","62 Ourva’s son"),("J amadagni","Jamadagni"),("©8This has been","68 This has been"),("73Qbtained","73 Obtained"),("agitated or angry. 79 Shiva has","agitated or angry. 75 Shiva has"),("7©Mahadeva","76 Mahadeva"),("821 iterally","82 Literally"),("86T Hiranyavarma.","86 Hiranyavarma."),("8° Hiranyavarma.","89 Hiranyavarma."),("20 The word means the son of a shudra","90 The word means the son of a shudra"),("°1 This part of the conver","91 This part of the conver"),("92-Yakshas","92 Yakshas"),("°3Demi-gods","93 Demi-gods"),("°4Kubera.","94 Kubera."),("9©Hemavarma","96 Hemavarma"),("9TTo Drupada.","97 To Drupada."),("1064A ratha","106 A ratha"),("1087 okapalas","108 Lokapalas"),("(Joka)","(loka)"),("109 a shvatthama.","109 Ashvatthama."),("110qHusion.","110 Illusion."),("!12yudhishthira. 11 3Kripa.","112 Yudhishthira. 113 Kripa."),("1165 atyaki.","116 Satyaki."),("117 since Kuru","117 Since Kuru"),("118 4 fer death.","118 After death."),("1214 yojana","121 A yojana")]
def first(t):
    for a,b in R:
        assert a in t,a; t=t.replace(a,b,1)
    t=re.sub(r'(?<=\s)(\d{1,3})(?=[A-Z])',r'\1 ',t)
    t=re.sub(r'(Sections? \d+) ?\(',lambda m:m.group(1)+' (',t)
    return t
N,miss=mknotes3.parse(18660,18761,122,first=first)
print('miss',miss)
mknotes.fin(N,122,'notes60.json')
d=json.load(open('notes60.json')); d={k:v.replace(' ',' ') for k,v in d.items()}
json.dump(d,open('notes60.json','w'),ensure_ascii=False,indent=0)
