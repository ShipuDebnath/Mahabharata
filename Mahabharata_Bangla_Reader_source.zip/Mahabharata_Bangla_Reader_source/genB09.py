exec(open('gen9xh.py').read()); setsec(94)
def GG(ch,a,b,n1,n2,fix,R,hdr=None,merge=()):
    if n1<=n2: NB(ch,n1,n2,fix=fix,merge=merge)
    h=dh(re.sub(r'^Chapter \d+ ?\(\d+\) ?','',P[a-1])) if hdr is None else hdr
    p=h+('\n'+J(a,b-1) if b-1>a else '')
    R=[r for r in R if r[0] in p or print('skip',ch,r[0])]
    run(ch,p,R,list(range(n1,n2+1)),n1,n2)
GG(1988,109,114,1,10,(),
 [("aE asked","Janamejaya asked"),("Kounteya! only","Kounteya 1 only"),("son of a vaishya.’ Parikshit","son of a vaishya. 2 Parikshit"),("in his own kingdom.’ The","in his own kingdom. 3 The"),("adharma in your mind.”","adharma in your mind.” 4"),("his mothers,‘ attentively","his mothers, 5 attentively"),("sacred fire into water.","sacred fire into water. 6"),("“Yudhishthira honoured","‘Yudhishthira honoured"),("“There were the five","‘There were the five"),("left Gajasahvya.’ For","left Gajasahvya. 7 For"),("mothers? sur","mothers 8 sur"),("Louhitya,’ an","Louhitya, 9 an"),("Khandava.'° Your","Khandava. 10 Your")])
GG(1989,114,115,11,15,(),
 [("yo said","Vaishampayana said"),("Krishna\"! fallen","Krishna 11 fallen"),("Madravati’s!? son","Madravati’s 12 son"),("Diti’s offspring,” that","Diti’s offspring, 13 that"),("scorcher of enemies,'* was","scorcher of enemies, 14 was"),("to you many times.’","to you many times.’ 15")])
GG(1990,115,126,16,19,(),
 [("yee said","Vaishampayana said"),("“Yudhishthira said","‘Yudhishthira said"),("“Yudhishthira said","‘Yudhishthira said"),("good deeds.! O","good deeds. 16 O"),("was pleased.!” He","was pleased. 17 He"),("Dvaitavana.'® Desiring","Dvaitavana. 18 Desiring"),("mothers,'? you","mothers, 19 you"),("how can J act","how can I act"),("She was buxom and dark.","She was buxom and dark.”’")],merge=(1,))
