import sys;sys.path.insert(0,'.')
import mken24 as m
from tidy5 import tidy
P=m.P
def fx(i,a,b):
    assert a in P[i],(i,a); P[i]=P[i].replace(a,b)
fx(3,'mentally decided to perform the sacrifice. ‘Separately','mentally decided to perform the sacrifice.\n‘Separately')
fx(3,'arrived —the','arrived—the')
P[4]='‘'+P[4][1:]
fx(4,'OO mighty-armed','O mighty-armed')
P[10]=P[10].replace('Vaishampayana said, “The','Vaishampayana said, ‘The')
fx(10,'many expensive jewels. ‘O descendant','many expensive jewels.\n‘O descendant')
fx(11,'dwelling houses —as','dwelling houses—as')
fx(14,'25 26 Vaishampayana','Vaishampayana')
fx(14,'Drona’s son?” 28 «All','Drona’s son and Vivimshati, “All')
fx(14,'masters.” Having been brought','masters. Having been brought') if 'masters.” Having' in P[14] else None
fx(14,'“Having been brought there by Nakula, the guests Bahlika, Dhritarashtra, Somadatta and Jayadratha enjoyed and Vivimshati.','Having been brought there by Nakula, the guests Bahlika, Dhritarashtra, Somadatta and Jayadratha enjoyed themselves, as if they were the masters.')
fx(15,'themselves, as if they were the masters. Kshatta2? Vidura','Kshatta Vidura')
fx(15,'lords of the earth,’ 1 brahmana','lords of the earth, brahmana')
fx(15,'desire— abundance','desire—abundance')
mid='‘Then that king, supreme among kings and supreme among the Kuru lineage, '+P[7].strip()
def J(*ix): return ' '.join(P[i].strip() for i in ix)
def mk(ch,paras,ns,ne):
    body=tidy('\n'.join(paras),(ns,ne))
    notes=['[%d] %s'%(k-ns+1,m.N[k]) for k in range(ns,ne+1)]
    open('en/ch-%d.txt'%ch,'w',encoding='utf-8').write(body+'\n---NOTES---\n'+'\n'.join(notes)+'\n')
    print(ch,len(body.split()),'words',len(notes),'notes',len(body.split('\n')),'paras')
mk(255,[J(0,1),P[3],P[4],P[5],P[6],mid,P[8]],1,17)
mk(256,[P[10],P[11],P[12]],18,24)
mk(257,[J(14,15)],25,31)
