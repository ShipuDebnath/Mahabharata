import re,sys
J=r'[!?|/“\'*>®©°~]'
def fix(s):
    body,_,notes=s.partition('\n---NOTES---\n')
    b=body
    b=re.sub(r'(?<=[.,;:])[!?>®©°*]+\d{0,2}(?=\s|$)','',b)
    b=re.sub(r'(?<=[A-Za-z])([,.;:]?)'+J+r'(?:'+J+r'|\d)+(?=[\s,.;:’”—]|$)',r'\1',b)
    b=re.sub(r'(?<=[A-Za-z])([,.;:]?)\d{1,3}'+J+r'+\d{0,2}(?=[\s,.;:’”—]|$)',r'\1',b)
    b=re.sub(r'(?<=[A-Za-z])[“*\'>®©°~|/]+(?=[\s,.;:’”])','',b)
    b=re.sub(r'(?<=\s)(?=\S*[|/“*>®©°~])[!?|/“\'*>®©°~0-9]{1,5}(?=\s)','',b)
    b=re.sub(r'(?<=[a-z]),[!?>®©°]+\d{0,2}(?=\s)',',',b)
    b=re.sub(r'(?<=[a-z])”’(?=[ ,.;])','',b)
    b=re.sub(r'(?<=[a-z])\?(?= [a-z])','',b)
    b=re.sub(r'(?<=[a-z])”(?= [a-z])','',b)
    b=re.sub(r'([a-z])- ([a-z])',r'\1\2',b)
    b=re.sub(r' {2,}',' ',b)
    return b+'\n---NOTES---\n'+notes
def sus(t):
    bad=re.findall(r'\S*[!?>®©°*/$|“~][\d?!]?\S*',t.split('---NOTES---')[0])
    return [x for x in bad if not re.fullmatch(r'[‘“(]*[A-Za-z’-]+[!?][’”)]*',x) and not re.fullmatch(r'“[A-Z][A-Za-z’-]*[,.!?]?',x)]
if __name__=='__main__':
    for f in sys.argv[1:]:
        s=open(f,encoding='utf8').read(); t=fix(s); open(f,'w',encoding='utf8').write(t)
        print(f,sus(t)[:30])
