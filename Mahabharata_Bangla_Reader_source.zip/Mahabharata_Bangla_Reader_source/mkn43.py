import mknotes3,mknotes,json
R=[("> Karna was naturally","5 Karna was naturally"),("© The sun is the lord","6 The sun is the lord"),("> Because he was brought up","9 Because he was brought up"),("i Jamadagni’s son","11 Jamadagni’s son"),(" 13 Vrish"," 15 Vrish"),("5 ayadratha.","40 Jayadratha.")]
def first(t):
    for a,b in R:
        assert a in t,a; t=t.replace(a,b,1)
    return t
N,miss=mknotes3.parse(12703,12742,40,first=first)
print('miss',miss)
mknotes.fin(N,40,'notes43.json')
d=json.load(open('notes43.json'))
d['24']=d['24'].replace('Th the sense','In the sense')
json.dump(d,open('notes43.json','w'),ensure_ascii=False,indent=0)
d=json.load(open('notes43.json'))
d['39']=d['39'].replace(' 40','').strip(); d['40']='Jayadratha.'
json.dump(d,open('notes43.json','w'),ensure_ascii=False,indent=0)
