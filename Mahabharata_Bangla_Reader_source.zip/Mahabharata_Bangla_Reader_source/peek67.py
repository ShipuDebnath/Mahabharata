import sys
P=open('/tmp/c67.txt').read().split('\n')
a,b=int(sys.argv[1]),int(sys.argv[2])
for i in range(a,b+1): print('P%d:'%i,P[i]);print()
