exec(open('gen54.py').read())
fx(118,"‘Narada said, “This","‘“Narada said, ‘This"); fx(118,"only after he!’ has","only after he127 has"); fx(118,"of an immortal!!** He","of an immortal!128 He"); fx(118,"OO Aryaka","O Aryaka"); fx(118,"in your lineage.!*? Therefore","in your lineage.129 Therefore")
fx(119,"“Kanva said, “Aryaka","‘“Kanva said, “Aryaka"); fx(119,"O father!!° My","O father!130 My"); fx(119,"king of the gods, departed.”","king of the gods, departed.”’")
mk(765,[P[118],P[119]],127,130)
