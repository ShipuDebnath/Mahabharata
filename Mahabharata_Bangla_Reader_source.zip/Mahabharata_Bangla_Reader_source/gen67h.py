exec(open('gen67.py').read())
p=P[38]+'\n'+P[39]
R=[("In- toxicated with victory,°7 you","Intoxicated with victory, 67 you"),("escape with your life.”","escape with your life.’"),("““On seeing that the extremely","‘“On seeing that the extremely"),("their standards 68 Satyaki","their standards, 68 Satyaki"),("He® is like","He 69 is like"),("there was no one 70; who","there was no one who"),("the vajra’™ in","the vajra 70 in"),("Rama’s”! disciple","Rama’s 71 disciple"),("played on musical instruments.","played on musical instruments.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(67,72)))
mk(1016,P[i].split('\n'),67,71)
