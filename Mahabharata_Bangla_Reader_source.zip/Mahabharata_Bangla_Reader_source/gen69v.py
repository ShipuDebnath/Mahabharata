exec(open('gen69.py').read())
p=P[92]+'\n'+P[93]+'\n'+P[94]
R=[("broad- headed","broad-headed"),("from the body. !5 3 That","from the body. 153 That"),("cav- ern","cavern"),("““Durmukha shot sixty","‘“Durmukha shot sixty"),("in the batte,","in the battle,"),("immensely strong one!>4 used","immensely strong one 154 used"),("immensely strong Khara.!55 © lord of men!","immensely strong Khara. 155 O lord of men!"),("““O king! In that battle, in an instant, Nakula","‘“O king! In that battle, in an instant, Nakula"),("whose deeds were based on truth.”","whose deeds were based on truth.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[153,154,155])
mk(1059,P[i].split('\n'),153,155)
