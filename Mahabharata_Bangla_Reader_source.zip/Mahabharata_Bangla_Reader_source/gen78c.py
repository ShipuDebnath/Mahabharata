exec(open('gen78.py').read())
p=dh('\n'.join(P[16:18]))
R=[("Hrishikeshas*° emerged","Hrishikeshas 46 emerged"),("mare-headed fire*’ devouring","mare-headed fire 47 devouring"),("Kapardin,** the lord","Kapardin, 48 the lord"),("Bhaga’s eyes.*” That god","Bhaga’s eyes. 49 That god"),
("Girisha, the wielder of the trident.”","Girisha, the wielder of the trident.’”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(46,50))); mk(1289,P[i].split('\n'),46,49)
p=dh('\n'.join(P[19:21]))
R=[("\n‘““Drona’s son said","\n“Drona’s son said"),
("Ugra,~? Sthanu,>! Rudra, Sharva, Ishana, Ishvara, Girisha>2 the god Varada,>’ Bhava,>* the undecaying Bhavana,” Shitikantha>° Aja,’ Shakra, Kratha, Kratuhara,-® Hara, Vishvarupa,°? Virupaksha, Bahurupa,°! Umapati.°* Shmashanavasina,® Dripta, the lord who is Mahaganapati,°* Khattangadharina,®> Munda, Jatila®’ and Brahmachari.",
 "Ugra, 50 Sthanu, 51 Rudra, Sharva, Ishana, Ishvara, Girisha, 52 the god Varada, 53 Bhava, 54 the undecaying Bhavana, 55 Shitikantha, 56 Aja, 57 Shakra, Kratha, Kratuhara, 58 Hara, Vishvarupa, 59 Virupaksha, 60 Bahurupa, 61 Umapati, 62 Shmashanavasina, 63 Dripta, the lord who is Mahaganapati, 64 Khattangadharina, 65 Munda, 66 Jatila 67 and Brahmachari."),
("destroyer of Tripura.’ He is","destroyer of Tripura. 68 He is"),("O Vilohita!®? O Nilakantha!’° O Aprikta!”! O Durnivara!’* O Shukra!/? O Vishvasrija!’* O brahman!","O Vilohita 69 O Nilakantha 70 O Aprikta 71 O Durnivara 72 O Shukra 73 O Vishvasrija 74 O brahman!"),
("ganas always looks.” You are","ganas always looks. 75 You are"),("Gouri’s heart.’° You","Gouri’s heart. 76 You"),("appeared before him.’’ “O king!","appeared before him. 77\n“O king!"),("giant sharks.’ Others","giant sharks. 78 Others"),
("like wolves”? and","like wolves 79 and"),("shataghnis®® and","shataghnis 80 and"),("jharjharas,3! other drums","jharjharas, 81 other drums"),("four types of beings.8? They","four types of beings. 82 They"),
("eight kinds of prosperity,’ they","eight kinds of prosperity, 83 they"),("four kinds of taste.34 They","four kinds of taste. 84 They"),("and the future. “They laughed","and the future.\n“They laughed"),
("sacrifices were offered.8> Bows","sacrifices were offered. 85 Bows"),("the black trails.°° He","the black trails. 86 He"),("arms raised up. “On seeing him immobile","arms raised up.\n“On seeing him immobile"),
("entered his body.” Before","entered his body. 87 Before"),("lord of the gods8? himself.”","lord of the gods 88 himself.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(50,89))); mk(1290,P[i].split('\n'),50,88)
for nm in ['Vilohita','Nilakantha','Aprikta','Durnivara','Shukra','Vishvasrija']:
    post(1290,'O %s O'%nm,'O %s! O'%nm)
