exec(open('gen60.py').read())
for a,b in [("O son! /2 They","O son!72 They"),("asked, “What do you wish","asked, ‘What do you wish"),("any world./> [have","any world.73 I have"),("intelligent one, “You will kill","intelligent one, ‘You will kill"),("Since Iam a woman, my mind is deep./4 O","Since I am a woman, my mind is deep.74 O"),("on the banner!/> Act","on the banner!75 Act"),("Kapardi Vrishadhvaja/© disappeared","Kapardi Vrishadhvaja76 disappeared"),("entered the fire.”","entered the fire.”’")]: fx(82,a,b)
mk(851,[P[82]],72,76)
