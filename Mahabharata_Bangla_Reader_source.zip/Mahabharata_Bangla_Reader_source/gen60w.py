exec(open('gen60.py').read())
fx(93,"pro- tect","protect")
for a,b in [("“Having been overcome","‘“Having been overcome"),("for- est","forest"),("a yaksha?? named","a yaksha92 named"),("im- possible","impossible"),("the guhyaka?? told","the guhyaka93 told"),("lord of riches.?4 I","lord of riches.94 I"),("golden armour?» is","golden armour95 is"),("favours on me.’””","favours on me.’”’")]: fx(94,a,b)
mk(855,[P[93],P[94]],92,95)
