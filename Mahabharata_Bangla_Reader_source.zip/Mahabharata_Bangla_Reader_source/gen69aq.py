exec(open('gen69.py').read())
p=P[189]+'\n'+P[190]+'\n'+P[191]+'\n'+P[192]+' '+P[193]
R=[("the brothers2?> and","the brothers 293 and"),("like that of Suparna 294 the king","like that of Suparna, 294 the king"),("““O great king! Bharadvaja’s","“O great king! Bharadvaja’s"),("grasped the pole2?5 with","grasped the pole 295 with"),("““He then saw Satyaki","“He then saw Satyaki"),("mighty roar.O Kouravya","mighty roar. O Kouravya"),("Partha2”© also","Partha 296 also"),
("the fire god.297 All","the fire god. 297 All"),("difficult for the gods to defeat.298 It","difficult for the gods to defeat. 298 It"),("he defeated them.2? It","he defeated them. 299 It"),("in a great battle 299 It","in a great battle. 300 It"),("valour of his arms.29! Tt is","valour of his arms. 301 It is"),("Saindhava in the battle 302 will","Saindhava in the battle, 302 will"),("the terrible battle continued.’","the terrible battle continued.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(293,303)))
mk(1080,P[i].split('\n'),293,302)
