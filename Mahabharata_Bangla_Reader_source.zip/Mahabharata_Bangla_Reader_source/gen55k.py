exec(open('gen55.py').read())
for a,b in [("“Vasudeva said, “Having","‘Vasudeva said, “Having"),("The king®® repeatedly","The king88 repeatedly"),("Pushya today.’®? Driven","Pushya today.89’ Driven"),("standard. “O lord","standard. O lord"),("as the king,”” Gangeya","as the king,90 Gangeya"),("of chastisement.?! Those","of chastisement.91 Those"),("are confronting death.”","are confronting death.”’")]: fx(44,a,b)
mk(811,[P[44]],88,91)
