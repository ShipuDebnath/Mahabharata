exec(open('gen73.py').read())
p='\n'.join(P[267:273])
R=[("spoke to him. ‘ʻO Partha!","spoke to him. ‘O Partha!"),("used you sharp sword","used your sharp sword"),("\n* “King Dharmaraja raised","\n“King Dharmaraja raised"),("of Pandava’s head 619 Filled","of Pandava’s head. 619 Filled"),("spoke to Jaya.©20 ‘O","spoke to Jaya. 620 ‘O"),
("\n‘ “He inhaled the fragrance","\n“He inhaled the fragrance"),("I will not return I am touching","I will not return. I am touching"),("telling you this truthfully.” Having pacified","telling you this truthfully.’ Having pacified"),("Krishna told Daruka,©7! ‘Do","Krishna told Daruka, 621 ‘Do"),("He®22 sought","He 622 sought"),
("\n‘* “O descendant of the Bharata lineage! On seeing the great archer","\n“O descendant of the Bharata lineage! On seeing the great archer"),("O lord of men!\nAt that time, blue jays, shatapatras and curlews","O lord of men! At that time, blue jays, shatapatras 623 and curlews"),("auspicious male birds.924 They","auspicious male birds. 624 They"),("wishing to devour,©25 and","wishing to devour, 625 and"),
("\n““On seeing that Partha","\n“On seeing that Partha"),("con- structed","constructed"),("wonderful Gandiva 626 © Partha!","wonderful Gandiva. 626 O Partha!"),("time and place.©27 He","time and place. 627 He"),("capa- ble","capable"),("one aratni in breadth 628 He","one aratni in breadth. 628 He"),("Defeat the son of a suta.’” ’","Defeat the son of a suta.’”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(619,629)))
mk(1200,P[i].split('\n'),619,628)
