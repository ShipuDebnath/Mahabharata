exec(open('gen87vh.py').read())
NB(1762,112,113,fix=(("'2The goddess","112 The goddess"),("'3Meaning","113 Meaning")))
p=H(73,1762)+'\n'+J(74,84)
R=[("¢Wudhishthira said","‘Yudhishthira said"),("has Shri!” in it","has Shri 112 in it"),("hear about it.”","hear about it.”’"),("““The cattle asked","‘“The cattle asked"),("““Shri replied","‘“Shri replied"),("the water! and","the water 113 and"),("“The cows replied, “You are","‘“The cows replied, ‘You are"),("““Shri said, ‘O cattle","‘“Shri said, ‘O cattle"),("“The cattle replied","‘“The cattle replied"),("“Shri said, ‘ʻO ones","‘“Shri said, ‘O ones"),("“Shri replied, ‘It is","‘“Shri replied, ‘It is"),("honoured by you.”","honoured by you.’"),("Listen to me.”","Listen to me.”’")]
run(1762,p,R,[112,113],112,113)
NB(1763,114,117,fix=(("14To earth","114 To earth"),("15The word","115 The word"),("6The mother","116 The mother"),("\"TA diti","117 Aditi")))
p=H(84,1763)+'\n'+J(85,87)
R=[("6 hishma said, “O Yudhishthira","‘Bhishma said, “O Yudhishthira"),("come down.''*","come down. 114"),("O son!''°","O son! 115"),("Aditi!!®","Aditi 116"),("great goddess''”","great goddess 117"),("““O immensely radiant one","‘“O immensely radiant one"),("difficult to obtain.”","difficult to obtain.”’")]
run(1763,p,R,list(range(114,118)),114,117)
NB(1764,118,120,fix=(("18] ater","118 Later"),("'l°Vasishtha","119 Vasishtha"),("'2°One who","120 One who")))
p=H(87,1764)+'\n'+J(88,89)
R=[("é \\ 7 udhishthira said","‘Yudhishthira said"),("Tell me this.”","Tell me this.”’"),("When I slept,''®","When I slept, 118"),("donating gold. ““O king! O lord!","donating gold.\n‘“O king! O lord!"),("I will again!’ tell","I will again 119 tell"),("Urdhvareta.'”°","Urdhvareta. 120"),("undecaying Brahma.”","undecaying Brahma.’”’")]
run(1764,p,R,list(range(118,121)),118,120)
