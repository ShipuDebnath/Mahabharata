exec(open('gen67.py').read())
p=P[53]+'\n'+P[54]
R=[("‘Sanjaya said, ““Arjuna’s","‘Sanjaya said, “Arjuna’s"),("“The powerful Rukmaratha","‘“The powerful Rukmaratha"),("lord of Madra.” He","lord of Madra. 90 He"),("Sub- hadra’s","Subhadra’s"),("well-stocked.?! He","well-stocked. 91 He"),("surround- ed","surrounded"),("Vaivasvata’s abode.? Those","Vaivasvata’s abode. 92 Those"),("He?? confounded","He 93 confounded"),("an- gry","angry"),("serpents.?4 On","serpents. 94 On"),("hundreds of arrows and retreated.”","hundreds of arrows and retreated.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(90,95)))
mk(1021,P[i].split('\n'),90,94)
