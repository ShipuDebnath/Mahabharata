exec(open('gen76.py').read())
p=dh('\n'.join(P[66:70]))
R=[("J anamejaya said","Janamejaya said"),("another kalpa.!69 During","another kalpa. 169 During"),("Soma,!70 you","Soma, 170 you"),("Pralamba!7! touched","Pralamba 171 touched"),
("Please create fire again.” °","Please create fire again.”’"),("Vaishampayana replied, “The powerful","Vaishampayana replied, ‘The powerful"),("Bhrigu’s curse.!72 The","Bhrigu’s curse. 172 The"),
("the intelligent one!73 went","the intelligent one 173 went"),("he!74 gave","he 174 gave"),("before him.!75 The one","before him. 175 The one")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(169,176)))
mk(1265,P[i].split('\n'),169,175)
