exec(open('gen74.py').read())
p='\n'.join(P[29:31])
R=[("sol- diers","soldiers"),("the king*4 in","the king 34 in"),("among rathas, 39 who knew","among rathas, 35 who knew"),("Sthanu’s3® bull","Sthanu’s 36 bull"),("Aruna’s younger brother.” He was","Aruna’s younger brother. 37 He was"),("Ushanas*® jn his","Ushanas 38 in his"),("pos- sessed all","possessed all"),("ten divisions.>? He knew","ten divisions. 39 He knew"),("as the fifth 40 Drona","as the fifth. 40 Drona"),("Tryam- baka","Tryambaka"),("not born in a womb.*! His deeds","not born in a womb. 41 His deeds"),("un- matched","unmatched"),("quali- ties","qualities"),("he said, “O preceptor’s son!","he said, ‘O preceptor’s son!"),
("\n*“Drona’s son replied","\n“Drona’s son replied"),("his sister’s sonst? sesses a large army and is mighty-armed. He is like Mahasena? to the enemy.","his sister’s sons 42 and has gratefully come to our side. He possesses a large army and is mighty-armed. He is like Mahasena 43 to the enemy."),("appointing Skanda.’ ‘ “When Drona’s son said this, all the lords of the earth surrounded Shalya and stationed themselves around him, and has gratefully come to our side. He pos- proclaiming his victory.44 They","appointing Skanda.’\n“When Drona’s son said this, all the lords of the earth surrounded Shalya and stationed themselves around him, proclaiming his victory. 44 They"),("like Rama‘ and Bhishma","like Rama 45 and Bhishma"),("maternal un- cle!46 I","maternal uncle! 46 I"),("Pavaki.*7 O brave","Pavaki. 47 O brave"),("en- emies","enemies"),("against the danavas.’” ’","against the danavas.’”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(34,48)))
mk(1224,P[i].split('\n'),34,47)
