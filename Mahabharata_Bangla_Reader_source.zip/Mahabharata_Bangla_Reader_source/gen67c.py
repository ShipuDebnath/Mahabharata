exec(open('gen67.py').read())
a,b=P[12].split(' 2d CHAPTER 1011(34) ')
p=b+'\n'+P[13]+'\n'+P[14]+'\n'+P[15]+'\n'+P[16]+' '+P[17]+'\n'+P[18]+' '+P[19]+'\n'+P[20]
R=[("Dhrishtadyumna,22 the","Dhrishtadyumna, 22 the"),("Arjuna’s son,23 Kshatradharma","Arjuna’s son, 23 Kshatradharma"),("Madri,2+ Ghatotkacha","Madri, 24 Ghatotkacha"),("brave son,2> the","brave son, 25 the"),("Bhimaseana","Bhimasena"),("ma- haratha","maharatha"),
("And he~” spoke","And he 26 spoke"),("Abhi- manyu","Abhimanyu"),("‘O son!?” Act","‘O son! 27 Act"),("on return.2® There","on return. 28 There"),("Arju- na,","Arjuna,"),("Pradyumna,2? there","Pradyumna, 29 there"),
("‘Abhimanyu replied, ‘Desiring","‘“Abhimanyu replied, ‘Desiring"),("“Yudhishthira said, ‘O foremost","‘“Yudhishthira said, ‘O foremost"),("““Bhima said","‘“Bhima said"),("“Abhimanyu replied, “Like","‘“Abhimanyu replied, ‘Like"),
("lineages.29 I","lineages. 30 I"),("““Yudhishthira said, ‘O Subhadra’s","‘“Yudhishthira said, ‘O Subhadra’s"),("in valour.”","in valour.’”"),("“Sanjaya said, “On hearing these words, he~ * instructed","‘Sanjaya said, “On hearing these words, he 31 instructed"),("Drona’s array.”","Drona’s array.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(22,32)))
mk(1011,P[i].split('\n'),22,31)
