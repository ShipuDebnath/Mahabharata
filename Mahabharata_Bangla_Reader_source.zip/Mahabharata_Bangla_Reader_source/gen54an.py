exec(open('gen54.py').read())
for a,b in [("six high points.” She","six high points.203 She"),("should be slim.7°4 She","should be slim.204 She"),("three places*”° that","three places205 that"),("should be red.?°° She","should be red.206 She"),("be an emperor.”°” O","be an emperor.207 O"),("price.’ He7°® applauded","price.’ He208 applauded")]: fx(157,a,b)
fx(158,"‘After some time","‘“After some time"); fx(158,"lord of his subjects.”","lord of his subjects.”’")
mk(777,[P[157],P[158]],203,208)
