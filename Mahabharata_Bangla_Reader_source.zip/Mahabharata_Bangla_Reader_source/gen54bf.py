exec(open('gen54.py').read())
for a,b in [("““Vidula said, ‘If","‘“Vidula said, ‘If"),("see it in you.*°* O son! Live","see it in you.308 O son! Live"),("Knowing this— fight","Knowing this—fight"),("Shambara??? has","Shambara309 has"),("pond to another.*!° I have","pond to another.310 I have"),("be- decked","bedecked")]: fx(219,a,b)
for a,b in [("“When there are no shores","‘“‘When there are no shores"),("for only one*!! and","for only one311 and"),("maidens of Souvira.*!* Boast","maidens of Souvira.312 Boast"),("al- 9999 lies","allies"),("always live in this way.","always live in this way.’”’")]: fx(220,a,b)
mk(795,[P[219],P[220]],308,312)
