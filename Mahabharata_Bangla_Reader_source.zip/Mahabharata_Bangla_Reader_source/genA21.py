exec(open('gen89vh.py').read())
NB(1893,246,249,fix=(("46R aivataka","246 Raivataka"),("241A kalpa","247 A kalpa"),("248Since","248 Since"),("49K rishna","249 Krishna")))
p=H(214,1893)+'\n'+J(215,216)
R=[("Jonae asked","Janamejaya asked"),("colourful ways.”° O","colourful ways. 246 O"),("kalpavrikshas everywhere.” There","kalpavrikshas everywhere. 247 There"),("maireya.**","maireya. 248"),("Cheerful, he” entered","Cheerful, he 249 entered")]
R=[r for r in R if r[0] in p or print('skip',r[0])]
run(1893,p,R,list(range(246,250)),246,249)
NB(1894,250,258,fix=(("°The text says","250 The text says"),("2351The eleven","251 The eleven"),("°°°This should","252 This should"),("253The period","253 The period"),("254Kavya","254 Kavya"),("25K arna","255 Karna"),("°5°The five","256 The five"),("°°’) rupada","257 Drupada"),("°58K ritavarma","258 Kritavarma")))
p=H(216,1894)+'\n'+J(217,220)
R=[("c asudeva said, “O Varshneya","‘Vasudeva said, “O Varshneya"),("‘Krishna™ said","‘Krishna 250 said"),("army under him.”°!","army under him. 251"),("sons of Pandu.”””","sons of Pandu. 252"),("for ten days.>®","for ten days. 253"),("lord of the daityas.7*","lord of the daityas. 254"),("Vrisha?° and","Vrisha 255 and"),("five armies”°° and","five armies 256 and"),("of his father” and","of his father 257 and"),("Kripa and Bhoja,”°*","Kripa and Bhoja, 258"),("peformed","performed")]
R=[r for r in R if r[0] in p or print('skip',r[0])]
run(1894,p,R,list(range(250,259)),250,258)
