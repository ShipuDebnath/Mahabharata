exec(open('gen87vh.py').read())
NB(1772,189,197,fix=(("'8°This could","189 This could"),("Because, under","190 Because, under"),("PIDivinities","191 Divinities"),("‘Both are","192 Both are"),("'3Qnions","193 Onions"),("194A small","194 A small"),("1954 kind","195 A kind"),("‘S6Pastries","196 Pastries"),("'7Implying","197 Implying")))
p=H(117,1772)+'\n'+J(118,120)
R=[("‘ yo asked, “Who","‘Yudhishthira asked, “Who"),("Tell me this.”","Tell me this.”’"),("shyamaka rice,!®","shyamaka rice, 189"),("in his mind.!™","in his mind. 190"),("“On seeing that he was","‘“On seeing that he was"),("Ushmapas.!*!","Ushmapas. 191"),("given shares —","given shares—"),("pulaka,!°*","pulaka, 192"),("Nor should one use onions,!”","Nor should one use onions, 193"),("grinjana,'™*","grinjana, 194"),("shitapaki.'>","shitapaki. 195"),("shringatakas'”","shringatakas 196"),("inferior lineage'’’","inferior lineage 197"),("offered— chandalas","offered—chandalas"),("divine assembly hall?”","divine assembly hall.”’")]
run(1772,p,R,list(range(189,198)),189,197)
NB(1773,198,200,fix=(("98A brahmana","198 A brahmana"),("19Not directly","199 Not directly"),("700A Iternatively","200 Alternatively")))
p=H(120,1773)
R=[("é D hishma said","‘Bhishma said"),("Brahma-rakshasas'™","Brahma-rakshasas 198"),("well-wishers and relatives.!°?","well-wishers and relatives. 199"),("two black?” bulls","two black 200 bulls"),("Soma replied, “Go to","Soma replied, ‘Go to"),("tell you about donations.”","tell you about donations.”’")]
run(1773,p,R,[198,199,200],198,200)
