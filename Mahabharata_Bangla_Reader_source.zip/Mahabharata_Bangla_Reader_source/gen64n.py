exec(open('gen64.py').read())
p=P[97]+' '+P[98]+'\n'+P[99]+'\n'+P[100]
R=[("Hidimba’s son!37 and","Hidimba’s son 137 and"),("““Tn Drona’s sight","‘“In Drona’s sight"),("sol- diers","soldiers"),("the bull among the Kurus!38 were","the bull among the Kurus 138 were"),("firma- ment","firmament"),("‘Having seen that the army had been rallied","‘“Having seen that the army had been rallied"),("O bulls among men! 139 Tf] do not","O bulls among men! 139 If I do not"),("drums and tambourines should be sounded.”","drums and tambourines should be sounded.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(136,140)))
mk(914,P[i].split('\n'),136,139)
