exec(open('gen76.py').read())
p=dh(P[64])
R=[("V aishampayana said","Vaishampayana said"),("immobile! 49 —Prabhavati","immobile 149 —Prabhavati"),("copperyeyed","coppery-eyed"),
("followed the great-souled one. ‘O tiger among kings! The illustrious chastiser of Paka! 50 gave Guha!5! a javelin","followed the great-souled one.\n‘O tiger among kings! The illustrious chastiser of Paka 150 gave Guha 151 a javelin"),
("nairrtas.!92 The flags","nairrtas. 152 The flags"),
("by the tambourines, 154 trumpets made of cow horn, trumpets,!55 gomukhas!>© and smaller drums.!>7 All the gods","by the tambourines, jharjharas, 153 krakachas, 154 trumpets made of cow horn, trumpets, 155 gomukhas 156 and smaller drums. 157 All the gods"),
("large numbers of apsaras jharjharas,!> 3 krakachas, danced. ‘Delighted, Mahasena!98 granted","large numbers of apsaras danced.\n‘Delighted, Mahasena 158 granted"),
("and Learning!» 9 advanced","and Learning 159 advanced"),("The god Guha advanced. ‘On seeing him","The god Guha advanced.\n‘On seeing him"),
("javelin as a weapon, !60 He displayed","javelin as a weapon. 160 He displayed"),("The infinintely energetic","The infinitely energetic"),("to slay him!®! in the battle","to slay him 161 in the battle"),
("who surrounded him.!62 He slew","who surrounded him. 162 He slew"),("slaughtered them in the encounter. ‘Bali’s son","slaughtered them in the encounter.\n‘Bali’s son"),
("called Krouncha.!63 The mountain","called Krouncha. 163 The mountain"),("sarala!® trees","sarala 164 trees"),("sharabhas!66 and","sharabhas 166 and"),("Pavaka’s son,!67 the","Pavaka’s son, 167 the"),
("killed hundreds of daityas. ‘Thus did","killed hundreds of daityas.\n‘Thus did"),("hundreds and thousands of forms. ‘O king!","hundreds and thousands of forms.\n‘O king!")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(149,169)))
mk(1264,P[i].split('\n'),149,168)
post(1264,'immobile —Prabhavati','immobile—Prabhavati')
