exec(open('gen69.py').read())
p=P[128]+'\n'+P[129]+'\n'+P[130]+'\n'+P[131]+'\n'+P[132]
R=[("““Shini’s descendant, with truth","‘“Shini’s descendant, with truth"),("Yajnasena’s son228 pierced","Yajnasena’s son 228 pierced"),("that state, they,229 with","that state, they, 229 with"),("cheerfully pierced him with arrows.”","cheerfully pierced him with arrows."),("“The immensely strong Bhimasena recovered","‘“The immensely strong Bhimasena recovered"),("‘““O descendant of the Bharata lineage! In that encounter, the maharatha laughed","‘“O descendant of the Bharata lineage! In that encounter, the maharatha laughed"),("swifly","swiftly"),("““On seeing Shikhandi on the floor","‘“On seeing Shikhandi on the floor"),("and were forced to retreat.”","and were forced to retreat.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[228,229])
mk(1067,P[i].split('\n'),228,229)
