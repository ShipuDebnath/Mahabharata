exec(open('gen75.py').read())
p=dh('\n'.join(P[30:35]))
R=[("by means of signs.2 l As","by means of signs. 21 As"),("deprived of their partings in the encounter.2? That","deprived of their partings in the encounter. 22 That"),("afflicting our rear.O Pandava","afflicting our rear. O Pandava"),("will not advance in the battle again.” Droupadi’s","will not advance in the battle again.’ Droupadi’s"),("Iam the first","I am the first"),("grasping the hair? and","grasping the hair 23 and"),("\n* “When the sound","\n“When the sound"),("spears, swords and arrows were used.” ’","spears, swords and arrows were used.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[21,22,23])
mk(1241,P[i].split('\n'),21,23)
