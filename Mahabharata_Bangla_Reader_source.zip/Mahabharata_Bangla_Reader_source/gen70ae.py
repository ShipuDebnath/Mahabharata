exec(open('gen70.py').read())
p='\n'.join(P[k] for k in range(171,175))
R=[("bat- tle","battle"),("sum- moned","summoned"),("Bhimsena","Bhimasena"),
("Karna and the rakshasa.2*9 It","Karna and the rakshasa. 243 It"),
("your share in the battle.2“4 O","your share in the battle. 244 O"),
("\n““O lord! Bhimasena’s son","\n“O lord! Bhimasena’s son"),
("As his enemy245 advanced","As his enemy 245 advanced"),
("disregarded the advancing one 246 ““O lord! On seeing","disregarded the advancing one. 246\n“O lord! On seeing"),
("some of the others 247 On","some of the others. 247 On"),
("club down with a club, he28 advanced","club down with a club, he 248 advanced"),
("\n““On seeing that this","\n“On seeing that this"),
("the best of men?49 spoke","the best of men 249 spoke"),
("\n‘““The powerful Indra","\n“The powerful Indra"),
("club towards him 250 The","club towards him. 250 The"),
("to protect Bhimasena.”","to protect Bhimasena.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(243,251)))
mk(1129,P[i].split('\n'),243,250)
