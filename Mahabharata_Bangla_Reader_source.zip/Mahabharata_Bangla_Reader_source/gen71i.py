exec(open('gen71.py').read())
p='\n'.join([P[47]+' '+P[48],P[49]+' '+P[50],P[51]])
R=[("He®! was skilled","He 61 was skilled"),("he®? had to cast","he 62 had to cast"),("covered him with arrows. “To protect your son","covered him with arrows.\n“To protect your son"),
("Karna stopped, like a snake","Karna stopped, 63 like a snake"),("Bhi- ma’s","Bhima’s"),
("towards Bhima’s chariot, but heo4+ wards Adhiratha’s son. Exercising great care, Karna used ten gold-tufted arrows to strike it. He struck it with more arrows and sped it back towards Bhima. It descended and brought down Bhima’s giant standard. Struck by that shattered the club with his own club. Bhima again picked up a heavy club and hurled it to- club, his charioteer also lost his senses.",
 "towards Bhima’s chariot, but he 64 shattered the club with his own club. Bhima again picked up a heavy club and hurled it towards Adhiratha’s son. Exercising great care, Karna used ten gold-tufted arrows to strike it. He struck it with more arrows and sped it back towards Bhima. It descended and brought down Bhima’s giant standard. Struck by that club, his charioteer also lost his senses."),
("He®® was senseless","He 65 was senseless"),("each other on the right.© The","each other on the right. 66 The"),("tvash- tra","tvashtra"),("and varuna.” However","and varuna. 67 However"),
("\n““The immensely intelligent","\n“The immensely intelligent"),("could not find a passage.”","could not find a passage.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(61,68)))
mk(1140,P[i].split('\n'),61,67)
