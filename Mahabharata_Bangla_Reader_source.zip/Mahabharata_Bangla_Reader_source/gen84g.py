exec(open('gen84.py').read())
def run(ch,p,R,auton,n1,n2,posts=()):
    for x,y in R:
        assert x in p,(ch,x); p=p.replace(x,y,1)
    P.append(p); i=len(P)-1
    auto(i,auton); mk(ch,P[i].split('\n'),n1,n2)
    for a,b in posts: post(ch,a,b)
def H(k,ch): return dh(re.sub(r'^Chapter %d\(\d+\) ?'%ch,'',P[k]))
def J(a,b): return dh('\n'.join(P[a:b]))
NB(1358,247)
run(1358,J(115,121),[("become Kanchanashthivi?**’ Why","become Kanchanashthivi 247 Why"),("uncle and nephew.7** Once","uncle and nephew. 248 Once"),("Narada, who was overcome by desire. “You voluntarily","Narada, who was overcome by desire. ‘You voluntarily"),("will see you as an ape.” As soon","will see you as an ape.’ As soon"),("\n““The great sage","\n“The great sage"),("\n‘“After some time","\n“After some time"),("Parvata said, ʻO lord","Parvata said, ‘O lord"),
 ("\n““Sukumari saw","\n“Sukumari saw"),("spoke to her. “This is your husband","spoke to her. ‘This is your husband"),("will tell you exactly what happened.”","will tell you exactly what happened.”’")],[247,248],247,248,[('become Kanchanashthivi Why','become Kanchanashthivi? Why')])
NB(1359,249,split=('254 The king','257 That is'))
run(1359,J(122,126),[("Parvata said, “This desire of yours","Parvata said, ‘This desire of yours"),("protect him from the king of the gods.”","protect him from the king of the gods.’"),("Srinjaya said, ‘Through your favours","Srinjaya said, “Through your favours"),("let my son have a long life.’ However","let my son have a long life.” However"),("spoke to him again. ‘O great king!","spoke to him again. “O great king!"),("back to you in that form.’*4 Having","back to you in that form.” Having"),
 ("not just in name .?®? O","not just in name. 250 O"),("the great-souled ones.”>! The","the great-souled ones. 251 The"),("Vritra was frightened*>? and","Vritra was frightened 252 and"),("which appeared in a personified form. ‘O lord! Become a tiger.","which appeared in a personified form. “O lord! Become a tiger."),("may surpass me in valour.’ Having","may surpass me in valour.” Having"),("that mountainous stream.”>? His","that mountainous stream. 253 His"),
 ("His mothers”** also","His mothers 254 also"),("the king remembered me.*>> Knowing","the king remembered me. 255 Knowing"),("has told you about.?°° With","has told you about. 256 With"),("the dharma of time.”°’ O Indra","the dharma of time. 257 O Indra"),("obtain the worlds that are desired.”","obtain the worlds that are desired.’”’")],list(range(250,258)),249,257)
NB(1360,258)
p=J(127,130).replace(" were the slayers of dharma and you have\n","\n",1)
run(1360,p,[("indicated for the worlds.*°* In","indicated for the worlds. 258 In"),("They”>” killed them","They 259 were the slayers of dharma and you have killed them"),("\n“Yudhishthira said, “O one rich","\n‘Yudhishthira said, “O one rich"),("done by others.”°° Therefore","done by others. 260 Therefore"),("perform a good deed.”°! O","perform a good deed. 261 O"),("factor in this world.*°? O","factor in this world. 262 O"),
 ("have been laid down.*°* One","have been laid down. 263 One"),("one will not succeed.” O king","one will not succeed. 264 O king"),("tormented after death.”","tormented after death.”’")],list(range(258,265)),258,264)
run(1361,H(131,1361),[("“Yudhishthira said, “O grandfather!","‘Yudhishthira said, “O grandfather!"),("I should resort to now.","I should resort to now.”’")],[],1,0)
NB(1362,265)
run(1362,H(133,1362),[("O bull among men! This® is","O bull among men! This 265 is"),("the deeds they*®° performed","the deeds they 266 performed"),("gods were younger.*°’ Because","gods were younger. 267 Because"),("known in the three worlds as shalavrikas.7°8 There were eightyeight","known in the three worlds as shalavrikas. 268 There were eighty-eight"),("known as Shatakratu.”® He","known as Shatakratu. 269 He"),("cities and kingdoms””° and","cities and kingdoms 270 and"),("you will obtain the best.”","you will obtain the best.”’")],list(range(265,271)),265,270)
