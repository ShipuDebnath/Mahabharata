exec(open('gen86bh.py').read())
NB(1539,116,138,fix=(("9.5 will","119 As will"),("207 iterally","120 Literally"),("'231t is","123 It is"),("132A s distinct","132 As distinct"),("D6If","136 If")))
p=H(22,1539)+'\n'+J(23,25)
run(1539,p,[("¢- Wz udhishthira asked","‘Yudhishthira asked"),("advance towards emancipation?”","advance towards emancipation?”’"),("lord of Mithila,!'° follow","lord of Mithila, 116 follow"),
("from opposite sentiments,'!’ and","from opposite sentiments, 117 and"),("who expounded samkhya,''* himself","who expounded samkhya, 118 himself"),("years, he!’ had","years, he 119 had"),("known as panchasrota.!™® There","known as panchasrota. 120 There"),
("name of Kapila’! and","name of Kapila 121 and"),("became his!”* disciple","became his 122 disciple"),("became Kapila’s son.!”* He","became Kapila’s son. 123 He"),("reasons. Kapila!” therefore","reasons. Kapila 124 therefore"),
("subject to destruction.'* There","subject to destruction. 125 There"),("evidently been defeated.'*° They","evidently been defeated. 126 They"),("hardship, death,'?’ old","hardship, death, 127 old"),("thought of in that way.!?* Whether","thought of in that way. 128 Whether"),
("view of non-believers.'?? A","view of non-believers. 129 A"),("the sun-crystal!*° drink up water.'*! When","the sun-crystal 130 drink up water. 131 When"),("preserving the spirit.\" This","preserving the spirit. 132 This"),("obtained by someone else?! There","obtained by someone else? 133 There"),
("one passes on,'™ but","one passes on, 134 but"),("However, this!” will","However, this 135 will"),("would be valid.'*° Reflecting","would be valid. 136 Reflecting"),("separated from their meat,'*’ come","separated from their meat, 137 come"),
("He glanced towards him’?! to ask him once again.” and got ready","He glanced towards him 138 and got ready to ask him once again.”’")],list(range(116,139)),116,138)
NB(1540,139,151,fix=(("14L iterallly","143 Literally"),))
p=H(25,1540)
run(1540,p,[("é D hishma said","‘Bhishma said"),("‘O illustrious one!!*? If","‘O illustrious one! 139 If"),("enveloped in darkness.'“° ““The wise Panchashika","enveloped in darkness. 140\n‘“The wise Panchashika"),("in that excellence.'*! Nor","in that excellence. 141 Nor"),
("imperishable seed.'” If","imperishable seed. 142 If"),("known as samyangamana.'* J will","known as samyangamana. 143 I will"),("there are eleven! and","there are eleven 144 and"),("These fifteen'* are","These fifteen 145 are"),("between the two.'“° The","between the two. 146 The"),
("The ten!” tively.","The ten 147 undertake their own tasks, separately and collectively."),("cannot be destroyed.Their","cannot be destroyed. Their"),("can be grasped.'** If","can be grasped. 148 If"),("or from the gods.\" He","or from the gods. 149 He"),
("king of Mithila.!°° When","king of Mithila. 150 When"),("being burnt here.”!°! The","being burnt here.” 151 The"),("after meeting Kapila.” undertake their own tasks, separately and collec-","after meeting Kapila.”’")],list(range(139,152)),139,151)
NB(1541,152,153)
p=H(26,1541)+'\n'+J(27,28)
run(1541,p,[("c yo asked","‘Yudhishthira asked"),("What conduct ensures success?”","What conduct ensures success?”’"),("his many enemies!” as","his many enemies 152 as"),("waiting for his time.!°? He","waiting for his time. 153 He"),("and is full of his atman.”","and is full of his atman.”’")],[152,153],152,153)
post(1540,'[7] Rach','[7] Each')
