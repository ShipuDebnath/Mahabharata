exec(open('gen64.py').read())
p=P[236]+'\n'+P[237]+'\n'+P[238]
R=[("de- feated","defeated"),("O son!!! My sons","O son! 311 My sons"),("“Drona, best among rathas","‘“Drona, best among rathas"),("those on your side met with decay.”","those on your side met with decay.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[311])
mk(945,P[i].split('\n'),311,311)
