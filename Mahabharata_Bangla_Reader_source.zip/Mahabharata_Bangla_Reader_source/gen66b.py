exec(open('gen66.py').read())
p=P[7]+'\n'+P[8]+' '+P[9]
R=[("“When they regained consciousness","‘“When they regained consciousness"),
("The angry king of the Trigartas 10 You pledged","The angry king of the Trigartas 10 spoke to the maharathas. ‘O brave ones! Do not run away. You should not be overcome by fear. You pledged"),
("returned again, like 11 spoke to the maharathas. ‘O brave ones! Do not run away. You should not be overcome by fear. the Narayana cowherds’~ that have returned to their death.”","returned again, like the Narayana cowherds 11 that have returned to their death.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[10,11])
mk(994,P[i].split('\n'),10,11)
