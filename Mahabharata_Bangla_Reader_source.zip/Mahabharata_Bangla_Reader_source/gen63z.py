exec(open('gen63.py').read())
p=P[115]+' '+P[116]+' '+P[117]
R=[("“Arjuna said, ‘Those who discard 567 the prescriptions of the shastras, but worship 568 what","‘“Arjuna said, ‘Those who discard 567 the prescriptions of the shastras, but worship 568 with recourse to faith, what"),
("tamas?’ ““The lord said,","tamas?’\n‘“The lord said, 0 "),
("tamas- type","tamas-type"),("those of the with recourse to faith, rajas-type,","those of the rajas-type,"),
("ghosts 971 and devils. >’2 Those","ghosts 571 and devils. 572 Those"),("de- sire","desire"),
("inside the body. 574 Know","inside the body. 574 Know"),
("un- happiness","unhappiness"),
("a long time ago, 576 t577 578 579 —impure.","a long time ago, 576 no longer succulent, 577 with a bad smell, stale, 578 tasted by others 579 —impure."),
("in search of fruits or no longer succulen and with a bad smell, stale and tasted by others indeed because of insolence,","in search of fruits or indeed because of insolence,"),
("non-violence 582 _ these","non-violence 582 —these"),
("pleasant 583 584 and leads to welfare, and self-study —these","pleasant and leads to welfare, 583 and self-study 584 —these"),
("purity in attitude —all","purity in attitude 585 —all"),
("wor- ship","worship"),("subject 589 _ are","subject 589 —are"),
("“Om tat sat’ —in","“Om tat sat” —in"),("with- out","without"),
("in the afterworld.’””","in the afterworld. 590")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y)
p=p.replace('The lord said, 0 ','The lord said, ')
P.append(p); i=len(P)-1
auto(i,list(range(567,591)))
P[i]=P[i].replace('afterworld.590','afterworld.590’”’')
mk(899,P[i].split('\n'),567,590)
for a,b in [("“Sat is used","“Sat” is used"),("“Sat is also","“Sat” is also"),("“Sat and action","“Sat” and action")]:
    post(899,a,b)
