exec(open('gen89vh.py').read())
NB(1884,196,201,fix=(("'Purusha.","196 Purusha."),("'7Rven","197 Even"),("'8One-fourth","198 One-fourth"),("‘9 Action","199 Action"),("0°The sense","200 The sense"),("°0lThe seven","201 The seven")))
p=H(171,1884)+'\n'+J(172,173)
R=[("6666 PD rahma said","‘“Brahma said"),("enjoys the enjoyer!”°","enjoys the enjoyer 196"),("doesn’t attain intelligence.!”","doesn’t attain intelligence. 197"),("one-fourth of that,!°*","one-fourth of that, 198"),("yield fruits.” By","yield fruits. 199 By"),("down at the ground.” However","down at the ground. 200 However"),("dhaivata.°!","dhaivata. 201"),("\n“There is an entity","\n‘“There is an entity"),("obtains the infinite. 999999","obtains the infinite.”’”")]
R=[r for r in R if r[0] in p or print('skip',r[0])]
run(1884,p,R,list(range(196,202)),196,201)
NB(1885,202,207,fix=(("2071 ike horses","202 Like horses"),("?3This","203 This"),("?04[ama","204 Mama"),("07s has been","207 As has been")))
p=H(173,1885)+'\n'+J(174,179)
R=[("6666 B rahma said","‘“Brahma said"),("senses are yoked” and","senses are yoked 202 and"),("gods, animals,” animals","gods, animals, 203 animals"),("namama is eternal.” There","namama is eternal. 204 There"),("by the sixteen.” The","by the sixteen. 205 The"),("as if in a dream.” This","as if in a dream. 206 This"),("you will obtain success.”\n","you will obtain success.”’\n"),("The preceptor said,”°’ ‘Thus","The preceptor said, 207 ‘Thus"),("\n“Vasudeva continued","\n‘Vasudeva continued")]
R=[r for r in R if r[0] in p or print('skip',r[0])]
run(1885,p,R,list(range(202,208)),202,207)
