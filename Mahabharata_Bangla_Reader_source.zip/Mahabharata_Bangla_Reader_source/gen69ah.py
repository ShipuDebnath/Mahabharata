exec(open('gen69.py').read())
p=P[146]+'\n'+P[147]
R=[("thousand eyes.242 He","thousand eyes. 242 He"),("of his243 charioteer","of his 243 charioteer"),("range of the arrows.”","range of the arrows.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[242,243])
mk(1071,P[i].split('\n'),242,243)
