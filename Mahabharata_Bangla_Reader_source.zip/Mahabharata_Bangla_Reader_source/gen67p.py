exec(open('gen67.py').read())
q=P[62].replace(' ““Soubala pierced','\n‘“Soubala pierced',1)
p=P[61].split('CHAPTER 1024(47) ')[1]+' '+q+'\n'+P[63]
R=[("he!97 Jooked","he 107 looked"),("kimshuka trees.!08 subhadra’s","kimshuka trees. 108 Subhadra’s"),("guarded his flanks.!99 He","guarded his flanks. 109 He"),("and he!!0 climbed","and he 110 climbed"),("Oth- erwise","Otherwise"),("spoke to Drona.!!! ‘Before","spoke to Drona. 111 ‘Before"),("bat- tle","battle"),("wielder of Gandiva.!!? At this","wielder of Gandiva.112’ At this"),("about that.! 13 But","about that. 113 But"),("guard his flanks.!14 O","guard his flanks. 114 O"),("light- handed","light-handed"),("Bhoja! 15 killed","Bhoja 115 killed"),("Goutama!!® the","Goutama 116 the"),
("“At that time, when","‘“At that time, when"),("maharathas! 17 quickly","maharathas 117 quickly"),("motions.!!8 The","motions. 118 The"),("wondering, “He might","wondering, ‘He might"),("Abhi- manyu","Abhimanyu"),("Vasudeva.!!? Blood","Vasudeva. 119 Blood"),("looked exceedingly fierce.”","looked exceedingly fierce.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[107,108,109,110,111,113,114,115,116,117,118,119])
mk(1024,P[i].split('\n'),107,119)
