exec(open('gen76.py').read())
p=dh('\n'.join(P[53:55])).replace('Chapter 1260(41) ','',1)
R=[("anamejaya asked","Janamejaya asked"),("bear the rishi away??? O lord!","bear the rishi away 99 O lord!"),("between them?!00 © immensely","between them 100 O immensely"),
("on the west.19! O great king! Sthanu had performed great austerities there.!02 Learned","on the west. 101 O great king! Sthanu had performed great austerities there. 102 Learned"),
("did not know what to do. ‘Realizing","did not know what to do.\n‘Realizing"),("Otherwise, Vishamitra will","Otherwise, Vishvamitra will"),
("Koushika!3 was","Koushika 103 was"),("was also borne away, 104 O king!","was also borne away. 104 O king!"),("from the grandfather.!05 This","from the grandfather. 105 This"),
("obtain our learning.!06 You","obtain our learning. 106 You"),("and splendour.!07 You","and splendour. 107 You"),("speech and svaha 108 You","speech and svaha. 108 You"),
("find life.” 109 O king!","find life.” O king!"),("he110 was overcome","he 110 was overcome")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(99,109))+[110])
mk(1260,P[i].split('\n'),99,110)
post(1260,'bear the rishi away','bear the rishi away?')
post(1260,'enmity between them','enmity between them?')
p=dh('\n'.join(P[56:59]))
R=[("V aishampayana said, “The","Vaishampayana said, ‘The"),("terrible tirtha.!!1 © supreme","terrible tirtha. 111 O supreme"),("this plight.! 12 We","this plight. 112 We"),
("eternal dharma.!!3 It","eternal dharma. 113 It"),("brahma-rakshasas.!!4 In","brahma-rakshasas. 114 In"),("of women.!!5 9 supreme","of women. 115 O supreme"),
("as she had been earlier. ‘O king!","as she had been earlier.\n‘O king!"),("foam of water.!!© Namuchi","foam of water. 116 Namuchi"),("killing a brahmana.!!7 Perform","killing a brahmana. 117 Perform"),
("and he! !8 obtained","and he 118 obtained"),("of desire. ‘The great-souled","of desire.\n‘The great-souled"),("Mahasena,! 19 the","Mahasena, 119 the")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(111,120)))
mk(1261,P[i].split('\n'),111,119)
