exec(open('gen47.py').read())
fx(50,'names of Partha” earlier','names of Partha56 earlier'); P[51]='‘'+P[51][1:]; P[52]='‘'+P[52][1:]; P[53]='‘'+P[53][1:]
fx(53,'Dhananjaya.°’','Dhananjaya.57'); fx(53,'Vijaya.°®>','Vijaya.58'); fx(53,'Shvetavahana.>°','Shvetavahana.59'); fx(53,'known as Phalguna.','known as Phalguna.60'); fx(53,'I am Kiriti l I have','I am Kiriti.61 I have'); fx(53,'Bibhatsu.®*','Bibhatsu.62'); fx(53,'Savyasachi.°*','Savyasachi.63'); fx(53,'as Arjuna.°*','as Arjuna.64'); fx(53,'Paka.°>','Paka.65'); fx(53,'Jishnu.©','Jishnu.66'); fx(53,'complexion.”®’','complexion.67”'); fx(54,'redeyed','red-eyed')
mk(635,[P[i] for i in range(48,55)],56,67)
fx(58,'trident,°*','trident,68'); fx(58,'Shatakratu.©','Shatakratu.69'); P[59]='‘'+P[59][1:]; P[60]='‘'+P[60][1:]
fx(59,'elder brother.” I have','elder brother.70 I have'); fx(59,'another.’! O','another.71 O'); fx(59,'vow has been completed.”','vow has been completed.72”'); fx(60,'Shakra.’? The','Shakra.73 The'); fx(60,'hardly be seen.”* I','hardly be seen.74 I'); fx(61,'strong one”? took','strong one75 took')
mk(636,[P[i] for i in range(56,62)],68,75)
fx(63,'shami tree.’°','shami tree.76'); fx(63,'Vishvakarma.”’','Vishvakarma.77'); fx(63,'he’® instructed','he78 instructed'); fx(66,'Vaishampayana said, “The earth','Vaishampayana said, ‘The earth'); fx(67,'vultures’?','vultures79'); fx(67,'your®? body','your80 body'); fx(67,'battle formations.”','battle formations.”’')
mk(637,[P[i] for i in range(63,68)],76,80)
fx(69,'They®! sought','They81 sought'); fx(69,'Drona’s son*?','Drona’s son82'); fx(69,'vajra®’','vajra83'); fx(69,'deserted forest?**','deserted forest?84'); fx(69,'He®° knows their®° minds','He85 knows their86 minds'); fx(69,'Vasava®’','Vasava87'); fx(69,'fight with the enemy.”','fight with the enemy.”’')
mk(638,[P[69]],81,87)
# post: 638 'deserted forest? Se'; 635 closing ’
