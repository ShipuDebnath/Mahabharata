import re,sys
a,b,n=int(sys.argv[1]),int(sys.argv[2]),sys.argv[3]
L=open('/mnt/user-data/uploads/bf4b53ce-Source_-_Copy.txt',encoding='utf-8').read().split('\n')
src=L[a-1:b]
out=[]
st=re.compile(r'^(Chapter \d|‘ ?“|“ ?“|\* ?“|« ?“|‘Sanjaya|‘Dhritarashtra|V ?aishampayana|J ?anamejaya|SECTION)')
for s in src:
    t=s.strip()
    if not t or re.fullmatch(r'\d{1,4}',t): continue
    if not out or st.match(t): out.append(t)
    else: out[-1]+=' '+t
for f in ['c%s.txt'%n,'/tmp/c%s.txt'%n]: open(f,'w',encoding='utf-8').write('\n'.join(out))
print(len(out))
for i,o in enumerate(out):
    if o.startswith('Chapter'): print(i,o[:40])
