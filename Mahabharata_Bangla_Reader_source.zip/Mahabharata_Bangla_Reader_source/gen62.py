import sys,re;sys.path.insert(0,'.')
import mken62 as m
from tidy5 import tidy
P=m.P
def fx(i,a,b):
    assert a in P[i],(i,a); P[i]=P[i].replace(a,b)
def sp(i,*keys):
    for k in keys:
        assert k in P[i],(i,k); P[i]=P[i].replace(' '+k,'\n'+k,1)
def J(*ix): return ' '.join(P[i].strip() for i in ix)
def mk(ch,paras,ns,ne):
    body=tidy('\n'.join(paras),(ns,ne))
    body='\n'.join(('‘'+l if re.match(r'(Shakuni|Duryodhana|Dhritarashtra|Vidura|Yudhishthira|Bhima|Arjuna|Droupadi|Kunti|Karna)\s(said|replied|asked)',l) else l) for l in body.split('\n'))
    notes=['[%d] %s'%(k-ns+1,m.N[k]) for k in range(ns,ne+1)]
    open('en/ch-%d.txt'%ch,'w',encoding='utf-8').write(body+'\n---NOTES---\n'+'\n'.join(notes)+'\n')
    print(ch,len(body.split()),'words',len(notes),'notes',len(body.split('\n')),'paras')
def post(ch,a,b):
    f='en/ch-%d.txt'%ch; s=open(f,encoding='utf-8').read(); assert a in s,(ch,a); open(f,'w',encoding='utf-8').write(s.replace(a,b))
