exec(open('gen70.py').read())
p=P[41]+' '+P[42]+'\n'+P[43]+'\n'+P[44]+' '+P[45]+'\n'+P[46]+'\n'+P[47]
R=[("invincible one 5 ! intolerant","invincible one, 51 intolerant"),("penetrat- ed, what did he>? think","penetrated, what did he 52 think"),("world of the hereafter.O king!","world of the hereafter. O king!"),("King Shibi,’ 3 angrily","King Shibi, 53 angrily"),("He brought his’ charioteer","He brought his 54 charioteer"),("He severed his>> head","He severed his 55 head"),
("killed by Bhimasena,’ 6 the","killed by Bhimasena, 56 the"),("struck Vishokað” with","struck Vishoka 57 with"),("maharatha brothers~’° could","maharatha brothers 58 could"),("went to Dhruva’s chariot.°? With","went to Dhruva’s chariot. 59 With"),("went to J ayarata’s chariot","went to Jayarata’s 60 chariot"),("laughed and seized it 61 The","laughed and seized it. 61 The"),
("““O king! Your sons°2 advanced","“O king! Your sons 62 advanced"),("lord of the waters©? and","lord of the waters 63 and"),("de- lighted","delighted"),("after Andhaka had been killed.* Your","after Andhaka had been killed. 64 Your"),("wolves and vultures.”","wolves and vultures.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(51,65)))
mk(1107,P[i].split('\n'),51,64)
