exec(open('gen66.py').read())
p=P[59]+'\n'+P[60]+'\n'+P[61]
R=[("ar- rows","arrows"),("the mighty-armed one105 quickly","the mighty-armed one 105 quickly"),("with sweat and rain.!06 Those","with sweat and rain. 106 Those"),("“Shakuni was skilled","‘“Shakuni was skilled"),("blud- geons","bludgeons"),("hollow arrows, !07 weapons with joints, chakras, tufted arrows, darts and many other weapons showered down on Arjuna from all the vatsadantas, directions.","hollow arrows, 107 vatsadantas, weapons with joints, chakras, tufted arrows, darts and many other weapons showered down on Arjuna from all the directions."),("small deer, !08 kites","small deer, 108 kites"),("flesh-eaters !99 hungrily","flesh-eaters 109 hungrily"),("un- leashed","unleashed"),("enveloped Arjuna’s chariot.!!0 From","enveloped Arjuna’s chariot. 110 From"),("known as jyotisha.!!1 When","known as jyotisha. 111 When"),
("“Arjuna was the best among","‘“Arjuna was the best among"),("Gandiva on my south.!!2 There","Gandiva on my south. 112 There"),("wellwisher","well-wisher"),("they abandoned their mounts.”","they abandoned their mounts.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(105,113)))
mk(1006,P[i].split('\n'),105,112)
