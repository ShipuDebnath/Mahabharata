exec(open('gen64.py').read())
p=P[371]+'\n'+P[372]+' '+P[373]+'\n'+P[374]+' '+P[375]+'\n'+P[376]
R=[("““O descendant of the Bharata lineage! Shalya, Kripa","‘“O descendant of the Bharata lineage! Shalya, Kripa"),("““Tn the battle, the maharatha commander“? addressed","‘“In the battle, the maharatha commander 439 addressed"),("O father!*40 His","O father! 440 His"),("ear- lier","earlier"),("Rama‘ 41 had imparted","Rama 441 had imparted"),
("“On witnessing his valour, Madhusudana","‘“On witnessing his valour, Madhusudana"),("Sub- hadra’s","Subhadra’s"),("Susharma,442 Virata","Susharma, 442 Virata"),("fol- lowers443 and","followers 443 and"),("lamenta- tion","lamentation"),("between the gods and the asuras.””’","between the gods and the asuras.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(439,444)))
mk(973,P[i].split('\n'),439,443)
