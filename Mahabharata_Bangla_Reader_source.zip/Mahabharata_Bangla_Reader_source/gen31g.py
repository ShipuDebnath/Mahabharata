exec(open('gen31.py').read())
def q(i): P[i]=re.sub(r'^[“‘]*“(Yudhishthira|Vasudeva|Droupadi|Prahlada|Bhima)','‘\\1',P[i]); P[i]=re.sub(r'^[‘“]*““','“',P[i])
for i in range(80,92): q(i)
R={80:[('the immobile! can','the immobile 199 can'),('the creator29! and','the creator 201 and'),('If it293 is','If it 203 is')],
83:[('one?05 who','one 205 who')],
84:[('father’s house 206 O','father’s house. 206 O')],
87:[('not one served by the strong. 1S 18 not approve isnna, or D1 atsu, or imanyu, or srinjaya, or 1 myse „Ort e two g. This i pproved by Krishna,2!9 or Bibh Abhimanyu, or Srinjaya,2!! or I myself, or th sons of Madri.','not one served by the strong. This is not approved by Krishna, 210 or Bibhatsu, or Abhimanyu, or Srinjaya, 211 or I myself, or the two sons of Madri.')],
88:[('two goals” !2 deserves','two goals 212 deserves'),('in the last 213 The','in the last. 213 The'),('in the last.2!4 0 supreme','in the last. 214 O supreme'),('Kuru lineage!2!5 Whether','Kuru lineage! 215 Whether')],
89:[('cruel deeds,2!6 those','cruel deeds, 216 those'),('the preserver2!7 has','the preserver 217 has'),('with a spear^ +° obtains','with a spear 218 obtains'),('every way.219 But','every way. 219 But')],
90:[('the other.229 O','the other. 220 O'),('Kuru lineage!22! O','Kuru lineage! 221 O')],
91:[('Vritra22> surrounded','Vritra 223 surrounded'),('asuras.O Kounteya','asuras. O Kounteya'),('Srinjayas 224 the','Srinjayas, 224 the')]}
for i,L in R.items():
    for a,b in L: fx(i,a,b)
mk(330,[P[80],P[81],P[82],P[83],J(84,85)],199,207)
mk(331,[P[87],P[88],P[89],P[90],P[91]],208,224)
