exec(open('gen69.py').read())
p=P[213]+' '+P[214]+'\n'+P[215]+'\n'+P[216]+'\n'+P[217]
R=[("Partha330 is","Partha 330 is"),("the downfall.331 He","the downfall. 331 He"),("thinks that it332 belongs","thinks that it 332 belongs"),("Vaikartana Vrisha>3 wished","Vaikartana Vrisha 333 wished"),("shot by Vasushena,>>4 Bhima","shot by Vasushena, 334 Bhima"),("instructed Dur- jaya, 335 ‘O Durjaya!","instructed Durjaya, 335 ‘O Durjaya!"),("your son>36 agreed and at- tacking","your son 336 agreed and attacking"),
("337 of his chariot, he?38 laughed at the enemy and covered him with a mass of arrows, mak- Having deprived him ing him look like a shataghni>>? with spikes","“Having deprived him 337 of his chariot, he 338 laughed at the enemy and covered him with a mass of arrows, making him look like a shataghni 339 with spikes"),("avoid Bhima in that battle.’","avoid Bhima in that battle.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(330,340)))
mk(1085,P[i].split('\n'),330,339)
