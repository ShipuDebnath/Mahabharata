exec(open('gen64.py').read())
p=P[332]+'\n'+P[333]+' '+P[334]+' '+P[335]
R=[("““Dhrishtadyumna forcefully","‘“Dhrishtadyumna forcefully"),("the soldiers. “This Arjuna","the soldiers. ‘This Arjuna"),("short time to live.” On","short time to live.’ On"),("in front of Bhishma, he*!1 grasped","in front of Bhishma, he 411 grasped"),("penentrated","penetrated"),("Arjuna was not distressed.””’","Arjuna was not distressed.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[411])
mk(966,P[i].split('\n'),411,411)
