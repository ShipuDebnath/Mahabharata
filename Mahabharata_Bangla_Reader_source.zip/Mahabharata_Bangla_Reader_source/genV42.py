exec(open('gen87vh.py').read())
NB(1799,369,370,fix=(("3 Vyasa","369 Vyasa"),("37D) harma","370 Dharma")))
p=H(256,1799)+'\n'+J(257,261)
p='\n'.join(('‘'+l) if l.startswith('“The worm') else l for l in p.split('\n'))
R=[("6 you said","‘Yudhishthira said"),("there is good or bad?”","there is good or bad?”’"),("a state of unhappiness.”","a state of unhappiness.’"),("he*® replied","he 369 replied"),("the three objectives?™”","the three objectives 370"),("best for me.’””’","best for me.’”’")]
run(1799,p,R,[369,370],369,370)
