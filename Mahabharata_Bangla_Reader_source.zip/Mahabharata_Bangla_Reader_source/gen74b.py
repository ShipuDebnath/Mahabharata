exec(open('gen74.py').read())
p='\n'.join(P[20:22])
R=[("V aishampayana said, “O great king!","Vaishampayana said, ‘O great king!"),("lament- ed","lamented"),("se- verely","severely"),("O son! O Indra among kings! Come to me.","O son! O Indra among kings! 8 Come to me."),("mighty- armed","mighty-armed"),("re- spectful","respectful"),("af- fectionately","affectionately"),("won- derful","wonderful"),("the two from Avanti 3 Jayadratha","the two from Avanti, 9 Jayadratha"),("Trigarta, ~ grandfather","Trigarta, 10 grandfather"),("Rishyashringa’s son, !! the rakshasa","Rishyashringa’s son, 11 the rakshasa"),("bat- tle","battle"),("ad- viser","adviser"),("king of deer!2 by","king of deer 12 by"),("all weapons. !3 He","all weapons. 13 He"),("Bhurishra- va","Bhurishrava"),("oth- er than","other than"),("im- mensely strong grandsons","immensely strong grandsons"),("rel- atives","relatives"),("re- duced","reduced"),("Duryod- hana has been slain","Duryodhana has been slain"),("hun- dred","hundred"),
("Gavalgana’s son,!5 to tell","Gavalgana’s son, 15 to tell"),("Gaval- gana’s","Gavalgana’s"),("assem- bled","assembled"),("Satvata warriors,!© Kripa","Satvata warriors, 16 Kripa"),("Bharadvaja’s son! 7 escape?","Bharadvaja’s son 17 escape?"),("recounting.” ’","recounting.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(8,18)))
mk(1221,P[i].split('\n'),8,17)
