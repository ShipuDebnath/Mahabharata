exec(open('gen63.py').read())
s=P[87].replace("CHAPTER 892(32) 257 ““The lord said, ‘O mighty-armed one!","‘“The lord said, 357 ‘O mighty-armed one!")
assert '357' in s
P[87]=s
auto(87,[357,358,359,360])
fx(88,"sages, 361 the four who came before them © and the Manus 2° owe","sages, 361 the four who came before them 362 and the Manus 363 owe"); fx(88,"365 | am","365 I am"); fx(88,"ex- plaining","explaining"); auto(88,[361,362,363,364,365,366,367])
fx(89,"“Arjuna said, “You are","‘“Arjuna said, ‘You are"); fx(89,"Asita-Devala 2© and","Asita-Devala 369 and"); fx(89,"manifestations. >’! 0 supreme being!","manifestations. 371 O supreme being!"); auto(89,[368,369,370,371])
R=[("““The lord said, ‘ʻO foremost","‘“The lord said, ‘O foremost"),("manifesta- tions","manifestations"),("3741 am","374 I am"),("379 T am","379 I am"),("380 1 am Meru","380 I am Meru"),("Among weapons I am vajra.","Among weapons I am vajra. 391"),("be- come kamadhenu. 97 I become","become kamadhenu. 392 I become"),("ser- pents Iam","serpents I am"),("ancestors Iam","ancestors I am"),("Among those wh devour","Among those who devour"),("the lion among animals.","the lion among animals. 400"),("weapons, Iam Rama","weapons, I am Rama"),("Jahnavi. 499 0 Arjuna!","Jahnavi. 403 O Arjuna!")]
for a,b in R: fx(90,a,b)
auto(90,list(range(372,405)))
for a,b in [("408 T am gambling","408 I am gambling"),("409 T am energy","409 I am energy"),("4101 am danda","410 I am danda"),("41! Tam strategy","411 I am strategy"),("with only a part of me.”","with only a part of me.’”’")]: fx(91,a,b)
auto(91,list(range(405,412)))
mk(892,[P[87]+' '+P[88],P[89],P[90]+' '+P[91]],357,411)
