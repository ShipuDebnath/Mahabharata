exec(open('gen64.py').read())
p=P[292]
R=[("travelled straight 28! O venerable","travelled straight. 381 O venerable"),(" ““There was an extremely","\n‘“There was an extremely"),("Vaishravana>®2 in","Vaishravana 382 in"),("the hair? was like","the hair 383 was like"),("your evil policy.”","your evil policy.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(381,384)))
mk(959,P[i].split('\n'),381,383)
