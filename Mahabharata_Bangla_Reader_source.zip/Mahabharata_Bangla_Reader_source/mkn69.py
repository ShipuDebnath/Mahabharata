import mknotes3,mknotes,json,re,os
R=[('I The Pandavas.', '1 The Pandavas.'), ('STs this at the time', '5 Is this at the time'), ('©Bhurishrava. 7Saptatantu', '6 Bhurishrava. 7 Saptatantu'), ('From the text, it is not obvious where', '9 From the text, it is not obvious where'), ('llKrishna’s name.', '11 Krishna’s name.'), ('circular. 1 Duryodhana', 'circular. 19 Duryodhana'), ('alone. 23 Indra.', 'alone. 25 Indra.'), ('2°The word used is tata.', '29 The word used is tata.'), ('3 l Arjuna.', '31 Arjuna.'), ('al Hridika’s son', '41 Hridika’s son'), ('5lThe text uses', '51 The text uses'), ('38kritavarma.', '38 Kritavarma.'), ('miles. 8kritavarma.', 'miles. 58 Kritavarma.'), ('604 royal sage', '60 A royal sage'), ('6l Ekapada.', '61 Ekapada.'), ('©5There are different versions', '65 There are different versions'), ('6 "Indra.', '69 Indra.'), ('73%ndra.', '73 Indra.'), ('850n the part', '85 On the part'), ('0The lotuses', '90 The lotuses'), ('°| The dead bodies.', '91 The dead bodies.'), ('°3Dhrishtadyumna’s horses', '93 Dhrishtadyumna’s horses'), ('red. 4 The parshnis', 'red. 94 The parshnis'), ('95 atyaki. Drona.', '95 Satyaki. 96 Drona.'), ('°8 Those of a brahmana.', '98 Those of a brahmana.'), ('°° Meaning Satyaki’s.', '99 Meaning Satyaki’s.'), ('1l1Vinda', '111 Vinda'), ('battle. 11 Duryodhana.', 'battle. 118 Duryodhana.'), ('13 l Arjuna.', '131 Arjuna.'), ('1 34Duryodhana ’sS.', '134 Duryodhana’s.'), ('1371n every direction', '137 In every direction'), ('131 The rakshasa Alambusa.', '151 The rakshasa Alambusa.'), ('15750 far', '157 So far'), ('1721h the Pandava camp.', '172 In the Pandava camp.'), ('18 Though not clearly stated', '181 Though not clearly stated'), ('2031 iterally', '203 Literally'), ('210, snataka', '210 A snataka'), ('2114 mixture', '211 A mixture'), ('2131 is not obvious', '213 It is not obvious'), ('21 7Dhrishtadyumna.', '217 Dhrishtadyumna.'), ('2220f mounts', '222 Of mounts'), ('23 ln Section 67', '231 In Section 67'), ('242Īndra', '242 Indra'), ('25 !Duryodhana’s charioteer', '251 Duryodhana’s charioteer'), ('25 3That is', '253 That is'), ('25 6Those that had', '256 Those that had'), ('25 TYuvaraja', '257 Yuvaraja'), ('25° There should be no confusion', '259 There should be no confusion'), ('2601t was red', '260 It was red'), ('279)hrishtaketu.', '279 Dhrishtaketu.'), ('28°Bhima and Yudhishthira', '289 Bhima and Yudhishthira'), ('2950 Drona’s chariot.', '295 To Drona’s chariot.'), ('3 12Duryodhana’s à 31 3Duryodhana.', '312 Duryodhana’s. 313 Duryodhana.'), ('3 17 That is, Wheeled', '317 That is, wheeled'), ('3280f that army', '328 Of that army'), ('3394 shataghni', '339 A shataghni'), ('3430nly part', '343 Only part'), ('3504 reference', '350 A reference'), ('35 IThe subterranean', '351 The subterranean'), ('352K alakuta', '352 Kalakuta'), ('35 3Duryodhana’s brothers.', '353 Duryodhana’s brothers.'), ('35 Arjuna. 35 7Yudhamanyu', '356 Arjuna. 357 Yudhamanyu'), ('36l Hence', '361 Hence'), ('364-Vidura.', '364 Vidura.'), ('373K arna’s chariot. 3761n Section 55', '375 Karna’s chariot. 376 In Section 55'), ('3948 hurishrava.', '394 Bhurishrava.'), ('4040f protecting', '404 Of protecting'), ('408K artavirya', '408 Kartavirya'), ('40° The daughter', '409 The daughter'), ('410%¢ has to be inferred', '410 It has to be inferred'), ('41 Ishini.', '411 Shini.'), ('41275 wealth.', '412 As wealth.'), ('41 4 Arjuna. 4115The arms.', '414 Arjuna. 415 The arms.'), ('42T Referring', '427 Referring'), ('429\\riddhakshatra.', '429 Vriddhakshatra.'), ('43150 that the head', '431 So that the head'), ('434R odasi.', '434 Rodasi.')]
def first(t):
    for a,b in R:
        if a in t: t=t.replace(a,b,1); continue
        rx=re.escape(a).replace('\\ ',r'\s?')
        m=re.search(rx,t); assert m,a; t=t[:m.start()]+b+t[m.end():]
    t=re.sub(r'(?<=\s)(\d{1,3})(?=[A-Z])',r'\1 ',t)
    t=re.sub(r'(Sections? \d+) ?\(',lambda m:m.group(1)+' (',t)
    return t
N,miss=mknotes3.parse(22740,23098,434,first=first)
print('miss',len(miss),miss)
if not miss:
    mknotes.fin(N,434,"notes69.json")
    d=json.load(open('notes69.json')); d={k:v.replace(' ',' ') for k,v in d.items()}
    for k,v in d.items():
        if v and v[0].islower(): d[k]=v[0].upper()+v[1:]
    json.dump(d,open('notes69.json','w'),ensure_ascii=False,indent=0)
if os.environ.get('SH'):
    for k in map(int,os.environ['SH'].split(',')): print(k,'::',N.get(k))

d=json.load(open('notes69.json'))
import re as _re
for k,v in d.items():
    v=_re.sub(r'\b(J|K|B|D|S|Y|V) (ayadratha|ritavarma|arna|rishna|hurishrava|rona|hikhandi|udhishthira|asudeva|ritra|ishnu|atyaki|uryodhana|hima|hrishtadyumna)',r'\1\2',v)
    d[k]=v
json.dump(d,open('notes69.json','w'),ensure_ascii=False,indent=0)
d=json.load(open('notes69.json'))
FX={'14':('N addition','In addition'),'100':('F lags','Flags'),'184':('K righna','Krishna'),'188':('B alarama','Balarama'),'239':('K artavirya','Kartavirya'),'311':('P the encounter','In the encounter')}
for k,(a,b) in FX.items(): d[k]=d[k].replace(a,b)
json.dump(d,open('notes69.json','w'),ensure_ascii=False,indent=0)
d=json.load(open('notes69.json'))
FX2={'177':('Yijaya','Vijaya'),'182':('Alarama','Balarama'),'189':('Vudhishthira','Yudhishthira'),'155':('FThis','This'),'163':('Qbviously','Obviously')}
for k,(a,b) in FX2.items(): d[k]=d[k].replace(a,b)
json.dump(d,open('notes69.json','w'),ensure_ascii=False,indent=0)
d=json.load(open('notes69.json'))
FX3={'247':('Vama','Yama'),'266':('Ajternatively','Alternatively'),'278':('ina pot','in a pot'),'297':('areference','a reference'),'300':('descrbed','described'),'314':('YYudhishthira','Yudhishthira'),'382':('Jamidha','Ajamidha')}
for k,(a,b) in FX3.items(): d[k]=d[k].replace(a,b)
json.dump(d,open('notes69.json','w'),ensure_ascii=False,indent=0)
