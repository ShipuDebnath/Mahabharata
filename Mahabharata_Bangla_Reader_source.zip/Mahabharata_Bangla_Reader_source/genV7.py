exec(open('gen87vh.py').read())
NB(1747,46,48,fix=(("4This incident","47 This incident"),))
p=H(27,1747)+'\n'+J(28,29)
R=[("6 udhishthira said, “O father!","‘Yudhishthira said, “O father!"),("about this in detail.”","about this in detail.”’"),("superior to granting life.’“°","superior to granting life. 46 ’"),("life to the pigeon.*’","life to the pigeon. 47"),("Amrita, sudha,** svaha","Amrita, sudha, 48 svaha"),("This is what Manu has said.”","This is what Manu has said.”’")]
run(1747,p,R,[46,47,48],46,48,posts=[("life. ’","life.’")])
NB(1748,49,56,fix=(("Yama.","52 Yama."),("This brahmana’s lifespan","53 This brahmana’s lifespan"),("Implicitly, brahmanas","55 Implicitly, brahmanas")))
p=H(29,1748)+'\n'+J(30,33)
R=[("c yo said, “Tell me again","‘Yudhishthira said, “Tell me again"),("lamps, food and garments.”","lamps, food and garments.”’"),("known as Yamuna.” O lord","known as Yamuna. 49 O lord"),("instructed a man.*’ He","instructed a man. 50 He"),("intelligent one’s*! equal","intelligent one’s 51 equal"),("When Dharmaraja’? spoke","When Dharmaraja 52 spoke"),("dwell here with you.’*?","dwell here with you. 53 ’"),("people have performed.**","people have performed. 54"),("‘Yama said, ‘ʻO brahmana rishi!","‘“Yama said, ‘O brahmana rishi!"),("house, with all his soul.” There","house, with all his soul. 55 There"),("water must be offered.”","water must be offered.’"),("Once he”® had been","Once he 56 had been"),("superior to all kinds of gains.”","superior to all kinds of gains.”’")]
run(1748,p,R,list(range(49,57)),49,56,posts=[("with you. ’","with you.’")])
