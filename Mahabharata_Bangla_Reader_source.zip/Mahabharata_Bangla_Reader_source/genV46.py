exec(open('gen87vh.py').read())
NB(1808,386,391,fix=(("38°Vrisha","386 Vrisha"),("*87Bhuta","387 Bhuta"),("388Parvati","388 Parvati"),("38°Shiva","389 Shiva"),("°°There is a pun","390 There is a pun"),("*°'The name","391 The name")))
p=H(288,1808)+'\n'+J(289,292)
L=p.split('\n')
for i in range(1,len(L)): L[i]='‘“'+re.sub(r'^[‘“’"]+','',L[i])
p='\n'.join(L)
R=[("é hishma said","‘Bhishma said"),("between Shankara and Uma. ‘Narada said, ‘The lord","between Shankara and Uma.\n‘“Narada said, ‘The lord"),("Vrishabhadhvaja**°","Vrishabhadhvaja 386"),("Bhutapati’s**’ place","Bhutapati’s 387 place"),("daughter of the mountain*** arrived","daughter of the mountain 388 arrived"),("Sharva**’ saw","Sharva 389 saw"),("Since the light was destroyed,","Since the light was destroyed, 390"),("the Pinaka”! always","the Pinaka 391 always"),("behind these forms.””’”’","behind these forms.”’”")]
run(1808,p,R,list(range(386,392)),386,391)
