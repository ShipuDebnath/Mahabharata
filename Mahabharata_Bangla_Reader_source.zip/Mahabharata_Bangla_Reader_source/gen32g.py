exec(open('gen32.py').read())
import re as _r
s=P[61]; i=s.index('dhavas'); j=s.index('vibhitakas.148')+len('vibhitakas.148')
names=['dhavas','ashvatthas','tindukas','ingudas','kimshukas','arjunas','arishtas','chandanas','shalmalas','jambus','mangoes','lodhras','khadiras','shakas','cane','kashmaris','amalakas','plakshas','kadambas','udumburas','badaris','bilvas','nyagrodhas','priyalas','talas','kharjuras','haritakas','vibhitakas']
k=124; out=[]
for nm in names:
    if nm in ('mangoes','cane','bilvas'): out.append(nm)
    else: out.append('%s, %d'%(nm,k) if nm!='vibhitakas' else 'vibhitakas. 148'); k+=1 if nm not in ('mangoes','cane','bilvas') else 0
lst=', '.join(out[:-1]).replace(', ,',',')
lst=_r.sub(r', (\d+),',r', \1',', '.join(o for o in out[:-1]))
P[61]=s[:i]+lst.replace(', 147',' 147')+' and '+out[-1]+s[j:]
P[62]=_r.sub(r'^‘Damayanti said, ‘','“Damayanti said, ‘',P[62]); 
P[62]=P[62].replace('words that he!49 is here','words that he 149 is here')
t=P[63].replace('“““This','“This').rstrip()+' '+P[64].strip()
for a,b in [('It resounds on all 130 and pumnagas.!9! There are','It resounds on all sides with the noise of many types of birds. It is adorned with kimshukas, ashokas, 150 bakulas and pumnagas. 151 There are'),('He is the lord of sides with the noise of many types of birds. It is adorned with kimshukas, ashokas, bakulas the earth and','He is the lord of the earth and'),('about the king.!5 2 “O illustrious','about the king. 152 “O illustrious'),('the fire. 153 He','the fire. 153 He')]:
    assert a in t,a; t=t.replace(a,b)
P[65]=P[65].replace('traditions,!54 brings','traditions, 154 brings')
P[67]=P[67].replace('“Tell us what we can do for you,’','‘Tell us what we can do for you,’')
P[68]=P[68].replace('‘ʻO fortunate','‘O fortunate')
u=P[70].rstrip()+' '+P[71].strip()
for a,b in [('Dramida.!55 O beautiful ashoka! 156 Free','Dramida. 155 O beautiful ashoka! 156 Free'),('accordingly,!9/ so','accordingly, 157 so')]:
    assert a in u,a; u=u.replace(a,b)
for a,b in [('chakravakas.!>8 Tt was','chakravakas. 158 It was'),('yak- shi, a rakshasi 15 ? or','yakshi, a rakshasi 159 or'),('for the sake of profit.””’','for the sake of profit.’”')]:
    assert a in P[72],a; P[72]=P[72].replace(a,b)
for i2 in (66,67,69,70,72): P[i2]=_r.sub(r'^[‘“]*““','“',P[i2])
u=_r.sub(r'^[‘“]*““','“',u)
mk(358,[P[61],P[62],t,P[65],P[66],P[67],P[68],P[69],u,P[72]],124,159)
