import json,re,sys
sys.path.insert(0,'/home/claude/mbh')
from tidy5 import tidy
P=open('/tmp/c59.txt',encoding='utf-8').read().split('\n')
N={int(k):v for k,v in json.load(open('notes59.json',encoding='utf-8')).items()}
