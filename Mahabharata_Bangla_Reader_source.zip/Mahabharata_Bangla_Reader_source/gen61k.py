exec(open('gen61.py').read())
for a,b in [("Tell me in detail.” ‘Sanjaya said","Tell me in detail.”’\n‘Sanjaya said"),("and pushya.!5 5 O","and pushya.155 O"),("ex- tremely","extremely"),("are emperors.!5 60 great king!","are emperors.156 O great king!"),("is very small.!57 Haimavat","is very small.157 Haimavat"),("and so on.” 158","and so on.158”’")]: fx(60,a,b)
a,b=P[60].split('\n')
mk(871,[a,b],155,158)
