exec(open('gen74.py').read())
p=dh('\n'.join(P[60:62]))
R=[("from the delighted sid- 87 and in the battle, Bhimsena","from the delighted siddhas. 86 The assembled sages also said that it was extraordinary. Shalya was like a dart in his valour 87 and in the battle, Bhimasena"),("broad-headed arrows to dhas. The assembled sages also said that it was extraordinary. Shalya was like a dart in his valour sever the archer","broad-headed arrows to sever the archer"),("In Bhimasena’s presence, he then used","In Bhimasena’s presence, he 88 then used"),("\n‘“They were swiftly","\n“They were swiftly"),("those five.89 Shalya","those five. 89 Shalya"),("chariot wheel of the king of Madra.” The king","chariot wheel of the king of Madra. 90 The king"),("Yudhisthira","Yudhishthira"),("the ornament of a battle.” ’","the ornament of a battle.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(86,91)))
mk(1231,P[i].split('\n'),86,90)
