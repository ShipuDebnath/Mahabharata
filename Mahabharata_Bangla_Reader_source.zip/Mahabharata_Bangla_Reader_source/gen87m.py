exec(open('gen87h.py').read())
NB(1700,1155,1161,merge=(2,),fix=(("'IS81f women","1158 If women"),("5°Uma","1159 Uma"),("1604 t the time","1160 At the time")))
p=H(98,1700)+'\n'+J(99,102)
R=[("¢W udhishthira said, “O bull","‘Yudhishthira said, “O bull"),("sahadharma''®","sahadharma 1155"),("or asura?'!°° T have","or asura? 1156 I have"),("O father!''*’","O father! 1157"),("mystery to me.!!58","mystery to me. 1158"),("O immensely wise one? You","O immensely wise one! You"),("in its entirety.”","in its entirety.”’"),
("““Ashtavakra answered","‘“Ashtavakra answered"),("““Vadanya said","‘“Vadanya said"),("the goddess'! tormented","the goddess 1159 tormented"),("night of destruction!! and","night of destruction 1160 and"),("accept the hand.''°!","accept the hand. 1161"),("successful journey there.”","successful journey there.’”’")]
run(1700,p,R,list(range(1155,1162)),1155,1161)
