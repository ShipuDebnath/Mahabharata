exec(open('gen73.py').read())
p='\n'.join(P[203:205])
R=[("samshap- takas","samshaptakas"),("the narayana army.486 In","the narayana army. 486 In"),("maharatha Susharma.*8/ The","maharatha Susharma. 487 The"),("broadheaded","broad-headed"),("full of many flowers.488 © best","full of many flowers. 488 O best"),
("\n‘ “In that battle, he then spoke","\n“In that battle, he then spoke"),("blew on Devadatta.*8? Krishna","blew on Devadatta. 489 Krishna"),("tied down their feet.490 Partha","tied down their feet. 490 Partha"),("battle with Taraka.49! Slaughtered","battle with Taraka. 491 Slaughtered"),
("the Suparna weapon 492 Suparna","the Suparna weapon. 492 Suparna"),("the aindra weapon 493 9 venerable one!","the aindra weapon. 493 O venerable one!"),("Pandava Kiriti.” ’","Pandava Kiriti.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(486,494)))
mk(1187,P[i].split('\n'),486,493)
