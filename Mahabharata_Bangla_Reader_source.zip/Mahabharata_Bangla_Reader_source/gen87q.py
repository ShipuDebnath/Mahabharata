exec(open('gen87h.py').read())
NB(1704,1175,1182,fix=(("1754 brahmana","1175 A brahmana"),))
p=H(124,1704)+'\n'+J(125,147)
R=[("¢-w udhishthira asked, “O best","‘Yudhishthira asked, “O best"),("without the signs?”!!”°","without the signs? 1175 ”’"),("‘Bhishma replied, “O son!!!’°","‘Bhishma replied, “O son! 1176"),("must be tested.”!!7”","must be tested. 1177 ”’"),("three of these attributes.!!”*","three of these attributes. 1178"),
("“The earth said","‘“The earth said"),("kinds of conduct.’!!”","kinds of conduct. 1179 ’"),("““Kashyapa said","‘“Kashyapa said"),("““Agni said, “There","‘“Agni said, ‘There"),("“Markandeya said","‘“Markandeya said"),("one and a half times the other.”","one and a half times the other.’”’"),
("‘Bhishma said, “Having said this","‘Bhishma continued, “Having said this"),("quickly went away.”!!*°","quickly went away. 1180 ”’"),("regarded as good conduct?”!!*!","regarded as good conduct? 1181 ”’"),("an entire lineage.'!®?","an entire lineage. 1182")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
L=[]
for l in p.split('\n'):
    if l.startswith('“Yudhishthira') or l.startswith('“Bhishma'): l='‘'+l[1:]
    if (l.startswith('‘Yudhishthira') or l.startswith('‘Bhishma')) and l.endswith('”'): l+='’'
    L.append(l)
p='\n'.join(L)
run(1704,p,[],list(range(1175,1183)),1175,1182,posts=[("ones —the","ones—the"),("tested. ”’","tested.”’"),("conduct. ’","conduct.’"),("away. ”’","away.”’")])
