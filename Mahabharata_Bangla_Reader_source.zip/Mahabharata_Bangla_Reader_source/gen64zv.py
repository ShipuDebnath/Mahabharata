exec(open('gen64.py').read())
p=P[251]+'\n'+P[252]
R=[("like Vinata’s son.>3 Stationed","like Vinata’s son. 333 Stationed"),("“The rakshasa is certainly","‘The rakshasa is certainly"),("O son!?34 I see","O son! 334 I see"),("present themselves.>3> Having","present themselves. 335 Having"),("‘A battle then commenced","‘“A battle then commenced"),("the waves were 336 constituted the weeds and moss.","the waves were elephants, horses and men. The hair 336 constituted the weeds and moss."),("mutiliated","mutilated"),("They fell down in that tu- elephants, horses and men. The hair mult, like mountains with their wings sliced off.237","They fell down in that tumult, like mountains with their wings sliced off. 337"),("were generally made to retreat.”","were generally made to retreat.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(333,338)))
mk(949,P[i].split('\n'),333,337)
