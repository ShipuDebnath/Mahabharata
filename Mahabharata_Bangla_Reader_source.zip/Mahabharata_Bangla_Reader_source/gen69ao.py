exec(open('gen69.py').read())
p=P[171].replace('CHAPTER 1078(101) ','')+'\n'+P[172]+'\n'+P[173]+'\n'+P[174]+'\n'+P[175]+' '+P[176]+'\n'+P[177]+'\n'+P[178]
R=[("foremost among men2/7 was","foremost among men 277 was"),("from a supreme pot 2180 descendant","from a supreme pot. 278 O descendant"),("‘“Maharatha Brihatkshatra","“Maharatha Brihatkshatra"),("Bri- hatkshatra","Brihatkshatra"),("““O king! On the death","“O king! On the death"),("He279 was trying","He 279 was trying"),
("““O descendant of the Bharata lineage! The Pandavas","“O descendant of the Bharata lineage! The Pandavas"),("‘Drona was like Death","“Drona was like Death"),("chariots, “There is no doubt","chariots, ‘There is no doubt"),("Bharata lineage!280 There","Bharata lineage! 280 There"),("these words. ‘He used an arrow","these words. He used an arrow"),
("““Maharatha Chekitana","“Maharatha Chekitana"),("vajra in his hand.28!","vajra in his hand. 281"),("““O great king! O king! The intelligent","“O great king! O king! The intelligent"),("placing the Parthas in front of him.”","placing the Parthas in front of him.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(277,282)))
mk(1078,P[i].split('\n'),277,281)
