exec(open('gen59.py').read())
for a,b in [("“Bhishma said, ‘It is","‘“Bhishma said, ‘It is"),("with Sahadeva.!? O","with Sahadeva.13 O"),("O son!!4 They","O son!14 They"),("and Partha.!> O","and Partha.15 O"),("like sharks!° that","like sharks16 that"),("O son!!” It is","O son!17 It is"),("O son!!* He will","O son!18 He will"),("types of weapons and bows.”","types of weapons and bows.’”’")]: fx(11,a,b)
mk(826,[P[11]],13,18)
