exec(open('gen73.py').read())
p='\n'.join(P[320:327])
R=[("\n‘ “O great king!","\n“O great king!"),("\n‘ “The angry","\n“The angry"),("at- tacked","attacked"),("J ambha./22 Using","Jambha. 722 Using"),("he’23 attacked Nakula","he 723 attacked Nakula"),("Single-hand- edly","Single-handedly"),("seemed to be sporting 24 with","seemed to be sporting 724 with"),("fore- most among men, attacked","foremost among men, attacked"),("he’25 shattered","he 725 shattered"),
("\n‘ “Nakula’s bow","\n“Nakula’s bow"),("Hridika’s son,/26 Kripa","Hridika’s son, 726 Kripa"),("eleven brave ones/2/ and","eleven brave ones 727 and"),
("\n‘“Those on your side","\n“Those on your side"),("They/28 had","They 728 had"),("Using 729 severely struck Kripa","Using ten arrows that were completely made out of iron, the son of Kuninda 729 severely struck Kripa"),("at his/20 chariot","at his 730 chariot"),
("the lord of Gandhara/>! ered his head, while he was still roaring. When the Kunindas were slain, the maharathas on your side were delight- ten arrows that were completely made out of iron, the son of Kuninda sev- ed. They loudly","the lord of Gandhara 731 severed his head, while he was still roaring. When the Kunindas were slain, the maharathas on your side were delighted. They loudly"),
("lightining","lightning"),("your son! 32 between","your son 732 between"),("sharp arrows.\nWith the son of the king","sharp arrows. With the son of the king"),("Shachi’s consort./33 However","Shachi’s consort. 733 However"),("The lord Kratha’4 was","The lord Kratha 734 was"),("mountain733 slew","mountain 735 slew"),("he ous regions brought","he brought"),("Suparna./36 The","Suparna. 736 The"),("Nakula’s son./37 At","Nakula’s son. 737 At"),
("\n*“Karna’s son pierced","\n“Karna’s son pierced"),("that he /38 was","that he 738 was"),("best of men/>? was","best of men 739 was"),("ma- haratha","maharatha"),("kill the son of a suta in the battle.”4! Kiriti","kill the son of a suta 741 in the battle. Kiriti"),("towards the ratha Kiriti.” ’","towards the ratha Kiriti.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(722,742)))
mk(1212,P[i].split('\n'),722,741)
