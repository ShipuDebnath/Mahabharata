exec(open('gen65.py').read())
p=P[30]+'\n'+P[31]
R=[("‘Make endeavours to counter the one who was born from a pot and surround him.>? Arjuna","‘Make endeavours to counter the one who was born from a pot 39 and surround him.’ Arjuna"),("“With the bow and arrows in his hand","‘“With the bow and arrows in his hand"),("Shinis’s descendant","Shini’s descendant"),("trembled because of that loud roar.”","trembled because of that loud roar.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[39])
mk(984,P[i].split('\n'),39,39)
