exec(open('gen87h.py').read())
NB(1708,1223,1233,fix=(("12247 iterally","1224 Literally"),("'227Qn the","1227 On the")))
p=H(161,1708)+'\n'+J(162,168)
R=[("Vee said, ‘He was","Vaishampayana said, ‘He was"),("rivers are really sacred?”\n","rivers are really sacred?”’\n"),("had obtained success.'?","had obtained success. 1223"),("““Shilavritti asked","‘“Shilavritti asked"),("“The Siddha! replied","‘“The Siddha 1224 replied"),("The run rises","The sun rises"),("satisified","satisfied"),
("seeing Tarkshya,!”*","seeing Tarkshya, 1225"),("is for serpents.!?®","is for serpents. 1226"),("both his family lines.'??’","both his family lines. 1227"),("adorn the three worlds.'”5","adorn the three worlds. 1228"),("lord of the gods!” to men","lord of the gods 1229 to men"),("conveyed by her to heaven.!”0","conveyed by her to heaven. 1230"),
("“““Ganga’s waves","‘“‘Ganga’s waves"),("She is Supreme among","She is supreme among"),("Guha in her womb.'**!","Guha in her womb. 1231"),("O king!!”** Ganga","O king! 1232 Ganga"),("the lord and the god,!?","the lord and the god, 1233"),("worship her with faith.’”","worship her with faith.’”’"),("You will obtain supreme success.”","You will obtain supreme success.”’"),("Vaishampayana said, “This is the history","Vaishampayana said, ‘This is the history")]
run(1708,p,R,list(range(1223,1234)),1223,1233)
