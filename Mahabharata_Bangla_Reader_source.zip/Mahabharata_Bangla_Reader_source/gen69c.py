exec(open('gen69.py').read())
p=P[10]+'\n'+P[11]
R=[("welltempered","well-tempered"),("They raised these !© and","They raised these 16 and"),("“Where is Arjuna? Where is Govinda?","‘Where is Arjuna? Where is Govinda?"),("“Drona blew on his conch","‘“Drona blew on his conch"),("three govyutis!? behind","three govyutis 17 behind"),("form of a cart.!8 It","form of a cart. 18 It"),("The king!’ was delighted","The king 19 was delighted"),("gave rise to fear.”","gave rise to fear.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[16,17,18,19])
mk(1040,P[i].split('\n'),16,19)
