exec(open('gen54.py').read())
fx(154,"“Narada said, “On","‘Narada said, “On"); fx(154,"sons and grandsons.”®! This","sons and grandsons.201 This")
fx(155,"““When","‘“When"); fx(155,"Galava, travelled","Galava travelled"); fx(155,"constituent parts??? zens. He","constituent parts202 in his army. He loved brahmanas and was the beloved of the citizens. He"); fx(155,"arrive at a decision.”","arrive at a decision.’”’")
mk(776,[P[154],P[155]],201,202)
