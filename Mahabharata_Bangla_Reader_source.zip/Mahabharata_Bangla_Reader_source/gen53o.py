exec(open('gen53.py').read())
fx(71,"Jamadagni’s son.!’","Jamadagni’s son.137"); fx(71,'faced hardships.!**','faced hardships.138'); fx(71,'Parjanya!*°','Parjanya139'); fx(71,'the grandfather,!*°','the grandfather,140')
mk(723,[P[71]],137,140)
