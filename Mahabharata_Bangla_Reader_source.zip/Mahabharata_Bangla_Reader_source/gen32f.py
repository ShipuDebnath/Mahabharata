exec(open('gen32.py').read())
def q(i): P[i]=re.sub(r'^[‘“]*““','“',P[i])
for i in range(51,60): q(i)
R={51:[('three nights outside. 14 ““O great king!','three nights outside. 114\n“O great king!'),('homage towards him! 15 Thus','homage towards him. 115 Thus')],
52:[('his riches.!!© He','his riches. 116 He'),('Iam miserable and hungry','I am miserable and hungry'),('Iam miserable and have','I am miserable and have'),('Dakshinapatha.’ 117 Damayanti','Dakshinapatha.’ 117 Damayanti'),('Damayanti said, ʻO great king!','Damayanti said, ‘O great king!'),('in our house.’””’','in our house.’”')],
54:[('“Nala said, “There is','“Nala said, ‘There is'),('increase your unhappiness?’','increase your unhappiness?’”')],
55:[('cov- ered in only half her garment. !!8 With','covered in only half her garment. 118 With'),('dwelling house.!!9 On','dwelling house. 119 On'),('wellwishers','well-wishers'),('sweetsmiling','sweet-smiling')],
57:[('crying “Alas! O king!’','crying, ‘Alas! O king!’')],
58:[('dried up.!20 Suddenly, Bhi- ma’s','dried up. 120 Suddenly, Bhima’s'),('constrictor.!2! As','constrictor. 121 As'),('the serpent,!22 she','the serpent, 122 she'),('Nishadha. “O protector!','Nishadha. ‘O protector!')],
59:[('the hunter!23 spoke','the hunter 123 spoke')]}
for i,L in R.items():
    for a,b in L: fx(i,a,b)
a,b=P[51].split('\n')
sp(52,'Damayanti was oppressed by grief')
mk(355,[a,b,P[52]],114,117)
mk(356,[P[54],P[55]],118,119)
P[56]=P[56].replace('357(60) ','',1)
mk(357,[P[56],P[57],P[58],P[59]],120,123)
