exec(open('gen63.py').read())
intro='Section Sixty-Three Bhagavad Gita Parva: This parva has 994 shlokas and twenty-seven chapters. '+P[1]
fx(3,"had been killed. 1 «O bull","had been killed. 1 “O bull"); fx(3,"Like Shakra, > he","Like Shakra, 5 he"); fx(3,"of your evil counsel.”","of your evil counsel.”’")
auto(3,[1,2,3,4,5])
mk(874,[intro,P[3]],1,5)
