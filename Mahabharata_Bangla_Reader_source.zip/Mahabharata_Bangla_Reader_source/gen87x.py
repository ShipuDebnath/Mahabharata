exec(open('gen87h.py').read())
NB(1711,1241,1243,fix=(("1242Hjis","1242 His"),("12434 sage","1243 A sage")))
p=H(176,1711)+'\n'+J(177,181)
R=[("6 D hishma said, “Thus","‘Bhishma said, “Thus"),("‘““Shakra said","‘“Shakra said"),("you are asking for.!™!","you are asking for. 1241"),("““Matanga replied","‘“Matanga replied"),("only one thing.” I do","only one thing. 1242 I do"),("worshipped by women.’”!?°","worshipped by women. 1243 ’"),("difficult to obtain.”","difficult to obtain.”’")]
run(1711,p,R,[1241,1242,1243],1241,1243,posts=[("women. ’","women.’")])
