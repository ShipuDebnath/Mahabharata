exec(open('gen73.py').read())
p='\n'.join(P[108:111])
R=[("lord of the ancestors2°’ when","lord of the ancestors 267 when"),(" < “O god among men!","\n“O god among men!"),("Shini’s descendant.2©8 That","Shini’s descendant. 268 That"),("sol- diers","soldiers"),("son of the sun2©? was","son of the sun 269 was"),
("supreme among men,2/0 with","supreme among men, 270 with"),("Vasusena2’! was","Vasusena 271 was"),("towards that 272 bull among rathas,^’/ together","towards that bull among rathas, 272 together"),
("Drupada’s son,2/3 destruction of men, rathas, horses and elephants.\nand there was a great ‘“The best of men","Drupada’s son, 273 and there was a great destruction of men, rathas, horses and elephants.\n“The best of men"),
("Lord Bhava2/4 in","Lord Bhava 274 in"),("hors- es","horses"),("they27> were","they 275 were"),("Howev- er","However"),("his horses.2/6 With","his horses. 276 With"),("and Parshata 277 The Chedis","and Parshata. 277 The Chedis"),
("\n‘ “Thus did they","\n“Thus did they"),("Mount Asta 218 o great king!","Mount Asta. 278 O great king!"),("withdrew.27? O king!","withdrew. 279 O king!"),("which 0° was like Rudra’s dancing arena.","which was like Rudra’s dancing arena.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,list(range(267,280)))
mk(1171,P[i].split('\n'),267,279)
