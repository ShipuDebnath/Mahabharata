exec(open('gen64.py').read())
p=P[193]+'\n'+P[194]
R=[("“He cheerfully instructed","‘“He cheerfully instructed"),("in the first yuga.2> 8 With","in the first yuga. 258 With"),("army of yoru sons","army of your sons"),("at the end of a yuga.”","at the end of a yuga.”’")]
for x,y in R:
    assert x in p,x; p=p.replace(x,y,1)
P.append(p); i=len(P)-1
auto(i,[258])
mk(936,P[i].split('\n'),258,258)
